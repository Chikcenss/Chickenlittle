@echo off
cd /d "%~dp0"
node --version
node standalone.js
pause
