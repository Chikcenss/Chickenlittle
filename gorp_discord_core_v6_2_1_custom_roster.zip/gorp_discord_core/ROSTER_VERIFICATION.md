# Live roster verification

The bot authenticated with Discord and its Google service account. The supplied spreadsheet matches the main roster in the uploaded configuration, and the private bot backend uses a different spreadsheet. All inspections were read-only; no sheet cells, Discord commands, roles, or messages were changed.

**Result: the custom layout is mapped, but live synchronization is blocked by protected-cell permissions and existing roster data errors.**

The mapped layout contains 9 rank sections, 743 recognizable callsign slots, 240 occupied rows and 505 vacant rows.

## Protected roster cells

Google reports that the service account cannot edit the mapped cells on all four visible roster worksheets. No unprotected exceptions were returned. Reading the sheet succeeds; that does not grant permission to synchronize it.

Use the service account identified by `client_email` in your existing `google-service-account.json`. Grant it spreadsheet edit access and allow it to edit the intended cells under **Data → Protect sheets and ranges**. Preserve protections for other users.

| Worksheet | Mapped columns |
| --- | --- |
| Probationary Officers | callsign=B, name=C, rank=D, id=K, status=M, notes=I |
| Law Enforcement Officers | callsign=B, name=C, rank=D, id=V, status=W, notes=P |
| Senior Law Enforcement Officers | callsign=B, name=C, rank=D, id=T, status=U, notes=P |
| Supervisors / Command Staff | callsign=D, name=E, rank=F, id=V, status=W, notes=R |

## Records requiring correction

These are existing sheet records, not changes made during verification. Confirm the correct officer and rank before removing duplicate identities or correcting IDs. Keep officer notes and other manual data. Discord IDs should be stored as plain text.

| Issue | Locations |
| --- | --- |
| Invalid Discord ID | Law Enforcement Officers row 64 |
| Malformed callsign | Senior Law Enforcement Officers row 64 |
| Malformed callsign | Supervisors / Command Staff row 239 |
| Same Discord ID in multiple officer rows | Law Enforcement Officers row 28; Law Enforcement Officers row 55 |
| Same Discord ID in multiple officer rows | Law Enforcement Officers row 31; Senior Law Enforcement Officers row 80 |
| Same Discord ID in multiple officer rows | Law Enforcement Officers row 63; Supervisors / Command Staff row 142 |
| Same Discord ID in multiple officer rows | Senior Law Enforcement Officers row 38; Supervisors / Command Staff row 215 |
| Same Discord ID in multiple officer rows | Senior Law Enforcement Officers row 59; Supervisors / Command Staff row 155 |
| Same Discord ID in multiple officer rows | Supervisors / Command Staff row 11; Supervisors / Command Staff row 14; Supervisors / Command Staff row 66 |
| Same Discord ID in multiple officer rows | Supervisors / Command Staff row 88; Supervisors / Command Staff row 269 |

The malformed printed callsigns are:

- `Senior Law Enforcement Officers!B64`: `(XI-55` appears intended to be `(X)I-55`.
- `Supervisors / Command Staff!D239`: `X)G-39` appears intended to be `(X)G-39`.
- `Law Enforcement Officers!V64` contains an invalid Discord ID; replace it with the correct officer ID.

## Discord configuration

Read-only role verification resolved 40 of 41 configured roles. The required department membership role exists and the bot's core rank mapping is reliable.

There are two Discord roles named `Fire Chief`; that optional non-patrol role is ambiguous. Select the intended role ID if you use it. No core patrol rank was missing.

## Recheck before starting

After fixing permissions and the listed records, run:

```sh
cd gorp_discord_core
npm test
npm run verify:roster
```

In this cloud environment, prefix the network command with `NODE_USE_ENV_PROXY=1`. The verification command must pass before live synchronization. If saved per-guild settings exist, they take precedence over the source configuration; use `--guild=ID` to select a different configured guild.

Test the initial live synchronization on a disposable roster copy before enabling it on the original. Run only one bot instance. Live writes and gateway startup against the real Discord server have not been tested during this update.
