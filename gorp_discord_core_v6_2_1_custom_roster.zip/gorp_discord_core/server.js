'use strict';
// Universal dedicated roster bot: one existing bot token, isolated per-guild rosters.
// No headtags, FiveM player status, ACE sync, moderation or vehicle code.
const {verifyBotIdentity}=require('./bot_identity');
const {Client,GatewayIntentBits,Events,REST,Routes,SlashCommandBuilder}=require('./discord_local');
const {installSadleRosterSync,rankLevel}=require('./sadleroaster/index');
const {CustomRosterMirror,canonical,validatedLayout}=require('./sadleroaster/customRoster');
const {CallsignManager}=require('./sadleroaster/callsigns');
const {GoogleSheetsClient}=require('./sadleroaster/googleSheets');
const {isTestingOverride}=require('./sadleroaster/testOverride');
const R=typeof GetCurrentResourceName==='function'?GetCurrentResourceName():'gorp_discord_core';
const log=(...x)=>console.log('[GORP Roster]',...x);
const err=(...x)=>console.error('[GORP Roster]',...x);
const FILE='guild_roster_settings.private.json'; // Stored on server, never included with a distribution.
let client,token='',credentials=null,privateBot={},legacy={},settings={},rosters=new Map(),online=false;
let startupError=null;const registered=new Set();
// Runtime layout writers belong to one saved configuration and one roster instance.
const configRevisions=new Map(),rosterGenerations=new Map();
const RANKS={probationary:['Probationary',10],leo:['LEO 1',20],senior:['Senior LEO',30],corporal:['Corporal',40],sergeant:['Sergeant',50],lieutenant:['Lieutenant',60],captain:['Captain',70],commander:['Commander',80],hq:['HQ',90]};
const clean=x=>String(x??'').trim();
const validId=x=>/^\d{16,22}$/.test(clean(x));
function read(path,fallback){
 const source=typeof LoadResourceFile==='function'?LoadResourceFile(R,path):null;
 if(!source){if(fallback!==undefined)return fallback;throw Error('Missing '+path+' in '+R);}
 try{return JSON.parse(source);}catch(e){throw Error('Invalid JSON '+path+': '+e.message);}
}
function save(){
 if(typeof SaveResourceFile!=='function')throw Error('Cannot save setup: FiveM resource storage unavailable');
 const safe=JSON.stringify(settings,null,2);
 if(!SaveResourceFile(R,FILE,safe,Buffer.byteLength(safe)))throw Error('Could not save guild configuration file');
}
function setting(name,convar){const file=clean(privateBot?.[name]);const override=typeof GetConvar==='function'?clean(GetConvar(convar,'')):'';return file&&!file.startsWith('PASTE_')?file:override;}
function backendOptions(guildId,config,generation,revision){
 const prefixes=config.callsignPrefixes||legacy.callsignPrefixes||{};
 return {guildId,department:clean(config.department||'Department'),requiredRoleId:clean(config.requiredRoleId||''),membershipRoleIds:(config.membershipRoleIds||[]).map(String),
  credentials,spreadsheetId:clean(config.spreadsheetId),originalRosterSpreadsheetId:clean(config.originalRosterSpreadsheetId||''),
  activeTab:config.activeTab||'BOT Active',historyTab:config.historyTab||'BOT History',
  careerTab:config.careerTab||'BOT Career',rankHistoryTab:config.rankHistoryTab||'BOT Rank History',
  callsignTab:config.callsignTab||'BOT Callsigns',callsignHistoryTab:config.callsignHistoryTab||'BOT Callsign History',
  detailsTab:config.detailsTab||'BOT Officer Details',callsignChannelId:clean(config.callsignChannelId||''),
  personnelSpreadsheetId:clean(config.personnelSpreadsheetId||''),personnelLogChannelId:clean(config.personnelLogChannelId||''),personnelTabs:config.personnelTabs||{},
  callsignPrefixes:prefixes,rankRoles:config.rankRoles||[],reconcileSeconds:Math.max(30,Number(config.reconcileSeconds)||90),
  rosterLayout:config.rosterLayout?{...config.rosterLayout,callsignTab:config.callsignTab||'BOT Callsigns',callsignPrefixes:prefixes}:null,onLayoutChange:async layout=>{
    // A stopped writer may finish an outstanding Sheets request after an administrator
    // replaces its mapping. Never let that old callback replace the new configuration.
    if(rosterGenerations.get(guildId)!==generation || (configRevisions.get(guildId)||0)!==revision)
      throw Error('Roster configuration changed during synchronization; stale layout update discarded.');
    const next=structuredClone(settings[guildId]||config);
    next.rosterLayout=structuredClone(layout);
    commitConfig(guildId,next,{preserveOwnership:true});
  },getToken:()=>token};
}
function legacyConfig(){
 return {department:'SADLE',requiredRoleId:legacy.requiredRoleId,
  membershipRoleIds:(legacy.membershipRoles||[]).map(r=>clean(r.roleId)).filter(validId),
  spreadsheetId:legacy.spreadsheetId,originalRosterSpreadsheetId:legacy.originalRosterSpreadsheetId,
  rankRoles:legacy.ranks||[],callsignChannelId:legacy.callsignChannelId,personnelSpreadsheetId:legacy.personnelSpreadsheetId||'',personnelLogChannelId:legacy.personnelLogChannelId||'',
  activeTab:legacy.activeTab,historyTab:legacy.historyTab,careerTab:legacy.careerTab,
  rankHistoryTab:legacy.rankHistoryTab,callsignTab:legacy.callsignTab,
  callsignHistoryTab:legacy.callsignHistoryTab,detailsTab:legacy.detailsTab,
  callsignPrefixes:legacy.callsignPrefixes,rosterLayout:legacy.rosterLayout?structuredClone(legacy.rosterLayout):null,
  reconcileSeconds:legacy.reconcileSeconds||90,enabled:true,configured:true};
}
function getConfig(guildId){return settings[guildId]||(guildId===setting('guildId','gorp_discord_guild_id')?legacyConfig():null);}
async function startRoster(guildId){
 const config=getConfig(guildId);
 if(!config?.enabled||!config?.configured)return null;
 if(!validId(guildId)||!clean(config.spreadsheetId)||!config.rankRoles?.length)throw Error('Missing roster/sheet/rank configuration');
 if(!clean(config.requiredRoleId)&&!(config.membershipRoleIds||[]).length)throw Error('Missing membership role mapping');
 const generation=Symbol('roster generation'),revision=configRevisions.get(guildId)||0;
 rosterGenerations.set(guildId,generation); // Revoke the previous writer before stopping it.
 rosters.get(guildId)?.stop();rosters.delete(guildId);
 try{
  const roster=installSadleRosterSync(client,backendOptions(guildId,config,generation,revision));
  rosters.set(guildId,roster);
  log('Roster enabled for Discord guild '+guildId);
  return roster;
 }catch(error){
  if(rosterGenerations.get(guildId)===generation)rosterGenerations.delete(guildId);
  throw error;
 }
}
function emptyConfig(){return {department:'Department',enabled:false,configured:false,spreadsheetId:'',originalRosterSpreadsheetId:'',
 requiredRoleId:'',membershipRoleIds:[],rankRoles:[],callsignChannelId:'',personnelSpreadsheetId:'',personnelLogChannelId:'',
 activeTab:'BOT Active',historyTab:'BOT History',careerTab:'BOT Career',rankHistoryTab:'BOT Rank History',
 callsignTab:'BOT Callsigns',callsignHistoryTab:'BOT Callsign History',detailsTab:'BOT Officer Details',
 reconcileSeconds:90,rosterLayout:{sections:{},placements:{},allowWholeRowInsertion:false}};}
function builder(name,desc){return new SlashCommandBuilder().setName(name).setDescription(desc);}
function commands(){
 const personnel=(name,description)=>builder(name,description)
  .addUserOption(o=>o.setName('officer').setDescription('Officer to change').setRequired(true))
  .addStringOption(o=>o.setName('rank').setDescription('Destination rank, e.g. Lieutenant').setRequired(true))
  .addStringOption(o=>o.setName('reason').setDescription('Reason for the change').setRequired(true))
  .addStringOption(o=>o.setName('approval_type').setDescription('Optional: vote or individual approval'))
  .addUserOption(o=>o.setName('approved_by').setDescription('Optional: higher-up who authorized it'))
  .addStringOption(o=>o.setName('vote_result').setDescription('Optional: result of the vote'));
 return [
  personnel('promote','Sergeant+: promote lower-ranked officer'),
  personnel('demote','Sergeant+: demote lower-ranked officer'),
  builder('callsign','Sergeant+: set an officer callsign (or auto)')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('callsign').setDescription('Callsign or auto').setRequired(true)),
  builder('setup','Admin: guided roster installation and configuration')
   .addStringOption(o=>o.setName('step').setDescription('start, sheet, data_sheet, rank, section, link, unlink, remap, preview, finish, disable'))
   .addStringOption(o=>o.setName('rank').setDescription('Rank: leo, senior, corporal, sergeant, lieutenant, captain, commander, hq, probationary'))
   .addRoleOption(o=>o.setName('role').setDescription('Discord rank / membership role'))
   .addUserOption(o=>o.setName('officer').setDescription('Optional: link existing roster entry to Discord officer'))
   .addStringOption(o=>o.setName('value').setDescription('Department name, Google Sheet URL, or on/off'))
   .addStringOption(o=>o.setName('tab').setDescription('Existing custom roster worksheet title'))
   .addIntegerOption(o=>o.setName('start_row').setDescription('First officer slot row'))
   .addIntegerOption(o=>o.setName('end_row').setDescription('Last officer slot row'))
   .addStringOption(o=>o.setName('columns').setDescription('Example: callsign=A,name=B,rank=C,id=K,subdivision=D')),
  builder('editofficer','Sergeant+: edit an officer name display or roster status')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('field').setDescription('name or status').setRequired(true))
   .addStringOption(o=>o.setName('value').setDescription('New value').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('Optional reason')),
  builder('setsubdivision','Sergeant+: manage multiple officer subdivisions')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('subdivision').setDescription('One or more subdivisions, comma-separated; clear for clear').setRequired(true))
   .addStringOption(o=>o.setName('action').setDescription('Optional: add (default), remove, clear or replace'))
   .addStringOption(o=>o.setName('reason').setDescription('Optional reason')),
  builder('certification','Sergeant+: add or remove an officer certification')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('action').setDescription('add or remove').setRequired(true))
   .addStringOption(o=>o.setName('certification').setDescription('Certification name').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('Optional reason')),
  builder('removeofficer','Sergeant+: remove lower-ranked officer from department roles')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('Reason for removal (required)').setRequired(true)),
  builder('note','Sergeant+: add a PRIVATE personnel note')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('text').setDescription('Private note, up to 1200 characters').setRequired(true)),
  builder('notes','Sergeant+: view an officer private notes')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true)),
  builder('strike','Sergeant+: issue and record an officer strike')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('Why the strike was issued').setRequired(true))
   .addStringOption(o=>o.setName('severity').setDescription('Standard, Verbal, Written or Final')),
  builder('strikes','Sergeant+: view current strike count and history')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true)),
  builder('voidstrike','Sergeant+: void an incorrect strike (keeps audit history)')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('strike_id').setDescription('Full strike ID from /strikes').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('REQUIRED: Why the strike is being voided').setMinLength(1).setMaxLength(1000).setRequired(true)),
  builder('removestrike','Sergeant+: remove active strike, retain reason/history privately')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('strike_id').setDescription('Full strike ID from /strikes').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('REQUIRED: Why removed (e.g. sustained good behavior)').setMinLength(1).setMaxLength(1000).setRequired(true)),
  builder('appealstrike','Sergeant+: record successful appeal and clear active strike')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true))
   .addStringOption(o=>o.setName('strike_id').setDescription('Full strike ID from /strikes').setRequired(true))
   .addStringOption(o=>o.setName('reason').setDescription('REQUIRED: Why the appeal was granted').setMinLength(1).setMaxLength(1000).setRequired(true)),
  builder('officer','Sergeant+: privately view one officer personnel record')
   .addUserOption(o=>o.setName('officer').setDescription('Officer').setRequired(true)),
  builder('sync','Admin: reconcile Discord and Google Sheets now'),
  builder('roster','Show roster sync status'),
  builder('settings','Admin: show roster setup progress')
 ];
}
async function registerCommands(guildId){
 if(!validId(guildId)||registered.has(guildId))return;
 try{await new REST().setToken(token).put(Routes.applicationGuildCommands(client.user.id,guildId),{body:commands().map(c=>c.toJSON())});registered.add(guildId);log('Registered slash commands for '+guildId);}
 catch(e){err('Slash command registration failed in '+guildId+': '+e.message);}
}
function canConfigureRoster(memberPermissions,userId){
 // Only the exact testing account bypasses Discord Manage Server / Administrator.
 return isTestingOverride(userId)||(BigInt(memberPermissions||'0')&0x28n)!==0n;
}
function sheetId(input){
 const raw=clean(input),found=raw.match(/\/spreadsheets\/d\/([A-Za-z0-9_-]+)/);
 const value=found?found[1]:raw;
 if(!/^[A-Za-z0-9_-]{15,}$/.test(value))throw Error('Provide a valid Google Sheets link or spreadsheet ID');
 return value;
}
function rankKey(input){const k=clean(input).toLowerCase().replace(/[^a-z]/g,'');if(!RANKS[k])throw Error('Choose a rank: '+Object.keys(RANKS).join(', '));return k;}
function roleFrom(input){const id=clean(input?.id);if(!validId(id))throw Error('Select a real Discord role');return id;}
function columnsFrom(text){
 const cols={};for(const part of clean(text).split(',')){
  const [key,column]=part.split('=').map(x=>clean(x).toLowerCase());
  if(!key)continue;
  if(!['callsign','name','rank','id','status','subdivision','certifications','strikes','notes'].includes(key)||!/^[a-z]{1,3}$/.test(column||''))throw Error('Column mapping must look like callsign=A,name=B,rank=C,id=K');
  cols[key]=column.toUpperCase();
 }
 if(!cols.callsign||!cols.name)throw Error('Both callsign and name columns are required');
 if(new Set(Object.values(cols)).size!==Object.keys(cols).length)throw Error('Two fields cannot use the same column');
 return cols;
}
function commitConfig(guildId,config,{preserveOwnership=false}={}){
 const previous=settings[guildId],previousRevision=configRevisions.get(guildId),previousGeneration=rosterGenerations.get(guildId);
 if(!preserveOwnership){
  configRevisions.set(guildId,(previousRevision||0)+1);
  rosterGenerations.delete(guildId);
 }
 settings[guildId]=config;
 try{save();}catch(error){
  if(previous===undefined)delete settings[guildId];else settings[guildId]=previous;
  if(previousRevision===undefined)configRevisions.delete(guildId);else configRevisions.set(guildId,previousRevision);
  if(previousGeneration===undefined)rosterGenerations.delete(guildId);else rosterGenerations.set(guildId,previousGeneration);
  throw error;
 }
}
function sectionSignature(section){
 if(!section)return '';
 return JSON.stringify([section.tab,Number(section.startRow),Number(section.endRow),
  Object.entries(section.columns||{}).sort(([a],[b])=>a.localeCompare(b))]);
}
async function setup(guildId,interaction){
 const action=clean(interaction.options.getString('step')||'status').toLowerCase();
 if(action==='status'){const c=getConfig(guildId);return c?statusText(guildId,c):'Not configured. Begin with `/setup step:start`.';}
 // Work on a copy: failed checks and read-only previews must not change a running configuration.
 const c=structuredClone(getConfig(guildId)||emptyConfig());
 c.rosterLayout ||= {sections:{},placements:{},allowWholeRowInsertion:false};
 c.rosterLayout.sections ||= {};c.rosterLayout.placements ||= {};
 if(action==='start'){
  commitConfig(guildId,c,{preserveOwnership:true});
  return 'Setup started; existing configuration retained. Configure the MAIN roster with `/setup step:sheet value:YOUR_ROSTER_URL` and a DIFFERENT private data spreadsheet with `/setup step:data_sheet value:YOUR_PRIVATE_SHEET_URL`. Map membership, ranks and sections, link existing officers, then run `/setup step:preview` and `/setup step:finish`.';
 }
 if(action==='department'){const val=clean(interaction.options.getString('value'));if(!val||val.length>80)throw Error('Department name must be 1–80 characters');c.department=val;}
 else if(action==='membership'){c.requiredRoleId=roleFrom(interaction.options.getRole('role'));c.membershipRoleIds=[c.requiredRoleId];}
 else if(action==='rank'){
  const k=rankKey(interaction.options.getString('rank')),id=roleFrom(interaction.options.getRole('role'));
  const roleName=RANKS[k][0], entry={roleId:id,roleName:'SADLE '+roleName,label:roleName,level:RANKS[k][1],priority:RANKS[k][1]};
  // Existing role names may include pipes, punctuation or dotted department names.
  // Match the exact rank level, keeping Supervisor (45) and distinct HQ directors (>90).
  c.rankRoles=(c.rankRoles||[]).filter(e=>(rankLevel(e.roleName)||rankLevel(e.label))!==entry.level);
  if(c.rankRoles.some(e=>String(e.roleId)===id))throw Error('That Discord role is already mapped to another rank. Use a distinct role for each rank.');
  c.rankRoles.push(entry);
 }
 else if(action==='sheet'){
  const id=sheetId(interaction.options.getString('value'));
  if(id===c.spreadsheetId || id===c.personnelSpreadsheetId)throw Error('Main roster must be different from the private data and personnel spreadsheets.');
  if(id!==c.originalRosterSpreadsheetId){
   c.rosterLayout.placements={};delete c.backupAt;
  }
  c.originalRosterSpreadsheetId=id;
 }
 else if(action==='data_sheet'){
  const id=sheetId(interaction.options.getString('value'));
  if(id===c.originalRosterSpreadsheetId)throw Error('Data spreadsheet must NOT be the main roster.');
  await new GoogleSheetsClient(id,credentials).request('GET','?fields=spreadsheetId');
  if(id!==c.spreadsheetId)delete c.backupAt;
  c.spreadsheetId=id;
 }
 else if(action==='personnel_sheet'){
  const id=sheetId(interaction.options.getString('value'));
  if(id===c.originalRosterSpreadsheetId)throw Error('Personnel records cannot use the main roster spreadsheet.');
  await new GoogleSheetsClient(id,credentials).request('GET','?fields=spreadsheetId');
  c.personnelSpreadsheetId=id;
 }
 else if(action==='personnel_channel'){
  const val=clean(interaction.options.getString('value')).replace(/[<#>]/g,'');if(!validId(val))throw Error('Provide personnel channel ID');c.personnelLogChannelId=val;
 }
 else if(action==='channel'){
  const val=clean(interaction.options.getString('value')).replace(/[<#>]/g,'');if(!validId(val))throw Error('Provide a Discord channel ID (Copy Channel ID)');c.callsignChannelId=val;
 }
 else if(action==='section'||action==='remap'){
  const k=rankKey(interaction.options.getString('rank'));
  const tab=clean(interaction.options.getString('tab'));
  const start=interaction.options.getInteger('start_row'),end=interaction.options.getInteger('end_row');
  if(!tab||tab.length>100||!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<1||end<start)throw Error('Supply tab, start_row, end_row');
  const cols=columnsFrom(interaction.options.getString('columns'));
  const previous=c.rosterLayout.sections[k];
  const next={...previous,tab,startRow:start,endRow:end,columns:cols};
  if(next.templateRow && (next.templateRow<start||next.templateRow>end))delete next.templateRow;
  const changed=sectionSignature(previous)!==sectionSignature(next);
  const linked=Object.entries(c.rosterLayout.placements).filter(([,p])=>p.key===k);
  if(changed&&linked.length&&action!=='remap')throw Error('This section has linked officers. Use `/setup step:remap` with the new mapping to replace it, then link those officers again.');
  c.rosterLayout.sections[k]=next;
  if(action==='remap')for(const [id] of linked)delete c.rosterLayout.placements[id];
  validatedLayout(c.rosterLayout);
  if(changed||action==='remap')delete c.backupAt;
 }
 else if(action==='link'){
  const k=rankKey(interaction.options.getString('rank'));
  const target=interaction.options.getUser('officer');
  const row=interaction.options.getInteger('start_row');
  const section=c.rosterLayout.sections[k];
  if(!section||!validId(target?.id)||!Number.isSafeInteger(row)||row<section.startRow||row>section.endRow)
   throw Error('Map the rank section first, then provide officer and start_row (the exact existing officer row)');
  const checker=new CustomRosterMirror(null,c.originalRosterSpreadsheetId,credentials,c.rosterLayout,{mainRankEntry:()=>null,rankLevel:()=>0});
  await checker.prepare();
  const vals=await checker.rows(checker.sections[k]);
  const officerRow=vals[row-section.startRow]||[];
  const rawCall=clean(officerRow[checker.sections[k].indices.callsign]);
  const call=rawCall?(canonical(rawCall)||CallsignManager.cleanInput(rawCall)):null;
  const name=clean(officerRow[checker.sections[k].indices.name]);
  if(!call||call==='auto'||!name)throw Error('The selected row needs a valid callsign and officer name before linking; auto is not a saved callsign.');
  c.rosterLayout.placements[target.id]={key:k,tab:section.tab,row,callsign:call,name};
  // Recheck prospective links against current cells before saving them.
  checker.placements=c.rosterLayout.placements;
  await checker.validatePlacements();
 }
 else if(action==='unlink'){
  const target=interaction.options.getUser('officer');
  if(!validId(target?.id))throw Error('Choose the officer whose saved row link should be removed.');
  if(!c.rosterLayout.placements[target.id])throw Error('That officer has no saved row link.');
  delete c.rosterLayout.placements[target.id];
 }
 else if(action==='expand'){
  const value=clean(interaction.options.getString('value')).toLowerCase();
  if(!['on','off'].includes(value))throw Error('Use value:on or value:off');
  c.rosterLayout.allowWholeRowInsertion=value==='on';
 }
 else if(action==='preview')return await validateConfig(c);
 else if(action==='finish'){
  const details=await validateConfig(c);
  if(!c.backupAt){await backupCustomTabs(c);c.backupAt=new Date().toISOString();}
  c.enabled=true;c.configured=true;commitConfig(guildId,c);
  await startRoster(guildId);
  return 'Setup enabled. '+details+'\nUse `/sync` to reconcile or `/roster` to check the visible roster status.';
 }
 else if(action!=='disable')throw Error('Unknown setup step '+action);
 // Pause the old mapping after a saved edit; resume only after preview/finish validates the new one.
 c.enabled=false;c.configured=false;commitConfig(guildId,c);
 rosters.get(guildId)?.stop();rosters.delete(guildId);
 const note=action==='remap'?' Previous saved links for this rank were removed; sheet cells were unchanged.':
  action==='unlink'?' Only the saved link was removed; sheet cells were unchanged.':'';
 return 'Saved **'+action+'** for '+c.department+'.'+note+' '+statusText(guildId,c);
}
async function backupCustomTabs(c){
 // Google Sheets copyTo preserves the worksheet formatting, without creating
 // ANY additional worksheets or columns in the user's original roster.
 if(!c.spreadsheetId || c.spreadsheetId===c.originalRosterSpreadsheetId)
  throw Error('A separate private data spreadsheet is required for backups.');
 const origin=new GoogleSheetsClient(c.originalRosterSpreadsheetId,credentials);
 const dest=new GoogleSheetsClient(c.spreadsheetId,credentials);
 const meta=await origin.request('GET','?fields=sheets(properties(sheetId,title))');
 const stamp=new Date().toISOString().replace(/[-:TZ.]/g,'').slice(0,14);
 const tabs=[...new Set(Object.values(c.rosterLayout.sections).map(s=>s.tab))];
 if(!tabs.length)throw Error('No sections have been mapped');
 for(const tab of tabs){
  const source=(meta.sheets||[]).find(s=>s.properties.title===tab);
  if(!source)throw Error('Cannot back up missing sheet '+tab);
  const copied=await origin.request('POST',`/sheets/${source.properties.sheetId}:copyTo`,{destinationSpreadsheetId:dest.id});
  if(!Number.isInteger(copied.sheetId))throw Error('Separate-sheet backup failed for '+tab);
  const name=('ROSTER BACKUP '+stamp+' '+tab).slice(0,95);
  await dest.request('POST',':batchUpdate',{requests:[{updateSheetProperties:{properties:{sheetId:copied.sheetId,title:name,hidden:true},fields:'title,hidden'}}]});
 }
 return tabs.length;
}
async function validateConfig(c){
 if(!c.originalRosterSpreadsheetId)throw Error('Connect your existing roster using `/setup step:sheet value:YOUR_ROSTER_URL`.');
 if(!c.spreadsheetId)throw Error('Connect a SEPARATE private spreadsheet using `/setup step:data_sheet value:YOUR_PRIVATE_SHEET_URL`.');
 if(c.spreadsheetId===c.originalRosterSpreadsheetId)throw Error('Private data spreadsheet must differ from the main roster.');
 if(c.personnelSpreadsheetId===c.originalRosterSpreadsheetId)throw Error('Personnel spreadsheet must differ from the main roster.');
 if(!validId(c.requiredRoleId))throw Error('Configure membership role first.');
 if(!c.rankRoles?.length)throw Error('Map at least one LEO rank role.');
 if(!c.rosterLayout?.sections||!Object.keys(c.rosterLayout.sections).length)throw Error('Map custom roster sections before finishing.');
 const roleIds=new Set();
 for(const entry of c.rankRoles){
  if(!validId(entry.roleId)||roleIds.has(String(entry.roleId)))throw Error('Rank roles must have distinct valid Discord role IDs.');
  roleIds.add(String(entry.roleId));
 }
 const sheets=new GoogleSheetsClient(c.spreadsheetId,credentials);
 const checker=new CustomRosterMirror(sheets,c.originalRosterSpreadsheetId,credentials,c.rosterLayout,{mainRankEntry:()=>null,rankLevel:()=>0});
 const required=new Set(c.rankRoles.map(entry=>rankLevel(entry.roleName||entry.label)).filter(level=>level>0)
  .map(level=>checker.sectionFor(level).key));
 if(!required.size)throw Error('Map at least one recognized LEO rank role.');
 const missing=[...required].filter(key=>!checker.sections[key]);
 if(missing.length)throw Error('Map roster sections for configured ranks before finishing: '+missing.join(', '));
 await sheets.request('GET','?fields=spreadsheetId');
 if(c.personnelSpreadsheetId&&c.personnelSpreadsheetId!==c.spreadsheetId)
  await new GoogleSheetsClient(c.personnelSpreadsheetId,credentials).request('GET','?fields=spreadsheetId');
 await checker.prepare();const reads=await checker.readCallsigns();
 const duplicates=new Set(),seen=new Set();for(const entry of reads){if(seen.has(entry.call))duplicates.add(entry.call);seen.add(entry.call);}
 if(duplicates.size)throw Error('Duplicate existing callsigns in mapped roster: '+[...duplicates].slice(0,8).join(', '));
 const links=await checker.validatePlacements();
 await checker.validateWriteAccess();
 return `Main roster and private data spreadsheet accessible; ${Object.keys(c.rosterLayout.sections).length} rank sections mapped; ${reads.length} existing callsign positions detected; ${links.count} saved officer links checked. Validation changed no sheet cells. Run /setup step:finish to back up and enable synchronization.`;
}
function statusText(guildId,c){
 return `**${c.department||'Department'}** — ${c.enabled?'enabled':'setup in progress'}\n`+
 `Ranks: ${c.rankRoles?.length||0} | Rank sections: ${Object.keys(c.rosterLayout?.sections||{}).length} | Main roster: ${c.originalRosterSpreadsheetId?'configured':'missing'} | Private data: ${c.spreadsheetId?'configured':'missing'} | Log channel: ${c.callsignChannelId?'configured':'missing'}\n`+
 `Auto-expand: ${c.rosterLayout?.allowWholeRowInsertion?'enabled':'disabled (safe default)'}.\n`+
 `Personnel details: ${c.personnelSpreadsheetId?'separate personnel Sheet configured':'private data Sheet (not main roster)'} | Personnel Discord log: ${c.personnelLogChannelId?'configured':'disabled'}.\n`+
 `Next: map roles and sections, link existing officers with /setup step:link, run /setup step:preview, then /setup step:finish. Saved edits pause synchronization until finish. Use remap to replace a linked section or unlink to remove a saved officer link.`;
}
async function interactionHandler(interaction){
 if(!interaction?.isChatInputCommand?.())return;
 const gid=clean(interaction.guildId);if(!validId(gid))return;
 const cmd=interaction.commandName;
 if(!['promote','demote','callsign','setup','settings','sync','roster','editofficer','setsubdivision','certification','removeofficer','note','notes','strike','strikes','voidstrike','removestrike','appealstrike','officer'].includes(cmd))return;
 try{
  await interaction.deferReply({ephemeral:true});
  if(['setup','settings','sync'].includes(cmd)&&!canConfigureRoster(interaction.memberPermissions,interaction.user.id))throw Error('Only Discord administrators or members with Manage Server can configure/sync the roster.');
  if(cmd==='setup')return await interaction.editReply({content:await setup(gid,interaction)});
  if(cmd==='settings')return await interaction.editReply({content:statusText(gid,getConfig(gid)||emptyConfig())});
  const roster=rosters.get(gid);
  if(!roster)throw Error('Roster not configured for this server. An administrator must run /setup.');
  if(cmd==='roster')return await interaction.editReply({content:'Roster running. '+JSON.stringify(roster.status()).slice(0,1400)});
  if(cmd==='sync'){
   await roster.syncNow();const visibleError=roster.status().originalRoster?.lastError;
   return await interaction.editReply({content:visibleError?'Private records reconciled, but the visible roster needs attention: '+String(visibleError).slice(0,1400):'Roster reconciliation completed; no visible roster errors reported.'});
  }
  const user=interaction.options.getUser('officer');if(!user?.id)throw Error('Choose a valid Discord user');
  if(cmd==='callsign'){
   const value=await roster.setCallsign(interaction.user.id,user.id,interaction.options.getString('callsign'));
   return await interaction.editReply({content:`Callsign updated for <@${user.id}>: **${value}**`});
  }
  if(['editofficer','setsubdivision','certification','removeofficer','note','notes','strike','strikes','voidstrike','removestrike','appealstrike','officer'].includes(cmd)){
   const opts=interaction.options;const reason=opts.getString('reason')||'';
   const inputs=cmd==='editofficer'?{field:clean(opts.getString('field')).toLowerCase(),value:opts.getString('value'),reason}:
    cmd==='setsubdivision'?{subdivision:clean(opts.getString('subdivision')).toLowerCase()==='clear'?'':opts.getString('subdivision'),operation:clean(opts.getString('subdivision')).toLowerCase()==='clear'?'clear':opts.getString('action')||'add',reason}:
    cmd==='certification'?{operation:opts.getString('action'),certification:opts.getString('certification'),reason}:
    cmd==='removeofficer'?{reason}:
    cmd==='note'?{note:opts.getString('text')}:
    cmd==='strike'?{reason,severity:opts.getString('severity')||'Standard'}:
    ['voidstrike','removestrike','appealstrike'].includes(cmd)?{reason,strikeId:opts.getString('strike_id')}:{ };
   const answer=await roster.managePersonnel(cmd,interaction.user.id,user.id,inputs);
   const escapeMentions=x=>String(x??'').replace(/@/g,'@\u200b').replace(/`/g,'\u02cb');
   let response;
   if(cmd==='officer')response=`**Officer:** <@${user.id}>\nCallsign: ${escapeMentions(answer.call)}\nName: ${escapeMentions(answer.profile.nameOverride||answer.name)}\nSubdivision: ${escapeMentions(answer.profile.subdivision)||'—'}\nCertifications: ${escapeMentions(answer.profile.certifications.join(', '))||'—'}\nStatus: ${escapeMentions(answer.profile.status)||'—'}\nActive strikes: ${answer.activeStrikes} | Total strikes: ${answer.totalStrikes} | Notes: ${answer.noteCount}`;
   else if(cmd==='notes')response=`**Private notes for <@${user.id}> (${answer.length})**\n`+(answer.slice(-7).reverse().map(x=>`• ${x.at.slice(0,10)} — ${escapeMentions(x.text).slice(0,180)} (by <@${x.by}>)`).join('\n')||'No notes recorded.');
   else if(cmd==='strikes')response=`**Strikes for <@${user.id}>** — Active: ${answer.filter(x=>x.state==='Active').length}, All: ${answer.length}\n`+
     (answer.slice(-4).reverse().map(x=>{
       const original=`• **${x.state}** | ${x.severity} | Issued ${x.at.slice(0,10)}\nOriginal reason: ${escapeMentions(x.reason).slice(0,130)}`;
       const resolved=x.state==='Active'?'':`\n${x.state} reason: ${escapeMentions(x.resolutionReason||'Not recorded').slice(0,170)}\nBy: <@${x.resolvedBy}> | ${String(x.resolvedAt||'').slice(0,10)}`;
       return `${original}${resolved}\nID: \`${x.id}\``;
     }).join('\n\n')||'No strikes recorded.');
   else if(cmd==='note')response=`Note saved for <@${user.id}>. ${answer.rosterUpdated?'Existing main-roster Notes cell updated.':answer.rosterPending?'Main-roster Notes update pending; private note history saved.':'Existing Notes column not mapped; private note history saved.'} Note ID: \`${answer.id}\`.`;
   else if(cmd==='strike')response=`Strike recorded for <@${user.id}>. Active strikes: **${answer.count}**. ID: \`${answer.id}\`.`;
   else if(['voidstrike','removestrike','appealstrike'].includes(cmd))response=`Strike \`${answer.id}\` marked **${answer.state}** for <@${user.id}>.\n**Reason:** ${escapeMentions(answer.resolutionReason).slice(0,800)}\n**Recorded by:** <@${interaction.user.id}>\nActive strikes: **${answer.count}**. Original strike and resolution saved to the private personnel spreadsheet.${answer.mirrorPending?' Main roster count update pending.':''}`;
   else if(cmd==='removeofficer')response=`Removed ${answer.removedRoles} department/rank roles from <@${user.id}>. ${answer.syncPending?'Google Sheets roster sync is pending retry.':'Roster removal synchronized.'}`;
   else response=answer.changed===false?'No change needed.':`**${cmd}** completed for <@${user.id}>.${answer.mirrorPending?' The custom roster display could not be updated; bot-owned profile was saved.':''}`;
   return await interaction.editReply({content:response.slice(0,1850)});
  }
  const by=interaction.options.getUser('approved_by');
  const changed=await roster.changeRank(cmd,interaction.user.id,user.id,
   interaction.options.getString('rank'),interaction.options.getString('reason'),
   {type:interaction.options.getString('approval_type'),by:by?.id?'<@'+by.id+'>':'',vote:interaction.options.getString('vote_result')});
  return await interaction.editReply({content:`${cmd==='promote'?'Promoted':'Demoted'} <@${user.id}> to **${changed.rank}** (${changed.callsign}).${changed.syncPending?' Discord rank changed, but the Sheets update is still pending a retry.':''}`});
 }catch(e){
  const message='Command not completed: '+String(e?.message||e).slice(0,1300);
  try{await interaction.editReply({content:message});}catch(_){try{await interaction.reply({content:message,ephemeral:true});}catch(__){}}
 }
}
function status(){return {online,botName:client?.user?.username||null,startupError,guilds:[...rosters.keys()],rosters:Object.fromEntries([...rosters].map(([id,r])=>[id,r.status()]))};}
function consoleCommand(name,fn){if(typeof RegisterCommand!=='function')return;RegisterCommand(name,(source,args)=>{
 if(Number(source)!==0&&!(typeof IsPlayerAceAllowed==='function'&&IsPlayerAceAllowed(String(source),'gorp.roster.manage')))return;
 Promise.resolve().then(()=>fn(args)).catch(e=>err(name+': '+e.message));},false);}
consoleCommand('gorpsadlestatus',()=>log('STATUS '+JSON.stringify(status())));
consoleCommand('gorpsadlesync',async()=>{for(const r of rosters.values())await r.syncNow();log('All configured rosters synchronized.');});
consoleCommand('gorpsadlecalltest',async()=>{for(const r of rosters.values())await r.testCallsignChannel();});
consoleCommand('gorpsadlerostercheck',()=>log('STATUS '+JSON.stringify(status())));
async function startup(){
 try{
  privateBot=read('bot_config.private.json',{});
  legacy=read('sadleroaster/config.json',{});
  settings=read(FILE,{});
  token=setting('token','gorp_discord_token');
  const id=setting('clientId','gorp_discord_client_id');
  if(!token)throw Error('Missing bot token. Keep your existing bot_config.private.json when upgrading.');
  if(!validId(id))throw Error('Missing bot clientId in bot_config.private.json');
  credentials=read('google-service-account.json');
  await verifyBotIdentity(token,id);
  client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers,GatewayIntentBits.GuildModeration]});
  client.on(Events.Error,e=>err('Discord: '+e.message));
  client.on(Events.Warn,msg=>log('Gateway warning: '+msg));
  client.on(Events.InteractionCreate,interactionHandler);
  const guildIds=new Set();
  client.on('rawDiscordDispatch',p=>{
   if(p.t==='READY')for(const g of p.d.guilds||[])if(validId(g.id))guildIds.add(g.id);
   if(p.t==='GUILD_CREATE'&&validId(p.d.id)){guildIds.add(p.d.id);if(client.user)void registerCommands(p.d.id);}
  });
  client.on(Events.ClientReady,()=>{
   online=true;log('Connected as '+client.user.username);
   const home=setting('guildId','gorp_discord_guild_id');
   if(validId(home))guildIds.add(home);
   for(const id of Object.keys(settings))if(validId(id))guildIds.add(id);
   for(const id of guildIds){void registerCommands(id);void startRoster(id).catch(e=>err('Roster '+id+': '+e.message));}
  });
  client.on(Events.ShardDisconnect,()=>{online=false;});
  client.on(Events.ShardResume,()=>{online=true;});
  await client.login(token);
 }catch(e){startupError=String(e.message||e);err('STARTUP FAILED: '+startupError);}
}
if(typeof on==='function')on('onResourceStop',name=>{if(name!==R)return;for(const [id,r] of rosters){rosterGenerations.delete(id);r.stop();}client?.destroy();});
if(typeof LoadResourceFile==='function')void startup();
module.exports={startup,status,emptyConfig,columnsFrom,sheetId,rankKey,validateConfig,setup,commands,canConfigureRoster};
