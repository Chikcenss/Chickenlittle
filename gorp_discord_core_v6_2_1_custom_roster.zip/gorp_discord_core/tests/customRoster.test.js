'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {CustomRosterMirror,blankEntry,validatedSection,validatedLayout,indexToLetter}=require('../sadleroaster/customRoster');
const ID='100000000000000001',OTHER='100000000000000002';
const credentials={type:'service_account',client_email:'offline@example.invalid',private_key:'synthetic-unused-key'};
const ranks=[{roleId:'leo',label:'LEO',roleName:'LEO'},{roleId:'sergeant',label:'Sergeant',roleName:'Sergeant'}];
const helpers={mainRankEntry:(member,list)=>list.find(r=>member.roles.includes(r.roleId)),rankLevel:name=>name==='Sergeant'?50:20};
const officer=(id=ID,role='leo',name='New Officer')=>({user:{id,username:name},nick:name,roles:[role]});
const section=(extra={})=>({tab:'Roster',startRow:2,endRow:3,columns:{callsign:'A',name:'B',rank:'C',id:'D'},...extra});
const value=cell=>cell&&typeof cell==='object'?cell.value:cell??'';
const literal=cell=>cell&&typeof cell==='object'?cell.formula??cell.value:cell??'';
function column(letters){return [...letters].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;}
class Sheet{
 constructor(rows=[],extra={}){
  this.grid=[[],...rows];this.writes=[];this.reads=0;
  this.metadata={properties:{sheetId:1,title:'Roster',gridProperties:{rowCount:Math.max(10,this.grid.length),columnCount:20}},...extra};
 }
 range(text){
  const m=text.match(/^'Roster'!([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?$/);assert.ok(m,'Unexpected test range: '+text);
  return {row:Number(m[2])-1,lastRow:Number(m[4]||m[2]),col:column(m[1]),lastCol:column(m[3]||m[1])+1};
 }
 values(range,formula=false){
  const r=this.range(range),result=[];
  for(let i=r.row;i<r.lastRow;i++)result.push(Array.from({length:r.lastCol-r.col},(_,offset)=>(formula?literal:value)(this.grid[i]?.[r.col+offset])));
  return result;
 }
 async getValues(range){return this.values(range);}
 async request(method,suffix,body){
  if(method==='GET'&&suffix.startsWith('?')){
   this.reads++;
   if(suffix.includes('includeGridData'))return {sheets:[{data:[{rowMetadata:[{pixelSize:32}]}]}]};
   return {sheets:[structuredClone(this.metadata)]};
  }
  if(method==='GET'&&suffix.startsWith('/values/'))return {values:this.values(decodeURIComponent(suffix.split('?')[0].slice(8)),true)};
  if(method==='POST'&&suffix==='/values:batchUpdate'){
   this.writes.push(structuredClone(body));
   for(const change of body.data){const r=this.range(change.range);this.grid[r.row]||=[];this.grid[r.row][r.col]=change.values[0][0];}
   return {};
  }
  if(method==='POST'&&suffix===':batchUpdate'){
   this.writes.push(structuredClone(body));
   for(const request of body.requests){
    if(request.insertDimension){this.grid.splice(request.insertDimension.range.startIndex,0,[]);this.metadata.properties.gridProperties.rowCount++;}
    if(request.copyPaste?.pasteType==='PASTE_FORMULA'){
     const {source,destination}=request.copyPaste;
     for(const [col,cell] of (this.grid[source.startRowIndex]||[]).entries())if(cell&&typeof cell==='object'&&cell.formula){this.grid[destination.startRowIndex]||=[];this.grid[destination.startRowIndex][col]=structuredClone(cell);}
    }
   }
   return {};
  }
  throw Error('Unexpected offline Sheets request: '+method+' '+suffix);
 }
}
function fixture(rows,layout={},extra={}){
 const assigned=new Map([[ID,'K-01']]);
 const backend={getValues:async()=>[...assigned].map(([id,call])=>Array.isArray(call)?[id,...call]:[id,call])};
 const mirror=new CustomRosterMirror(backend,'synthetic_sheet',credentials,{sections:{leo:section()},placements:{},...layout},helpers);
 const target=new Sheet(rows,extra);mirror.target=target;
 return {mirror,target,assigned};
}

test('vacant mapped slots remain usable beside populated manual columns, while mapped notes protect occupancy',()=>{
 const s=validatedSection(section({columns:{callsign:'A',name:'B',id:'D',notes:'F'}}));
 assert.equal(blankEntry(['(X)K-01','','Manual academy date','','FALSE','','Other table'],s),true);
 assert.equal(blankEntry(['(X)K-01','','Manual academy date','','FALSE','Existing officer notes'],s),false);
 assert.equal(blankEntry(['K-01','Occupied officer','',''],s),false);
});

test('custom sync allocates an existing decorated slot and preserves unmapped dates and qualifications',async()=>{
 const {mirror,target}=fixture([['(X)K-01','','LEO','','2026-01-01',true,'Manual information']]);
 const result=await mirror.sync([officer()],ranks);
 assert.equal(result.skipped,0);
 assert.deepEqual(target.grid[1],['(X)K-01','New Officer','LEO',ID,'2026-01-01',true,'Manual information']);
 assert.equal(mirror.placements[ID].row,2);
 assert.ok(target.writes.every(body=>body.data?.every(change=>!/[EFG]2$/.test(change.range))));
});

test('an explicitly linked legacy row safely backfills its empty ID and updates its own name',async()=>{
 const placement={key:'leo',tab:'Roster',row:2,callsign:'K-01',name:'Linked Officer'};
 const {mirror,target}=fixture([['(X)K-01','Linked Officer','LEO','']],{placements:{[ID]:placement}});
 assert.deepEqual(await mirror.validatePlacements(),{count:1});
 await mirror.sync([officer(ID,'leo','Updated Officer')],ranks);
 assert.deepEqual(target.grid[1],['(X)K-01','Updated Officer','LEO',ID]);
 assert.equal(mirror.placements[ID].name,'Updated Officer');
});

test('a saved placement cannot rename or clear another officer who now owns the same callsign row',async()=>{
 const placement={key:'leo',tab:'Roster',row:2,callsign:'K-01',name:'Original Officer'};
 const {mirror,target}=fixture([['K-01','Other Officer','LEO',OTHER]],{placements:{[ID]:placement}});
 await assert.rejects(mirror.sync([officer()],ranks),/Discord ID does not match/);
 assert.equal(target.writes.length,0);
 const safe=fixture([['K-01','Original Officer','LEO',ID]],{placements:{[ID]:placement}});
 const found=await safe.mirror.findMember(ID);
 safe.target.grid[1][1]='Other Officer';safe.target.grid[1][3]=OTHER;
 await assert.rejects(safe.mirror.clearPlacements(found),/Discord ID does not match/);
 assert.equal(safe.target.writes.length,0);
});

test('a linked row without an ID mapping detects a replaced officer name before writing',async()=>{
 const s=section({columns:{callsign:'A',name:'B',rank:'C'}});
 const {mirror,target}=fixture([['K-01','Replacement Officer','LEO']],{sections:{leo:s},placements:{[ID]:{key:'leo',tab:'Roster',row:2,callsign:'K-01',name:'Original Officer'}}});
 await assert.rejects(mirror.sync([officer()],ranks),/identity changed/);
 assert.equal(target.writes.length,0);
});

test('linked occupied callsigns are attributed to the linked officer when there is no ID column',async()=>{
 const s=section({columns:{callsign:'A',name:'B',rank:'C'}});
 const {mirror}=fixture([['(X)K-01','Linked Officer','LEO']],{sections:{leo:s},placements:{[ID]:{key:'leo',tab:'Roster',row:2,callsign:'K-01',name:'Linked Officer'}}});
 const candidates=await mirror.callCandidates([officer()],ranks);
 assert.equal(candidates.usedByOthers.get('K-01'),ID);
 assert.deepEqual(candidates.candidates.get(ID),['K-01']);
});

test('duplicate mapped Discord IDs are refused instead of silently choosing a row',async()=>{
 const {mirror,target}=fixture([['K-01','Officer','LEO',ID],['K-02','Officer','LEO',ID]]);
 await assert.rejects(mirror.sync([officer()],ranks),/Duplicate (?:Discord ID|officer identity)/);
 assert.equal(target.writes.length,0);
});

test('sync and removal preserve formulas in mapped identity cells',async()=>{
 const linked={key:'leo',tab:'Roster',row:2,callsign:'K-01',name:'Formula Officer'};
 const {mirror,target}=fixture([['K-01',{value:'Formula Officer',formula:'=LOOKUP(A2)'},'LEO',ID]],{placements:{[ID]:linked}});
 await assert.rejects(mirror.sync([officer()],ranks),/replace formula/);
 assert.equal(target.writes.length,0);
 await assert.rejects(mirror.dropOne(ID),/replace formula/);
 assert.equal(target.writes.length,0);
 assert.equal(target.grid[1][1].formula,'=LOOKUP(A2)');
});

test('whole-sheet protection defaults block changed cells but explicit unprotected ranges allow them',async()=>{
 const protection={range:{sheetId:1}};
 const blocked=fixture([['K-01','','LEO','']],{}, {protectedRanges:[protection]});
 await assert.rejects(blocked.mirror.sync([officer()],ranks),/cell is protected/);
 assert.equal(blocked.target.writes.length,0);
 const allowed=fixture([['K-01','','LEO','']],{}, {protectedRanges:[{...protection,unprotectedRanges:[{sheetId:1,startRowIndex:1,endRowIndex:3,startColumnIndex:1,endColumnIndex:4}]}]});
 await allowed.mirror.sync([officer()],ranks);
 assert.equal(allowed.target.grid[1][1],'New Officer');
});

test('whole-sheet protection with omitted row bounds blocks whole-row insertion',async()=>{
 const {mirror,target}=fixture([['K-01','Existing','LEO',OTHER]],{allowWholeRowInsertion:true},{protectedRanges:[{range:{sheetId:1}}]});
 await assert.rejects(mirror.extendSection('leo'),/protected range/);
 assert.equal(target.writes.length,0);
});

test('expansion shifts later sections and placements and refreshes protection metadata',async()=>{
 const layout={allowWholeRowInsertion:true,sections:{leo:section({endRow:2}),sergeant:section({startRow:4,endRow:4})},placements:{[OTHER]:{key:'sergeant',tab:'Roster',row:4,callsign:'E-01',name:'Supervisor'}}};
 const {mirror,target}=fixture([['K-01','Existing','LEO',ID],[],['E-01','Supervisor','Sergeant',OTHER]],layout);
 const inserted=await mirror.extendSection('leo');
 assert.equal(inserted,3);
 assert.equal(mirror.sections.leo.endRow,3);
 assert.equal(mirror.sections.sergeant.startRow,5);
 assert.equal(mirror.placements[OTHER].row,5);
 assert.equal(mirror.meta,null);
 target.metadata.protectedRanges=[{range:{sheetId:1}}];
 await assert.rejects(mirror.extendSection('leo'),/protected range/);
 assert.ok(target.reads>=3);
});

test('mapping validation rejects overlapping managed cells and invalid dimensions while allowing side-by-side tables',async()=>{
 assert.throws(()=>validatedSection(section({startRow:Infinity})),/Invalid section/);
 assert.throws(()=>validatedSection(section({templateRow:2.5})),/template/);
 assert.throws(()=>validatedSection(section({columns:{callsign:'A',name:'A'}})),/Duplicate/);
 assert.throws(()=>validatedSection(section({columns:{callsign:'A',name:'B',unknown:'C'}})),/Unknown/);
 assert.throws(()=>indexToLetter(Infinity),/Invalid column/);
 assert.throws(()=>validatedLayout({sections:{leo:section(),sergeant:section()}}),/Overlapping/);
 assert.doesNotThrow(()=>validatedLayout({sections:{leo:section(),sergeant:section({columns:{callsign:'H',name:'I',rank:'J',id:'K'}})}}));
 const ordinary=fixture([['K-01','','LEO','']],{}, {merges:[{sheetId:1,startRowIndex:1,endRowIndex:3,startColumnIndex:6,endColumnIndex:7}]});
 await ordinary.mirror.prepare();
 const invalid=fixture([['K-01','','LEO','']],{}, {merges:[{sheetId:1,startRowIndex:1,endRowIndex:3,startColumnIndex:1,endColumnIndex:2}]});
 await assert.rejects(invalid.mirror.prepare(),/merged cells/);
});


test('promotion moves the officer and their notes while preserving old manual notes and unrelated cells',async()=>{
 const columns={callsign:'A',name:'B',rank:'C',id:'D',notes:'F'};
 const layout={sections:{leo:section({startRow:4,endRow:4,columns}),sergeant:section({startRow:2,endRow:2,columns})}};
 const {mirror,target,assigned}=fixture([['(X)E-01','','Sergeant','','Manual destination date',''],[],['(X)K-01','Officer','LEO',ID,'Original manual date','Original notes']],layout);
 assigned.set(ID,'E-01');
 await mirror.sync([officer(ID,'sergeant')],ranks);
 assert.deepEqual(target.grid[1],['(X)E-01','New Officer','Sergeant',ID,'Manual destination date','Original notes']);
 assert.deepEqual(target.grid[3],['(X)K-01','','LEO','','Original manual date','Original notes']);
 assert.equal(mirror.placements[ID].key,'sergeant');
 assert.equal(target.writes.length,1,'destination and source identities must commit in one batch');
 assert.ok(target.writes[0].data.some(change=>change.range.endsWith('B2')));
 assert.ok(target.writes[0].data.some(change=>change.range.endsWith('B4')));
});

test('an unmapped new rank preserves the officer instead of deleting their existing roster identity',async()=>{
 const {mirror,target}=fixture([['K-01','Officer','LEO',ID]]);
 await assert.rejects(mirror.sync([officer(ID,'sergeant')],ranks,{full:true}),/No custom roster section/);
 assert.equal(target.writes.length,0);
 assert.equal(target.grid[1][3],ID);
});

test('a rank-removal event clears the known mapped identity immediately while keeping manual notes',async()=>{
 const {mirror,target}=fixture([['K-01','Officer','LEO',ID,'Unmapped data']]);
 await mirror.sync([{...officer(),roles:[]}],ranks,{full:false});
 assert.deepEqual(target.grid[1],['K-01','','LEO','','Unmapped data']);
});


test('existing arbitrary manual callsigns keep their own identity and update names without comparing null keys',async()=>{
 const placement={key:'leo',tab:'Roster',row:2,callsign:'AIR-ONE',name:'Existing Officer'};
 const {mirror,target,assigned}=fixture([['AIR-ONE','Existing Officer','LEO',ID]],{placements:{[ID]:placement}});
 assigned.set(ID,['AIR-ONE','MANUAL']);
 await mirror.sync([officer()],ranks);
 assert.deepEqual(target.grid[1],['AIR-ONE','New Officer','LEO',ID]);
 assert.equal(mirror.placements[ID].callsign,'AIR-ONE');
 assert.equal((await mirror.findMember(ID)).length,1);
});

test('a changed manual identifier updates its verified owned row in place even with no vacant slots',async()=>{
 const {mirror,target,assigned}=fixture([['AIR-ONE','Existing Officer','LEO',ID]],{sections:{leo:section({endRow:2})}});
 assigned.set(ID,['COMMAND_[A]','MANUAL']);
 await mirror.sync([officer()],ranks);
 assert.deepEqual(target.grid[1],['COMMAND_[A]','New Officer','LEO',ID]);
 assert.equal(mirror.placements[ID].row,2);
 assert.equal(target.writes.length,1);
});

test('a new manual identifier on a decorated layout uses an unnumbered slot and never prints (X)null',async()=>{
 const {mirror,target,assigned}=fixture([['(X)K-01','','LEO',''],['','','LEO','']]);
 assigned.set(ID,['AIR-ONE','MANUAL']);
 await mirror.sync([officer()],ranks);
 assert.deepEqual(target.grid[1],['(X)K-01','','LEO','']);
 assert.deepEqual(target.grid[2],['AIR-ONE','New Officer','LEO',ID]);
 assert.equal(mirror.placements[ID].row,3);
});

test('manual allocation preserves unrelated printed vacancies when expansion is disabled',async()=>{
 const {mirror,target,assigned}=fixture([['(X)K-01','','LEO',''],['(X)K-02','','LEO','']]);
 assigned.set(ID,['AIR-ONE','MANUAL']);
 await assert.rejects(mirror.sync([officer()],ranks),/No unnumbered slot.*insertion is disabled/);
 assert.equal(target.writes.length,0);
});

test('a remembered manual callsign survives reload and removal while preserving its printed vacancy',async()=>{
 const {mirror,target,assigned}=fixture([['AIR-ONE','Existing Officer','LEO',ID]]);
 assigned.set(ID,['AIR-ONE','MANUAL']);await mirror.sync([officer()],ranks);
 const restored=new CustomRosterMirror(mirror.backend,'synthetic_sheet',credentials,structuredClone(mirror.layout),helpers);
 restored.target=target;
 assert.deepEqual(await restored.validatePlacements(),{count:1});
 await restored.dropOne(ID);
 assert.deepEqual(target.grid[1],['AIR-ONE','','LEO','']);
 assert.equal(restored.placements[ID],undefined);
});

test('occupied manual callsigns are reserved and cannot be assigned to a different officer',async()=>{
 const {mirror,target,assigned}=fixture([['AIR-ONE','Existing Officer','LEO',OTHER],['','','LEO','']]);
 assigned.set(ID,['air-one','MANUAL']);
 const slots=await mirror.callCandidates([officer()],ranks);
 assert.equal(slots.reserved.has('AIR-ONE'),true);
 assert.equal(slots.usedByOthers.get('AIR-ONE'),OTHER);
 await assert.rejects(mirror.sync([officer()],ranks),/belongs to another custom roster officer/);
 assert.equal(target.writes.length,0);
});

test('preview distinguishes valid manual identifiers from malformed parentheses without changing rows',async()=>{
 for(const malformed of ['(XI-55','X)G-39']){
  const {mirror,target}=fixture([[malformed,'Existing Officer','LEO',ID]]);
  await assert.rejects(mirror.readCallsigns(),/Malformed callsign.*balanced/);
  await assert.rejects(mirror.validatePlacements(),/Malformed callsign.*balanced/);
  assert.equal(target.writes.length,0);
 }
 const valid=fixture([['COMMAND_[A]','Existing Officer','LEO',ID]]);
 assert.equal((await valid.mirror.readCallsigns())[0].call,'COMMAND_[A]');
});

test('promotion preflights a protected source before writing or persisting the destination',async()=>{
 const layout={sections:{leo:section({startRow:4,endRow:4}),sergeant:section({startRow:2,endRow:2})}};
 const {mirror,target,assigned}=fixture([['E-01','','Sergeant',''],[],['K-01','Officer','LEO',ID]],layout,{protectedRanges:[{range:{sheetId:1,startRowIndex:3,endRowIndex:4,startColumnIndex:1,endColumnIndex:2}}]});
 assigned.set(ID,'E-01');let persisted=0;mirror.onLayoutChange=()=>{persisted++;};
 await assert.rejects(mirror.sync([officer(ID,'sergeant')],ranks),/protected/);
 assert.deepEqual(target.grid[1],['E-01','','Sergeant','']);
 assert.equal(target.writes.length,0);assert.equal(persisted,0);
});

test('promotion preflights a source identity formula before inserting a destination row',async()=>{
 const layout={allowWholeRowInsertion:true,sections:{leo:section({startRow:4,endRow:4}),sergeant:section({startRow:2,endRow:2})}};
 const {mirror,target,assigned}=fixture([['E-01','Other Supervisor','Sergeant',OTHER],[],['K-01',{value:'Officer',formula:'=LOOKUP(A4)'},'LEO',ID]],layout);
 assigned.set(ID,'E-02');let persisted=0;mirror.onLayoutChange=()=>{persisted++;};
 await assert.rejects(mirror.sync([officer(ID,'sergeant')],ranks),/replace formula/);
 assert.equal(target.writes.length,0);assert.equal(persisted,0);
 assert.equal(mirror.sections.sergeant.endRow,2);
});

test('preview checks mapped write permissions including whole-sheet unprotected exceptions',async()=>{
 const blocked=fixture([['K-01','','LEO','']],{}, {protectedRanges:[{range:{sheetId:1}}]});
 await assert.rejects(blocked.mirror.validateWriteAccess(),/protected in section leo/);
 const allowed=fixture([['K-01','','LEO','']],{}, {protectedRanges:[{range:{sheetId:1},unprotectedRanges:[{sheetId:1,startRowIndex:1,endRowIndex:3,startColumnIndex:0,endColumnIndex:4}]}]});
 assert.deepEqual(await allowed.mirror.validateWriteAccess(),{cells:8,sections:1});
 assert.equal(allowed.target.writes.length,0);
});

test('manual callsign override flows from the real allocation manager into the existing custom row',async()=>{
 const {CallsignManager}=require('../sadleroaster/callsigns');
 const calls=[[ID,'AIR-ONE','MANUAL','K','2026-01-01','2026-01-01','AUTO']];
 const details=[[ID,'AIR-ONE',...Array(16).fill('')]],audit=[];
 const privateSheets={
  getValues:async range=>structuredClone(range.startsWith("'Calls'!")?calls:range.startsWith("'Details'!")?details:[]),
  appendValues:async(_,rows)=>{audit.push(...rows);},
  request:async(method,suffix,body)=>{
   assert.equal(method,'POST');assert.equal(suffix,'/values:batchUpdate');assert.equal(body.valueInputOption,'RAW');
   for(const change of body.data){
    const m=change.range.match(/^'(Calls|Details)'!([A-Z]+)(\d+):([A-Z]+)(\d+)$/);assert.ok(m);
    const table=m[1]==='Calls'?calls:details,start=Number(m[3])-2,col=column(m[2]);
    for(const [offset,row] of change.values.entries()){
     table[start+offset]||=[];
     for(const [i,v] of row.entries())table[start+offset][col+i]=v;
    }
   }
  }
 };
 const {mirror,target}=fixture([['AIR-ONE','Existing Officer','LEO',ID]],{callsignTab:'Calls',sections:{leo:section({endRow:2})}});
 mirror.backend=privateSheets;
 const manager=new CallsignManager(privateSheets,{callsignTab:'Calls',callsignHistoryTab:'Audit',detailsTab:'Details',...helpers});
 const member=officer();
 const result=await manager.update([member],ranks,{id:ID,actor:OTHER,value:'COMMAND_[A]'},true,await mirror.callCandidates([member],ranks));
 assert.equal(result.callsign,'COMMAND_[A]');assert.equal(calls[0][2],'MANUAL');assert.equal(audit.length,1);
 await mirror.sync([member],ranks);
 assert.deepEqual(target.grid[1],['COMMAND_[A]','New Officer','LEO',ID]);
 assert.equal(mirror.placements[ID].row,2);
});
