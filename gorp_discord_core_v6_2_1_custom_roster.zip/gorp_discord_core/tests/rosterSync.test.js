'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {SadleRoster} = require('../sadleroaster/index');
const {targetOf, TAB} = require('../sadleroaster/originalRoster');

test('legacy adapter routes Senior LEO officers to the senior worksheet', () => {
  assert.equal(targetOf(10),TAB.pro);
  assert.equal(targetOf(20),TAB.leo);
  assert.equal(targetOf(30),TAB.sen);
  assert.equal(targetOf(40),TAB.cmd);
});

test('visible roster failure remains visible and a successful retry clears it', async () => {
  const roster=Object.create(SadleRoster.prototype);
  let blocked=true;
  roster.roleMappingReliable=true;roster.stats={};roster.cfg={guildId:'100000000000000001'};
  roster.originalRoster={stats:{},async sync(){if(blocked)throw Error('Mapped cells are protected');}};
  roster.personnel={profiles:async()=>new Map(),rows:async()=>[]};
  const failed=await roster.syncOriginalRankTabs([]);
  assert.equal(failed.success,false);
  assert.match(roster.stats.lastRosterSyncError,/protected/);
  assert.match(roster.originalRoster.stats.lastError,/protected/);
  blocked=false;
  assert.equal((await roster.syncOriginalRankTabs([])).success,true);
  assert.equal(roster.stats.lastRosterSyncError,null);
  assert.equal(roster.originalRoster.stats.lastError,null);
  assert.ok(roster.stats.lastRosterSyncSuccess);
});

function runtime() {
  const roster=Object.create(SadleRoster.prototype);
  const target={user:{id:'100000000000000002',username:'Synthetic officer'},roles:['leo']};
  const actor={user:{id:'100000000000000003'},roles:['sergeant']};
  Object.assign(roster,{roleMappingReliable:true,
    ranks:[{roleId:'leo',roleName:'SADLE LEO',label:'LEO'},{roleId:'sergeant',roleName:'SADLE Sergeant',label:'Sergeant'}],
    enqueue:async(_,fn)=>fn(),resolveRanks:async()=>{},isEligible:()=>true,
    discord:{fetchMember:async id=>id===actor.user.id?actor:target},
    activeRows:async()=>[],writeActive:async()=>{},syncCareer:async()=>{},
    callsigns:{update:async()=>({callsign:'K-05',announcements:[]})},
    announceCallsignChanges:async()=>{},originalRoster:{callCandidates:async()=>({})},
    syncOriginalRankTabs:async()=>({success:false,error:'Mapped cells are protected'})});
  return {roster,target,actor};
}

test('callsign command reports a pending visible update after backend assignment', async () => {
  const {roster,target,actor}=runtime();
  await assert.rejects(roster.setCallsign(actor.user.id,target.user.id,'K-05'),/saved in private data.*visible roster update is pending/);
});

test('rank event returns a visible-sync failure for promotion pending status', async () => {
  const {roster,target}=runtime();
  const result=await roster.refreshOne(target.user.id,target);
  assert.equal(result.success,false);
  assert.match(result.error,/protected/);
});
