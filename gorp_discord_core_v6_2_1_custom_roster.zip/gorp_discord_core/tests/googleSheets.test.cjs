'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const {generateKeyPairSync, verify} = require('node:crypto');
const sourceRoot = process.env.GORP_SOURCE_ROOT || path.resolve(__dirname, '..');
const {GoogleSheetsClient, quoteTab} = require(path.join(sourceRoot, 'sadleroaster/googleSheets.js'));

test('Google Sheets client authenticates and initializes, writes, and reads an offline roster', async t => {
  const {publicKey, privateKey} = generateKeyPairSync('rsa', {modulusLength: 2048});
  const credentials = {
    type: 'service_account',
    client_email: 'offline-roster@example.invalid',
    private_key: privateKey.export({type: 'pkcs8', format: 'pem'})
  };
  const sheetId = 'offline_roster';
  const state = new Map();
  let tokenRequests = 0;
  let sheetRequests = 0;
  const originalFetch = global.fetch;
  t.after(() => { global.fetch = originalFetch; });

  // This fake HTTP service never delegates to a real network implementation.
  global.fetch = async (input, options = {}) => {
    const url = new URL(String(input));
    assert.ok(options.signal instanceof AbortSignal, 'requests must have a timeout');
    if (url.href === 'https://oauth2.googleapis.com/token') {
      assert.equal(options.method, 'POST');
      const params = new URLSearchParams(options.body);
      assert.equal(params.get('grant_type'), 'urn:ietf:params:oauth:grant-type:jwt-bearer');
      const jwt = params.get('assertion');
      assert.ok(jwt, 'service-account grant must include a signed JWT');
      const [header, claims, signature, extra] = jwt.split('.');
      assert.equal(extra, undefined);
      assert.deepEqual(JSON.parse(Buffer.from(header, 'base64url')), {alg: 'RS256', typ: 'JWT'});
      assert.ok(verify('RSA-SHA256', Buffer.from(`${header}.${claims}`), publicKey, Buffer.from(signature, 'base64url')));
      const payload = JSON.parse(Buffer.from(claims, 'base64url'));
      assert.equal(payload.iss, credentials.client_email);
      assert.equal(payload.aud, url.href);
      assert.equal(payload.scope, 'https://www.googleapis.com/auth/spreadsheets');
      assert.ok(payload.iat <= Date.now() / 1000 && payload.exp > Date.now() / 1000);
      tokenRequests++;
      return Response.json({access_token: 'offline-only-token', expires_in: 3600});
    }

    assert.equal(url.origin, 'https://sheets.googleapis.com', 'unexpected request host');
    assert.equal(options.headers.Authorization, 'Bearer offline-only-token');
    const base = `/v4/spreadsheets/${sheetId}`;
    sheetRequests++;
    if (url.pathname === base && options.method === 'GET') {
      return Response.json({sheets: [...state.keys()].map((title, sheetId) => ({properties: {title, sheetId}}))});
    }
    if (url.pathname === `${base}:batchUpdate` && options.method === 'POST') {
      const body = JSON.parse(options.body);
      for (const request of body.requests) {
        assert.deepEqual(Object.keys(request), ['addSheet']);
        const {title} = request.addSheet.properties;
        assert.ok(!state.has(title), 'sheet creation must preserve existing sheets');
        state.set(title, []);
      }
      return Response.json({replies: body.requests.map(() => ({}))});
    }
    assert.ok(url.pathname.startsWith(`${base}/values/`), 'unexpected Sheets endpoint');
    const encoded = url.pathname.slice(`${base}/values/`.length);
    const append = encoded.endsWith(':append');
    const range = decodeURIComponent(append ? encoded.slice(0, -7) : encoded);
    const matched = /^'Roster'!A(\d*)\:C(\d*)$/.exec(range);
    assert.ok(matched, `unexpected offline range: ${range}`);
    assert.ok(state.has('Roster'));
    const rows = state.get('Roster');
    const from = matched[1] ? Number(matched[1]) - 1 : 0;
    const until = matched[2] ? Number(matched[2]) : rows.length;
    if (options.method === 'GET' && !append) {
      return Response.json({values: rows.slice(from, until)});
    }
    assert.equal(url.searchParams.get('valueInputOption'), 'RAW', 'roster content must remain literal text');
    const body = JSON.parse(options.body);
    if (options.method === 'PUT' && !append) {
      assert.equal(body.range, range);
      assert.equal(body.majorDimension, 'ROWS');
      rows.splice(from, body.values.length, ...body.values);
      return Response.json({updatedRows: body.values.length});
    }
    if (options.method === 'POST' && append) {
      assert.equal(url.searchParams.get('insertDataOption'), 'INSERT_ROWS');
      rows.push(...body.values);
      return Response.json({updates: {updatedRows: body.values.length}});
    }
    assert.fail(`unmatched offline request: ${options.method} ${url.pathname}`);
  };

  const client = new GoogleSheetsClient(sheetId, credentials);
  const headers = ['Discord ID', 'Officer', 'Callsign'];
  await client.ensureTabs({Roster: headers});
  const officer = ['100000000000000001', '=literal officer name', '(X)E-10'];
  await client.appendValues(`${quoteTab('Roster')}!A:C`, [officer]);
  assert.deepEqual(await client.getValues(`${quoteTab('Roster')}!A2:C`), [officer]);
  assert.deepEqual(state.get('Roster'), [headers, officer]);
  assert.equal(tokenRequests, 1, 'a cached access token should serve the entire workflow');
  assert.ok(sheetRequests >= 6, 'the workflow must exercise actual Sheets-client operations');
});
