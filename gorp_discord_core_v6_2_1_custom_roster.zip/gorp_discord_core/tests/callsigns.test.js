'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {CallsignManager} = require('../sadleroaster/callsigns');

const ALICE = '100000000000000001';
const BOB = '100000000000000002';
const member = id => ({user: {id, username: 'Officer ' + id.slice(-1)}});
const entry = (id, call, source = 'AUTO') => [id, call, source, 'E', 'assigned', 'updated', 'AUTO'];

function fixture(rows = [], details = []) {
  const state = {rows: structuredClone(rows), details: structuredClone(details), writes: [], audits: []};
  const sheets = {
    getValues: async range => structuredClone(range.startsWith("'Calls'") ? state.rows : state.details),
    request: async (method, suffix, body) => {
      assert.equal(method, 'POST');
      assert.equal(suffix, '/values:batchUpdate');
      assert.equal(body.valueInputOption, 'RAW');
      state.writes.push(...structuredClone(body.data));
      for (const data of body.data) {
        const match = /^'(Calls|Details)'!([AB])(\d+):?([BG])?(\d+)?$/.exec(data.range);
        assert.ok(match, 'Unexpected test write: ' + data.range);
        const target = match[1] === 'Calls' ? state.rows : state.details;
        const row = Number(match[3]) - 2;
        const column = match[2] === 'A' ? 0 : 1;
        data.values.forEach((values, offset) => {
          target[row + offset] ||= [];
          values.forEach((value, i) => { target[row + offset][column + i] = value; });
        });
      }
      return {};
    },
    appendValues: async (range, values) => { state.audits.push(...structuredClone(values)); },
  };
  const manager = new CallsignManager(sheets, {
    callsignTab: 'Calls', callsignHistoryTab: 'History', detailsTab: 'Details',
    mainRankEntry: () => ({label: 'Sergeant'}), rankLevel: () => 50,
  });
  return {manager, state};
}

function slots(candidates, reserved = [], owners = []) {
  return {candidates: new Map(candidates), reserved: new Set(reserved), usedByOthers: new Map(owners)};
}

test('decorated and zero-padded callsigns cannot belong to different officers', async () => {
  const {manager} = fixture([entry(ALICE, '(X)E-9'), entry(BOB, 'E-09')]);
  await assert.rejects(manager.data(), /Duplicate callsign/);
  const other = fixture([entry(ALICE, 'E-09')], [[BOB, '(X)E-9']]);
  await assert.rejects(other.manager.data(), /Duplicate callsign/);
});

test('the same officer may retain decorated display and normalized lookup values', async () => {
  const {manager} = fixture([entry(ALICE, '(X)E-9')], [[ALICE, 'E-09']]);
  const result = await manager.data();
  assert.equal(result.used.size, 1);
  assert.equal(result.used.get('E-09'), ALICE);
});

test('restart preserves a valid automatic assignment instead of taking an earlier vacant row', async () => {
  const {manager, state} = fixture([entry(ALICE, '(X)E-10')], [[ALICE, '(X)E-10']]);
  const result = await manager.update([member(ALICE)], [], null, true,
    slots([[ALICE, ['E-01', 'E-10']]], ['E-01', 'E-10'], [['E-10', ALICE]]));
  assert.equal(result.changed, 0);
  assert.equal(state.rows[0][1], '(X)E-10');
  assert.deepEqual(state.writes, []);
  assert.deepEqual(state.audits, []);
});

test('an occupied assignment is replaced with a genuinely free custom-roster slot', async () => {
  const {manager, state} = fixture([entry(ALICE, 'E-01')], [[ALICE, 'E-01']]);
  await manager.update([member(ALICE)], [], null, false,
    slots([[ALICE, ['E-01', 'E-02']]], ['E-01', 'E-02'], [['(X)E-01', 'LEGACY']]));
  assert.equal(state.rows[0][1], 'E-02');
});

test('a new manual override is claimed before the next automatic assignment in the batch', async () => {
  const {manager, state} = fixture();
  await manager.update([member(ALICE), member(BOB)], [], {id: ALICE, value: '(X)E-01', actor: ALICE}, false,
    slots([[ALICE, ['E-01', 'E-02']], [BOB, ['E-01', 'E-02']]], ['E-01', 'E-02']));
  assert.deepEqual(state.rows.map(row => row.slice(0, 2)), [[ALICE, '(X)E-01'], [BOB, 'E-02']]);
});

test('two new officers cannot claim one printed callsign in the same batch', async () => {
  const {manager, state} = fixture();
  await manager.update([member(ALICE), member(BOB)], [], null, false,
    slots([[ALICE, ['E-01']], [BOB, ['E-01']]], ['E-01']));
  assert.deepEqual(state.rows.map(row => row[1]), ['E-01', 'E-02']);
});

test('a manual override refuses another officer or legacy occupied roster position before writing', async () => {
  const {manager, state} = fixture();
  await assert.rejects(manager.update([member(ALICE)], [], {id: ALICE, value: '(X)E-1', actor: ALICE}, false,
    slots([], ['E-01'], [['E-01', 'LEGACY']])), /occupied in the mapped roster/);
  assert.deepEqual(state.writes, []);
  assert.deepEqual(state.audits, []);
});

test('release targets the original physical row after an empty row', async () => {
  const {manager, state} = fixture([[], entry(ALICE, 'E-01')], [[], [ALICE, 'E-01']]);
  assert.equal(await manager.release(ALICE), true);
  assert.equal(state.writes[0].range, "'Calls'!A3:G3");
  assert.equal(state.writes[1].range, "'Details'!B3");
  assert.deepEqual(state.rows[0], []);
  assert.equal(state.rows[1][0], ALICE);
  assert.equal(state.rows[1][1], '');
});

test('updating one sparse row does not move another officer into the gap', async () => {
  const {manager, state} = fixture([[], entry(ALICE, 'E-01'), [], entry(BOB, 'E-02')], [[ALICE, 'E-01'], [BOB, 'E-02']]);
  await manager.update([member(ALICE)], [], {id: ALICE, value: 'E-03', actor: ALICE});
  assert.equal(state.rows[1][0], ALICE);
  assert.equal(state.rows[1][1], 'E-03');
  assert.equal(state.rows[3][0], BOB);
  assert.equal(state.rows[3][1], 'E-02');
  assert.ok(state.rows[0].every(value => value === ''));
  assert.ok(state.rows[2].every(value => value === ''));
});

test('unlinked populated callsign cells remain reserved instead of allocating a duplicate', async () => {
  const {manager, state} = fixture([['', '(X)E-01']], [['', 'E-02', 'manual notes']]);
  await manager.update([member(ALICE)], []);
  assert.equal(state.rows[0][1], '(X)E-01');
  assert.equal(state.rows[1][1], 'E-03');
  assert.equal(state.details[0][2], 'manual notes');
});

test('arbitrary supported manual identifiers remain manual across synchronization', async () => {
  assert.equal(CallsignManager.cleanInput('command_[a]'), 'COMMAND_[A]');
  const {manager, state} = fixture([entry(ALICE, 'COMMAND_[A]', 'MANUAL')], [[ALICE, 'COMMAND_[A]']]);
  const result = await manager.update([member(ALICE)], [], null, true,
    slots([[ALICE, ['E-01']]], ['E-01']));
  assert.equal(result.changed, 0);
  assert.equal(state.rows[0][1], 'COMMAND_[A]');
  assert.deepEqual(state.writes, []);
});

for (const malformed of ['(XI-55', 'X)G-39']) {
  test('malformed roster decorator ' + malformed + ' is rejected', () => {
    assert.throws(() => CallsignManager.cleanInput(malformed), /must be balanced/);
  });
}

test('manual callsigns support balanced decorations and reject broken bracket pairs', () => {
  for (const valid of ['AIR-ONE', '(VIP)', '[HQ]', '(X)G-39', 'COMMAND_[A]']) {
    assert.equal(CallsignManager.cleanInput(valid.toLowerCase()), valid);
  }
  for (const invalid of ['[HQ', 'HQ]', '([HQ)]']) {
    assert.throws(() => CallsignManager.cleanInput(invalid), /must be balanced/);
  }
});
