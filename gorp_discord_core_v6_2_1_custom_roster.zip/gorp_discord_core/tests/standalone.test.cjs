'use strict';
// Offline application startup check. All service responses and credentials are synthetic.
const assert = require('node:assert/strict');
const path = require('node:path');
const ROOT = path.resolve(process.env.GORP_SOURCE_ROOT || path.resolve(__dirname, '..'));

if (process.argv.includes('--offline-child')) {
  runChild().catch(error => { console.error(error.stack); process.exit(1); });
} else {
  const test = require('node:test');
  const {spawnSync} = require('node:child_process');
  test('standalone starts, synchronizes a synthetic officer, and answers /roster offline', () => {
    const child = spawnSync(process.execPath, [__filename, '--offline-child'], {
      env: {...process.env, GORP_SOURCE_ROOT: ROOT}, encoding: 'utf8', timeout: 15000,
    });
    assert.equal(child.error, undefined, child.error?.message);
    assert.equal(child.status, 0, child.stdout + child.stderr);
    assert.equal(child.stderr, '', child.stderr);
    const match = child.stdout.match(/^OFFLINE_STARTUP_RESULT (.+)$/m);
    assert.ok(match, child.stdout);
    const report = JSON.parse(match[1]);
    assert.equal(report.online, true);
    assert.equal(report.initialSync, true);
    assert.equal(report.checkedMembers, 1);
    assert.equal(report.eligibleMembers, 1);
    assert.equal(report.callsign, 'K-01');
    assert.ok(report.commands.includes('roster'));
    assert.ok(report.commands.includes('promote'));
    assert.equal(report.interactionDeferredPrivately, true);
    assert.equal(report.replyContainsRunningRoster, true);
    assert.equal(report.unmatchedRequests, 0);
    assert.equal(report.shutdown, true);
  });
}

async function runChild() {
  process.on('unhandledRejection', error => { throw error; });
  const fs = require('node:fs');
  const {generateKeyPairSync} = require('node:crypto');
  const {EventEmitter} = require('node:events');
  const BOT = '100000000000000001', GUILD = '100000000000000002';
  const MEMBER = '100000000000000003', MEMBERSHIP = '100000000000000004';
  const RANK = '100000000000000005';
  const {privateKey} = generateKeyPairSync('rsa', {modulusLength: 2048});
  const credentials = {
    type: 'service_account', client_email: 'offline@example.invalid',
    private_key: privateKey.export({type:'pkcs8', format:'pem'}),
  };
  const syntheticFiles = new Map([
    [path.join(ROOT, 'bot_config.private.json'), {token:'offline-synthetic-token', clientId:BOT, guildId:GUILD}],
    [path.join(ROOT, 'google-service-account.json'), credentials],
    [path.join(ROOT, 'sadleroaster/config.json'), {}],
    [path.join(ROOT, 'guild_roster_settings.private.json'), {[GUILD]: {
      enabled:true, configured:true, department:'Offline department',
      spreadsheetId:'offline_private_data', requiredRoleId:MEMBERSHIP, membershipRoleIds:[MEMBERSHIP],
      rankRoles:[{roleId:RANK,roleName:'SADLE LEO 1',label:'LEO 1',level:20,priority:20}],
      reconcileSeconds:90,
    }}],
  ]);
  const originalRead = fs.readFileSync.bind(fs), originalExists = fs.existsSync.bind(fs);
  fs.readFileSync = function(file, options) {
    const p = typeof file === 'string' ? path.resolve(file) : null;
    if (syntheticFiles.has(p)) {
      const json=JSON.stringify(syntheticFiles.get(p));
      return options ? json : Buffer.from(json);
    }
    // Never read additional real credential or runtime-settings files.
    if (p && /(?:private\.json|google-service-account\.json)$/.test(p)) throw Error('Unexpected private-file read');
    return originalRead(file, options);
  };
  fs.existsSync = file => typeof file === 'string' && syntheticFiles.has(path.resolve(file)) || originalExists(file);
  fs.writeFileSync = () => { throw Error('Offline startup must not write application files'); };
  const intervals = new Set(), originalSetInterval = global.setInterval;
  global.setInterval = (...args) => { const timer=originalSetInterval(...args); intervals.add(timer); return timer; };
  let instance;
  const adapter = require(path.join(ROOT, 'discord_local.js'));
  const RealClient = adapter.Client;
  adapter.Client = class extends RealClient { constructor(...args){super(...args);instance=this;} };
  const calls = [], commands = [], sheets = new Map();
  let deferred=false, reply='', unmatched=0, socket;
  // Existing officer-details tab, as supplied by a configured installation.
  sheets.set('BOT Officer Details', {sheetId:1, rows:[['Discord ID','Callsign']]});
  const data = value => ({ok:true,status:200,json:async()=>value});
  const column = letters => [...letters].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;
  const parse = range => {
    const m=range.match(/^'((?:[^']|'')+)'!([A-Z]+)(\d*)?(?::([A-Z]+)(\d*)?)?$/);
    assert.ok(m, 'Unhandled synthetic range: '+range);
    const tab=m[1].replace(/''/g,"'");
    assert.ok(sheets.has(tab),'Unknown synthetic tab: '+tab);
    return {sheet:sheets.get(tab), row:Math.max(0,Number(m[3]||1)-1), col:column(m[2]),
      endRow:m[5]?Number(m[5]):null, endCol:column(m[4]||m[2])};
  };
  const write=(range,values,append=false)=>{
    const p=parse(range);const row=append?p.sheet.rows.length:p.row;
    for(let i=0;i<values.length;i++) {
      p.sheet.rows[row+i] ||= [];
      for(let j=0;j<values[i].length;j++)p.sheet.rows[row+i][p.col+j]=values[i][j];
    }
  };
  global.fetch = async (input, options={}) => {
    const u=new URL(String(input)), method=options.method||'GET';
    const body=typeof options.body==='string' && /^[\[{]/.test(options.body)?JSON.parse(options.body):undefined;
    calls.push({host:u.hostname,path:u.pathname,method});
    if(u.origin==='https://discord.com' && u.pathname==='/api/v10/users/@me' && method==='GET')
      return data({id:BOT,bot:true,username:'offline-bot'});
    if(u.origin==='https://discord.com' && u.pathname==='/api/v10/gateway/bot' && method==='GET')
      return data({url:'wss://offline.invalid'});
    if(u.origin==='https://discord.com' && u.pathname===`/api/v10/applications/${BOT}/guilds/${GUILD}/commands` && method==='PUT') {
      assert.ok(Array.isArray(body)); commands.push(...body.map(c=>c.name)); return data(body);
    }
    if(u.origin==='https://discord.com' && u.pathname===`/api/v10/guilds/${GUILD}/roles` && method==='GET')
      return data([{id:RANK,name:'SADLE LEO 1',position:1},{id:MEMBERSHIP,name:'SADLE',position:0}]);
    if(u.origin==='https://discord.com' && u.pathname===`/api/v10/guilds/${GUILD}/members` && method==='GET')
      return data([{user:{id:MEMBER,username:'offline-officer',bot:false},nick:'Offline Officer',roles:[MEMBERSHIP,RANK]}]);
    if(u.origin==='https://discord.com' && u.pathname==='/api/v10/interactions/offline-interaction/offline-interaction-token/callback' && method==='POST') {
      assert.equal(body.type,5);assert.equal(body.data.flags,64);deferred=true;return data({});
    }
    if(u.origin==='https://discord.com' && u.pathname===`/api/v10/webhooks/${BOT}/offline-interaction-token/messages/@original` && method==='PATCH') {
      assert.ok(deferred);reply=body.content;return data({});
    }
    if(u.href==='https://oauth2.googleapis.com/token' && method==='POST') {
      assert.ok(String(options.body).includes('jwt-bearer'));return data({access_token:'offline-access-token',expires_in:3600});
    }
    if(u.origin==='https://sheets.googleapis.com' && u.pathname==='/v4/spreadsheets/offline_private_data' && method==='GET')
      return data({sheets:[...sheets].map(([title,s])=>({properties:{title,sheetId:s.sheetId}}))});
    if(u.origin==='https://sheets.googleapis.com' && u.pathname==='/v4/spreadsheets/offline_private_data:batchUpdate' && method==='POST') {
      for(const r of body.requests){assert.ok(r.addSheet);const title=r.addSheet.properties.title;assert.ok(!sheets.has(title));sheets.set(title,{sheetId:sheets.size+1,rows:[]});}
      return data({});
    }
    if(u.origin==='https://sheets.googleapis.com' && u.pathname==='/v4/spreadsheets/offline_private_data/values:batchUpdate' && method==='POST') {
      for(const d of body.data)write(d.range,d.values);return data({});
    }
    if(u.origin==='https://sheets.googleapis.com' && u.pathname.startsWith('/v4/spreadsheets/offline_private_data/values/')) {
      const encoded=u.pathname.slice('/v4/spreadsheets/offline_private_data/values/'.length);
      const append=encoded.endsWith(':append'),range=decodeURIComponent(append?encoded.slice(0,-7):encoded);
      if(method==='GET') {const p=parse(range);return data({values:p.sheet.rows.slice(p.row,p.endRow||p.sheet.rows.length).map(r=>r.slice(p.col,p.endCol+1))});}
      if(method==='PUT'||method==='POST'&&append){write(range,body.values,append);return data({});}
    }
    unmatched++;
    throw Error('Denied unmatched offline request: '+method+' '+u.origin+u.pathname);
  };
  class FakeWebSocket extends EventEmitter {
    constructor(url){super();assert.equal(new URL(url).hostname,'offline.invalid');this.readyState=1;socket=this;
      setImmediate(()=>this.packet({op:10,d:{heartbeat_interval:45000}}));}
    addEventListener(name,fn){this.on(name,fn);}
    packet(p){this.emit('message',{data:JSON.stringify(p)});}
    send(raw){const p=JSON.parse(raw);if(p.op===1)setImmediate(()=>this.packet({op:11}));
      else if(p.op===2){assert.equal(p.d.token,'offline-synthetic-token');assert.equal(p.d.intents,7);
        setImmediate(()=>this.packet({op:0,t:'READY',s:1,d:{session_id:'offline-session',resume_gateway_url:'wss://offline.invalid',user:{id:BOT,username:'offline-bot'},guilds:[{id:GUILD}]}}));}
      else throw Error('Unexpected offline gateway operation '+p.op);}
    close(){this.readyState=3;this.emit('close',{code:1000});}
  }
  global.WebSocket=FakeWebSocket;
  require(path.join(ROOT,'standalone.js'));
  const app=require(path.join(ROOT,'server.js'));
  const waitFor=async predicate=>{
    const end=Date.now()+5000;
    while(!predicate()){assert.ok(Date.now()<end,'Offline startup timed out: '+JSON.stringify(app.status()));await new Promise(r=>setTimeout(r,10));}
  };
  await waitFor(()=>app.status().rosters[GUILD]?.lastCheckSuccess && commands.length>0);
  const before=app.status();
  assert.equal(before.startupError,null);
  assert.equal(before.rosters[GUILD].lastError,null);
  assert.equal(before.rosters[GUILD].eligibleMembers,1);
  assert.equal(sheets.get('BOT Active').rows[1][0],MEMBER);
  assert.equal(sheets.get('BOT Career').rows[1][0],MEMBER);
  const callsign=sheets.get('BOT Callsigns').rows[1][1];
  assert.equal(sheets.get('BOT Officer Details').rows[1][1],callsign);
  socket.packet({op:0,t:'INTERACTION_CREATE',s:2,d:{id:'offline-interaction',token:'offline-interaction-token',application_id:BOT,guild_id:GUILD,type:2,member:{user:{id:MEMBER},permissions:'0'},data:{name:'roster',options:[]}}});
  await waitFor(()=>reply.length>0);
  assert.ok(reply.startsWith('Roster running. '));
  const replied=JSON.parse(reply.slice('Roster running. '.length));
  assert.equal(replied.running,true);assert.equal(replied.eligibleMembers,1);assert.equal(replied.lastError,null);
  instance.destroy();for(const timer of intervals)clearInterval(timer);
  assert.equal(instance.stopped,true);assert.equal(socket.readyState,3);
  console.log('OFFLINE_STARTUP_RESULT '+JSON.stringify({online:before.online,initialSync:Boolean(before.rosters[GUILD].lastCheckSuccess),checkedMembers:before.rosters[GUILD].checkedMembers,eligibleMembers:before.rosters[GUILD].eligibleMembers,callsign,commands,interactionDeferredPrivately:deferred,replyContainsRunningRoster:true,unmatchedRequests:unmatched,shutdown:true,mockedRequests:calls.length}));
}
