'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {canonical}=require('../sadleroaster/customRoster');
const {OriginalRosterMirror}=require('../sadleroaster/originalRoster');
test('custom roster treats decorated (X) codes as the same callsigns',()=>{
 assert.equal(canonical('(X)E-09'),'E-09');
 assert.equal(canonical('(X)C-40'),'C-40');
 assert.equal(canonical('G-9'),'G-09');
});
test('original roster recognizes decorated codes without renumbering',()=>{
 assert.equal(OriginalRosterMirror.canonicalCall('(X)E-10'),'E-10');
 assert.equal(OriginalRosterMirror.canonicalCall('(X)G-99'),'G-99');
});
