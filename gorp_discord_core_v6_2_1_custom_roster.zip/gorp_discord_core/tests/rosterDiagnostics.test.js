'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {analyzeRoster, editable} = require('../sadleroaster/rosterDiagnostics');
const {readOnly, effectiveConfig} = require('../scripts/verify-roster');
const section = {tab:'Custom officers',startRow:9,endRow:10,columns:{callsign:'B',name:'C',rank:'D',id:'K',notes:'I'}};
const row = (call, name='', id='') => {
  const cells=Array(11).fill('');cells[1]=call;cells[2]=name;cells[3]='Probationary Officer';cells[10]=id;return cells;
};

test('roster audit accepts decorated slots and preserves manual unmapped columns', () => {
  const vacant=row('(X)M-02');vacant[9]='manual hire date';
  const result=analyzeRoster({sections:{probationary:section}}, {sheets:[{properties:{title:section.tab}}]},
    {probationary:[row('(X)M-01','Synthetic officer','100000000000000001'),vacant]});
  assert.equal(result.ok,true);
  assert.deepEqual(result.totals,{sections:1,slots:2,occupied:1,vacant:1});
});

test('roster audit reports duplicate identity locations without exposing names or IDs', () => {
  const id='100000000000000001';
  const result=analyzeRoster({sections:{probationary:section}}, {sheets:[{properties:{title:section.tab}}]},
    {probationary:[row('(X)M-01','Private person',id),row('(X)M-02','Private person',id)]});
  const duplicate=result.issues.find(x=>x.code==='DUPLICATE_DISCORD_ID');
  assert.deepEqual(duplicate.locations.map(p=>p.row),[9,10]);
  assert.equal(result.ok,false);
  assert.ok(!JSON.stringify(result).includes(id));
  assert.ok(!JSON.stringify(result).includes('Private person'));
});

test('whole-sheet protection and unprotected exceptions use Google range defaults', () => {
  const sheet={protectedRanges:[{range:{sheetId:1},unprotectedRanges:[{startRowIndex:8,endRowIndex:10,startColumnIndex:2,endColumnIndex:3}]}]};
  assert.equal(editable(sheet,8,2),true);
  assert.equal(editable(sheet,8,10),false);
  assert.equal(editable(sheet,10,2),false);
  const result=analyzeRoster({sections:{probationary:section}},new Map([[section.tab,sheet]]),{probationary:[row('M-01'),row('M-02')]});
  assert.ok(result.issues.some(i=>i.code==='PROTECTED_CELLS' && i.message.includes('id')));
  sheet.protectedRanges[0].requestingUserCanEdit=true;
  assert.equal(editable(sheet,8,10),true);
});

test('verification client refuses writes before invoking the actual transport', async () => {
  const calls=[];const client=readOnly({request:async(...args)=>{calls.push(args);return {};}});
  await client.request('GET','?fields=spreadsheetId');
  assert.throws(()=>client.request('POST',':batchUpdate',{}),/refuses spreadsheet writes/);
  assert.equal(calls.length,1);
});

test('verification selects the same saved guild mapping and prefix fallback as the bot', () => {
  const guild='100000000000000001';
  const legacy={rosterLayout:{sections:{probationary:section}},callsignPrefixes:{leo:'CUSTOM'}};
  const saved={[guild]:{rosterLayout:{sections:{}},spreadsheetId:'different_backend'}};
  const selected=effectiveConfig(legacy,saved,guild);
  assert.equal(selected.source,'saved guild configuration');
  assert.equal(selected.config.spreadsheetId,'different_backend');
  assert.deepEqual(selected.config.rosterLayout.sections,{});
  assert.deepEqual(selected.config.callsignPrefixes,legacy.callsignPrefixes);
  assert.throws(()=>effectiveConfig(legacy,saved,''),/Select the Discord guild/);
  assert.throws(()=>effectiveConfig(legacy,saved,guild,'100000000000000002'),/no saved/);
});

test('audit recognizes supported manual identifiers without false missing-callsign errors', () => {
  const result=analyzeRoster({sections:{probationary:section}}, {sheets:[{properties:{title:section.tab}}]},
    {probationary:[row('AIR-ONE','Synthetic officer','100000000000000001'),row('M-02')]});
  assert.equal(result.ok,true);
  assert.equal(result.totals.slots,2);
});
