'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {EventEmitter} = require('node:events');
const adapter = require('../discord_local');
const {rankLevel} = require('../sadleroaster/index');
const {canonical, CustomRosterMirror} = require('../sadleroaster/customRoster');
const {CallsignManager} = require('../sadleroaster/callsigns');
const ROOT = path.resolve(__dirname, '..');
const GUILD = '100000000000000001';
const OFFICER = '100000000000000002';
const OTHER = '100000000000000003';
const ROLE = '100000000000000004';
const SERGEANT = '100000000000000005';
const clone = value => JSON.parse(JSON.stringify(value));

function layout() {
  return {sections: {leo: {tab: 'Custom roster', startRow: 2, endRow: 4,
    columns: {callsign: 'A', name: 'B', id: 'C'}}}, placements: {}, allowWholeRowInsertion: false};
}
function configuration() {
  return {department: 'Test department', requiredRoleId: ROLE, membershipRoleIds: [ROLE],
    originalRosterSpreadsheetId: 'synthetic_main_roster', spreadsheetId: 'synthetic_private_data',
    rankRoles: [{roleId: ROLE, roleName: 'SADLE LEO 1', label: 'LEO 1'}],
    rosterLayout: layout(), enabled: true, configured: true};
}
function interaction(values) {
  return {options: {getString: name => values[name] ?? null,
    getInteger: name => values[name] ?? null, getRole: name => values[name] ?? null,
    getUser: name => values[name] ?? null}};
}

// Only the server configuration workflow is under test. Service boundaries are
// synthetic; CustomRosterMirror's actual mapping and sync tests live separately.
async function loadServer({config = configuration(), legacy = null} = {}) {
  const state = {saved: null, saves: 0, failSave: false, requests: [], mirrorChecks: [],
    denied: null, placementError: null, writeAccessError: null, stops: 0, installs: [], callsigns: [{call: 'K-07'}],
    rows: [['(X)K-07', 'Existing Officer', '']]};
  class Sheets {
    constructor(id) { this.id = id; }
    async request(method, suffix, body) {
      state.requests.push({id: this.id, method, suffix, body});
      if (this.id === state.denied) throw Error('Private data spreadsheet is inaccessible');
      if (method === 'GET' && suffix.includes('sheets(properties'))
        return {sheets: [{properties: {sheetId: 10, title: 'Custom roster'}}]};
      if (method === 'POST' && suffix.endsWith(':copyTo')) return {sheetId: 20};
      return {spreadsheetId: this.id};
    }
  }
  class Mirror {
    constructor(backend, sheetId, credentials, mapped) {
      this.sections = Object.fromEntries(Object.entries(mapped.sections || {}).map(([key, section]) => [key,
        {...section, indices: Object.fromEntries(Object.entries(section.columns).map(([field, column]) => [field, column.charCodeAt(0) - 65]))}]));
      this.placements = mapped.placements || {};
    }
    sectionFor(level) { return CustomRosterMirror.prototype.sectionFor.call(this, level); }
    async prepare() { state.mirrorChecks.push('prepare'); }
    async readCallsigns() { state.mirrorChecks.push('callsigns'); return state.callsigns; }
    async rows() { return state.rows; }
    async validatePlacements() {
      state.mirrorChecks.push('placements');
      if (state.placementError) throw Error(state.placementError);
      return {count: Object.keys(this.placements).length};
    }
    async validateWriteAccess() {
      state.mirrorChecks.push('permissions');
      if (state.writeAccessError) throw Error(state.writeAccessError);
      return {cells: 9, sections: 1};
    }
  }
  class Client extends EventEmitter {
    async login() { state.client = this; this.user = {id: OTHER, username: 'offline'}; return 'offline'; }
  }
  class REST { setToken() { return this; } async put() { return []; } }
  const modules = {
    './bot_identity': {verifyBotIdentity: async () => ({})},
    './discord_local': {...adapter, Client, REST},
    './sadleroaster/index': {rankLevel, installSadleRosterSync: (client, options) => {
      const roster = {stop() { state.stops++; }, status() { return {originalRoster: {lastError: null}}; }};
      state.installs.push({roster, options}); return roster;
    }},
    './sadleroaster/customRoster': {CustomRosterMirror: Mirror, canonical,
      validatedLayout: value => value.sections},
    './sadleroaster/callsigns': {CallsignManager},
    './sadleroaster/googleSheets': {GoogleSheetsClient: Sheets},
    './sadleroaster/testOverride': {isTestingOverride: () => false},
  };
  const module = {exports: {}};
  const context = vm.createContext({module, exports: module.exports, Buffer, structuredClone,
    console: {log() {}, error() {}}, require(name) {
      assert.ok(Object.hasOwn(modules, name), 'unexpected server import: ' + name);
      return modules[name];
    }});
  new vm.Script(fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8'), {filename: 'server.js'}).runInContext(context);
  const syntheticLegacy = legacy || {
    ...configuration(), ranks: configuration().rankRoles,
    membershipRoles: [{roleId: ROLE}],
  };
  const files = {'bot_config.private.json': {token: 'synthetic-only-token', clientId: OTHER, guildId: GUILD},
    'google-service-account.json': {type: 'service_account'}, 'sadleroaster/config.json': syntheticLegacy,
    'guild_roster_settings.private.json': config ? {[GUILD]: config} : {}};
  context.LoadResourceFile = (_, name) => Object.hasOwn(files, name) ? JSON.stringify(files[name]) : null;
  context.SaveResourceFile = (_, name, data) => {
    if (state.failSave) throw Error('Local settings write failed');
    assert.equal(name, 'guild_roster_settings.private.json');
    state.saves++; state.saved = JSON.parse(data); return true;
  };
  await module.exports.startup();
  return {app: module.exports, state,
    setup: values => module.exports.setup(GUILD, interaction(values))};
}

test('setup start preserves legacy sheet, role, and custom layout configuration', async () => {
  const {setup, state} = await loadServer({config: null});
  await setup({step: 'start'});
  const saved = state.saved[GUILD];
  assert.equal(saved.originalRosterSpreadsheetId, configuration().originalRosterSpreadsheetId);
  assert.equal(saved.spreadsheetId, configuration().spreadsheetId);
  assert.deepEqual(saved.rankRoles, configuration().rankRoles);
  assert.deepEqual(saved.rosterLayout, layout());
});

test('failed rank edit and failed save leave the effective configuration intact', async () => {
  const config = configuration();
  config.rankRoles.push({roleId: SERGEANT, roleName: 'SADLE Sergeant', label: 'Sergeant'});
  const {setup, state} = await loadServer({config});
  await assert.rejects(setup({step: 'rank', rank: 'sergeant', role: {id: ROLE}}), /already mapped/);
  state.failSave = true;
  await assert.rejects(setup({step: 'department', value: 'Must not be committed'}), /write failed/);
  state.failSave = false;
  await setup({step: 'start'});
  assert.equal(state.saved[GUILD].department, config.department);
  assert.deepEqual(state.saved[GUILD].rankRoles, config.rankRoles);
  assert.equal(state.saved[GUILD].enabled, true);
});

test('rank edits replace legacy pipe and dotted-form names when reselecting or changing a role', async t => {
  for (const roleName of ['SADLE | Lieutenant', 'S.A.D.L.E. | Lieutenant']) {
    await t.test(roleName, async () => {
      const config = configuration();
      config.rankRoles.push({roleId: SERGEANT, roleName, label: 'Lieutenant'});
      const {setup, state} = await loadServer({config});
      await setup({step: 'rank', rank: 'lieutenant', role: {id: SERGEANT}});
      assert.equal(state.saved[GUILD].rankRoles.length, 2);
      assert.equal(state.saved[GUILD].rankRoles.filter(r => rankLevel(r.roleName) === 60).length, 1);
      const replacement = '100000000000000006';
      await setup({step: 'rank', rank: 'lieutenant', role: {id: replacement}});
      const saved = state.saved[GUILD].rankRoles;
      assert.equal(saved.length, 2);
      assert.equal(saved.some(r => r.roleId === SERGEANT), false);
      assert.equal(saved.filter(r => rankLevel(r.roleName) === 60).length, 1);
      assert.equal(saved.find(r => rankLevel(r.roleName) === 60).roleId, replacement);
      assert.deepEqual(saved.find(r => r.roleId === ROLE), config.rankRoles[0]);
    });
  }
});

test('rank edits preserve the separate supervisor level and each HQ director variant', async () => {
  const config = configuration();
  const names = ['SADLE | Corporal', 'SADLE | Supervisor', 'SADLE | HQ',
    'Deputy Director of SADLE', 'Assistant Director of SADLE', 'Director of SADLE', 'SADLE Commissioner'];
  const entries = names.map((roleName, index) => ({roleName, label: roleName,
    roleId: String(100000000000000010n + BigInt(index))}));
  config.rankRoles.push(...entries);
  const {setup, state} = await loadServer({config});
  await setup({step: 'rank', rank: 'corporal', role: {id: '100000000000000030'}});
  assert.deepEqual(state.saved[GUILD].rankRoles.find(r => rankLevel(r.roleName) === 45), entries[1]);
  await setup({step: 'rank', rank: 'hq', role: {id: '100000000000000031'}});
  const saved = state.saved[GUILD].rankRoles;
  assert.equal(saved.filter(r => rankLevel(r.roleName) === 90).length, 1);
  assert.equal(saved.find(r => rankLevel(r.roleName) === 90).roleId, '100000000000000031');
  for (const director of entries.slice(3)) assert.deepEqual(saved.find(r => r.roleId === director.roleId), director);
});

test('preview reads the private backend and validates links without saving or writing Sheets', async () => {
  const {setup, state} = await loadServer();
  const response = await setup({step: 'preview'});
  assert.match(response, /private data spreadsheet accessible/);
  assert.equal(state.saves, 0);
  assert.ok(state.requests.some(r => r.id === configuration().spreadsheetId && r.method === 'GET'));
  assert.ok(state.requests.every(r => r.method === 'GET'));
  assert.deepEqual(state.mirrorChecks, ['prepare', 'callsigns', 'placements', 'permissions']);
});

test('preview refuses missing rank sections before performing service requests', async () => {
  const config = configuration();
  config.rankRoles.push({roleId: SERGEANT, roleName: 'SADLE Sergeant', label: 'Sergeant'});
  const {setup, state} = await loadServer({config});
  await assert.rejects(setup({step: 'preview'}), /configured ranks.*sergeant/);
  assert.equal(state.requests.length, 0);
  assert.equal(state.saves, 0);
});

test('preview fails for an inaccessible private backend or stale officer placement', async () => {
  const {setup, state} = await loadServer();
  state.denied = configuration().spreadsheetId;
  await assert.rejects(setup({step: 'preview'}), /inaccessible/);
  assert.equal(state.mirrorChecks.length, 0);
  state.denied = null;
  state.placementError = 'Linked roster row belongs to a different officer';
  await assert.rejects(setup({step: 'preview'}), /different officer/);
  assert.equal(state.saves, 0);
});

test('preview rejects a known protected mapped cell before reporting readiness', async () => {
  const {setup, state} = await loadServer();
  state.writeAccessError = 'Mapped name cell is protected in section leo: B2';
  await assert.rejects(setup({step: 'preview'}), /Mapped name cell is protected/);
  assert.equal(state.saves, 0);
  assert.ok(state.requests.every(r => r.method === 'GET'));
});

test('linked sections require explicit remap and only that rank loses saved links', async () => {
  const config = configuration();
  config.backupAt = 'previous-backup';
  config.rosterLayout.sections.sergeant = {...layout().sections.leo, startRow: 8, endRow: 9};
  config.rosterLayout.placements = {
    [OFFICER]: {key: 'leo', tab: 'Custom roster', row: 2, callsign: 'K-07'},
    [OTHER]: {key: 'sergeant', tab: 'Custom roster', row: 8, callsign: 'E-01'},
  };
  const {setup, state} = await loadServer({config});
  const mapping = {rank: 'leo', tab: 'Custom roster', start_row: 3, end_row: 5, columns: 'callsign=A,name=B,id=C'};
  await assert.rejects(setup({...mapping, step: 'section'}), /step:remap/);
  assert.equal(state.saves, 0);
  const response = await setup({...mapping, step: 'remap'});
  assert.match(response, /sheet cells were unchanged/);
  assert.equal(state.saved[GUILD].rosterLayout.placements[OFFICER], undefined);
  assert.deepEqual(state.saved[GUILD].rosterLayout.placements[OTHER], config.rosterLayout.placements[OTHER]);
  assert.equal(state.saved[GUILD].backupAt, undefined);
  assert.equal(state.saved[GUILD].enabled, false);
});

test('link stores a canonical callsign and name snapshot; unlink changes no sheet cells', async () => {
  const {setup, state} = await loadServer();
  await setup({step: 'link', rank: 'leo', officer: {id: OFFICER}, start_row: 2});
  assert.deepEqual(state.saved[GUILD].rosterLayout.placements[OFFICER], {
    key: 'leo', tab: 'Custom roster', row: 2, callsign: 'K-07', name: 'Existing Officer',
  });
  assert.ok(state.mirrorChecks.includes('placements'));
  await setup({step: 'unlink', officer: {id: OFFICER}});
  assert.equal(state.saved[GUILD].rosterLayout.placements[OFFICER], undefined);
  assert.ok(state.requests.every(r => r.method === 'GET'));
});

test('link accepts balanced manual callsigns and rejects malformed or reserved automatic values', async () => {
  const {setup, state} = await loadServer();
  const request = {step: 'link', rank: 'leo', officer: {id: OFFICER}, start_row: 2};
  for (const callsign of ['AIR-ONE', 'COMMAND_[A]']) {
    state.rows = [[callsign, 'Existing Officer', '']];
    await setup(request);
    assert.equal(state.saved[GUILD].rosterLayout.placements[OFFICER].callsign, callsign);
  }
  for (const callsign of ['(XI-55', 'X)G-39', 'auto']) {
    state.rows = [[callsign, 'Existing Officer', '']];
    const saves = state.saves;
    await assert.rejects(setup(request), /balanced|valid callsign/);
    assert.equal(state.saves, saves);
    assert.equal(state.saved[GUILD].rosterLayout.placements[OFFICER].callsign, 'COMMAND_[A]');
  }
});

test('changing the main sheet drops old cached links and requires a fresh backup', async () => {
  const config = configuration();
  config.backupAt = 'previous-backup';
  config.rosterLayout.placements[OFFICER] = {key: 'leo', tab: 'Custom roster', row: 2, callsign: 'K-07'};
  const {setup, state} = await loadServer({config});
  await setup({step: 'sheet', value: 'different_synthetic_roster'});
  assert.deepEqual(state.saved[GUILD].rosterLayout.placements, {});
  assert.equal(state.saved[GUILD].backupAt, undefined);
  assert.equal(state.saved[GUILD].enabled, false);
});

test('saving a setup edit pauses a running roster until finish validates it again', async () => {
  const {setup, app, state} = await loadServer();
  await setup({step: 'finish'});
  assert.deepEqual(clone(app.status().guilds), [GUILD]);
  assert.ok(state.saved[GUILD].backupAt);
  assert.ok(state.requests.some(r => r.method === 'POST' && r.suffix.endsWith(':copyTo')));
  await setup({step: 'department', value: 'Updated department'});
  assert.equal(state.stops, 1);
  assert.deepEqual(clone(app.status().guilds), []);
  assert.equal(state.saved[GUILD].enabled, false);
  assert.equal(state.saved[GUILD].configured, false);
});

test('deferred layout callbacks from an old roster cannot replace remapped or disabled settings', async t => {
  for (const action of ['remap', 'disable']) {
    await t.test(action, async () => {
      const {setup, state} = await loadServer();
      await setup({step: 'finish'});
      const oldCallback = state.installs[0].options.onLayoutChange;
      let release;
      const deferred = new Promise(resolve => { release = resolve; });
      const oldLayout = {...layout(), sections: {leo: {...layout().sections.leo, endRow: 99}}};
      const pending = deferred.then(() => oldCallback(oldLayout));
      if (action === 'remap') {
        await setup({step: action, rank: 'leo', tab: 'Custom roster', start_row: 3, end_row: 5,
          columns: 'callsign=A,name=B,id=C'});
      } else await setup({step: action});
      const saved = clone(state.saved[GUILD]);
      const saves = state.saves;
      release();
      await assert.rejects(pending, /configuration changed.*stale layout update discarded/);
      assert.deepEqual(state.saved[GUILD], saved);
      assert.equal(state.saves, saves);
      assert.equal(state.saved[GUILD].enabled, false);
    });
  }
});

test('new roster generations revoke prior callbacks while legacy first persistence still works', async () => {
  const {state} = await loadServer({config: null});
  state.client.emit('ready');
  assert.equal(state.installs.length, 1);
  assert.equal(state.saves, 0, 'legacy startup must not require saved guild settings');
  const firstCallback = state.installs[0].options.onLayoutChange;
  const firstLayout = {...layout(), placements: {[OFFICER]: {
    key: 'leo', tab: 'Custom roster', row: 2, callsign: 'K-07', name: 'Existing Officer',
  }}};
  await firstCallback(firstLayout);
  assert.deepEqual(state.saved[GUILD].rosterLayout, firstLayout);
  assert.equal(state.saved[GUILD].originalRosterSpreadsheetId, configuration().originalRosterSpreadsheetId);
  state.client.emit('ready');
  assert.equal(state.installs.length, 2);
  await assert.rejects(firstCallback(layout()), /stale layout update discarded/);
  const secondCallback = state.installs[1].options.onLayoutChange;
  const expanded = {...firstLayout, sections: {leo: {...layout().sections.leo, endRow: 5}}};
  await secondCallback(expanded);
  assert.deepEqual(state.saved[GUILD].rosterLayout, expanded);
});

test('a failed config save restores the active writer ownership', async () => {
  const {setup, state} = await loadServer();
  await setup({step: 'finish'});
  const callback = state.installs[0].options.onLayoutChange;
  state.failSave = true;
  await assert.rejects(setup({step: 'department', value: 'Rejected edit'}), /write failed/);
  state.failSave = false;
  const expanded = {...layout(), sections: {leo: {...layout().sections.leo, endRow: 5}}};
  await callback(expanded);
  assert.deepEqual(state.saved[GUILD].rosterLayout, expanded);
  assert.equal(state.saved[GUILD].department, configuration().department);
  assert.equal(state.saved[GUILD].enabled, true);
  assert.equal(state.stops, 0);
});
