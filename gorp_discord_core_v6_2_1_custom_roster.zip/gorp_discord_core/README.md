# GORP custom roster bot

This update maps the supplied **GORP Whitelisted LEO Roster** to the bot's custom adapter. The existing private data spreadsheet remains separate from the visible roster.

The source configuration now maps these sections:

| Rank | Worksheet | Rows | Callsign / name / Discord ID |
| --- | --- | --- | --- |
| Probationary | Probationary Officers | 9–63 | B / C / K |
| LEO | Law Enforcement Officers | 10–210 | B / C / V |
| Senior LEO | Senior Law Enforcement Officers | 10–213 | B / C / T |
| HQ | Supervisors / Command Staff | 10–17 | D / E / V |
| Commander | Supervisors / Command Staff | 19–63 | D / E / V |
| Captain | Supervisors / Command Staff | 65–89 | D / E / V |
| Lieutenant | Supervisors / Command Staff | 91–130 | D / E / V |
| Sergeant | Supervisors / Command Staff | 132–199 | D / E / V |
| Corporal / Supervisor | Supervisors / Command Staff | 201–299 | D / E / V |

Only mapped columns are managed. Existing checkbox qualifications, promotion dates, phone numbers, and other unmapped information remain untouched. Checkbox strike columns are intentionally not mapped as a scalar strike count. Detailed strike records remain in the private backend.

## Before starting the live bot

Read [ROSTER_VERIFICATION.md](ROSTER_VERIFICATION.md). The service account can read the sheet, but the live roster currently has protected cells, duplicate identities, an invalid Discord ID, and malformed printed callsigns that must be corrected before synchronization.

Grant the service account from your existing `google-service-account.json` permission to edit the intended roster cells. In Google Sheets, check both file sharing and **Data → Protect sheets and ranges**. Keep protections for other users. The bot respects Google's effective permissions.

Keep these private files from your existing installation:

- `bot_config.private.json`
- `google-service-account.json`
- `guild_roster_settings.private.json`, if present

Credentials are excluded from the update archive. Never commit them. Existing saved per-guild settings take precedence over `sadleroaster/config.json`; the verification command checks the same effective configuration.

Stop the existing bot/FiveM resource, back up its folder, and deploy the updated source. Preserve private files and local data. Then run the checks below before enabling live synchronization.

## Development and read-only checks

Node.js 22 or newer is required, with native `fetch` and `WebSocket`. There are no external npm dependencies and no build step.

```sh
cd gorp_discord_core
npm test
npm run verify:roster
```

`npm test` uses synthetic fixtures and performs no live service operations. It exercises custom placement, promotions, callsign allocation, configuration changes, Sheets integration, and standalone startup.

`npm run verify:roster` authenticates with the existing service account and reads worksheet metadata and mapped rows. It never logs into Discord or writes spreadsheet cells. It exits nonzero if it finds a blocker, reports row locations without officer names or IDs, and supports `--json` or `--guild=DISCORD_GUILD_ID`:

```sh
npm run verify:roster -- --json
npm run verify:roster -- --guild=DISCORD_GUILD_ID
```

In this cloud environment, use Node 24 with `NODE_USE_ENV_PROXY=1` for network commands:

```sh
NODE_USE_ENV_PROXY=1 npm run verify:roster
```

## Setup and changes to the layout

Existing custom mappings are now preserved at startup. `/setup step:start` retains existing sheet and role configuration. Use `/settings` to inspect setup progress.

To map a section, supply its worksheet, first/last officer rows, and explicit columns. For example:

```text
/setup step:section rank:senior tab:Senior Law Enforcement Officers start_row:10 end_row:213 columns:callsign=B,name=C,rank=D,id=T,status=U,notes=P
```

For an existing section with linked officers, use `step:remap` with the new mapping, then re-link the affected officers. Use `/setup step:link` to associate an existing row with its Discord officer, or `step:unlink` to remove a saved link without editing sheet cells.

Successful setup edits pause that guild's roster until `/setup step:preview` and `/setup step:finish` validate and enable it again. Failed edits leave the existing configuration intact. Finishing setup creates backups in the private data spreadsheet before enabling changes to the visible roster.

Automatic whole-row insertion stays disabled in the supplied mapping. This roster has merged labels and other formatting; use `/setup step:expand value:on` only after reviewing the entire worksheet and allowing the necessary edits. After manual row insertions, verify and remap affected ranges.

Once verification passes, run **one** instance: either the FiveM resource or the standalone host using `npm start`. Startup registers Discord commands and immediately synchronizes configured rosters. Verify the first run on a disposable roster copy before using live personnel data.

## Behavior fixed in this update

- Senior LEOs use the Senior worksheet; custom mappings survive legacy configuration loading.
- Empty officer slots remain usable beside manual dates and qualifications.
- Decorated callsigns such as `(X)E-10` share one identity with `E-10`; existing allocations survive restarts.
- Promotions preserve notes and manual columns, while stale or ambiguous identities are refused.
- Sparse backend rows retain their original positions, and one batch cannot allocate the same callsign twice.
- Setup edits, remapping, protected ranges, formulas, and visible-roster failures have explicit checks and regression tests.
