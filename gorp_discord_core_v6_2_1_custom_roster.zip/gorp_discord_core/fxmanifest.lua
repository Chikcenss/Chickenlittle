fx_version 'cerulean'
game 'gta5'
node_version '22'
author 'GORP'
description 'Universal Discord roster, callsigns and supervisor personnel system (Google Sheets)'
version '6.2.1'

-- Server-side only. No client/headtags, NUI, fleet tracking, player-count status,
-- ACE role/principal sync, or FiveM player events.
server_script 'server.js'
