'use strict';

// Checks the real bot identity with Discord itself, never printing or persisting the token.
// This prevents a wrong credential from logging in as a different Discord bot.
async function verifyBotIdentity(token, expectedClientId, doFetch = fetch) {
  const expected = String(expectedClientId || '').trim();
  if (!/^\d{16,22}$/.test(expected)) throw new Error('Expected Discord application ID is missing or invalid');
  if (!token || String(token).startsWith('PASTE_')) throw new Error('Correct Discord bot token not configured');
  let res;
  try {
    res = await doFetch('https://discord.com/api/v10/users/@me', {
      method: 'GET',
      headers: { Authorization: 'Bot ' + token, 'User-Agent': 'GORP-DiscordCore/identity-check' },
      signal: AbortSignal.timeout(15000)
    });
  } catch (e) { throw new Error('Could not check Discord bot identity: ' + e.message); }
  if (!res.ok) throw new Error('Discord bot identity check failed: HTTP ' + res.status + ' (check the new bot token)');
  const data = await res.json();
  const actual = String(data?.id || '');
  if (!data?.bot || !/^\d{16,22}$/.test(actual)) throw new Error('Discord token does not belong to a bot');
  if (actual !== expected) {
    throw new Error('WRONG DISCORD BOT TOKEN: token belongs to application ' + actual + ', expected ' + expected + '. Do not use the old token.');
  }
  return actual;
}
module.exports = {verifyBotIdentity};
