'use strict';
// Optional standalone host (Node.js 22+). Do NOT run alongside the FiveM resource.
const fs=require('node:fs');const path=require('node:path');
const root=__dirname;
const locate=file=>{const p=path.resolve(root,file);if(!p.startsWith(root+path.sep))throw Error('Path outside bot directory');return p;};
global.GetCurrentResourceName=()=> 'gorp_discord_core';
global.LoadResourceFile=(_,file)=>{const p=locate(file);return fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;};
global.SaveResourceFile=(_,file,data)=>{fs.writeFileSync(locate(file),data,'utf8');return true;};
global.RegisterCommand=()=>{};
global.GetConvar=(name,defaultValue)=>process.env[name.toUpperCase()]||defaultValue;
global.on=()=>{};
require('./server');
