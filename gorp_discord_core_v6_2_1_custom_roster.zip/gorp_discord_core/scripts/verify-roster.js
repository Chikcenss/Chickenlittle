'use strict';
// Read-only verification: no Discord login, roster synchronization, or Sheets writes.
const fs = require('node:fs');
const path = require('node:path');
const {GoogleSheetsClient} = require('../sadleroaster/googleSheets');
const {CustomRosterMirror} = require('../sadleroaster/customRoster');
const {analyzeRoster} = require('../sadleroaster/rosterDiagnostics');
const {mainRankEntry, rankLevel} = require('../sadleroaster/index');

function readOnly(client) {
  const request = client.request.bind(client);
  client.request = (method, ...args) => {
    if (method !== 'GET') throw Error('Verification refuses spreadsheet writes.');
    return request(method, ...args);
  };
  return client;
}

async function verify(config, credentials) {
  if (!config.rosterLayout?.sections || !Object.keys(config.rosterLayout.sections).length)
    throw Error('No custom roster sections configured.');
  if (!config.originalRosterSpreadsheetId || config.originalRosterSpreadsheetId === config.spreadsheetId)
    throw Error('The visible roster and private bot data must use different spreadsheets.');
  const backend = readOnly(new GoogleSheetsClient(config.spreadsheetId, credentials));
  await backend.request('GET', '?fields=spreadsheetId');
  const layout = {...config.rosterLayout, callsignPrefixes:config.callsignPrefixes || {}};
  const mirror = new CustomRosterMirror(backend, config.originalRosterSpreadsheetId, credentials, layout, {mainRankEntry, rankLevel});
  readOnly(mirror.target);
  await mirror.prepare();
  return analyzeRoster(layout, mirror.meta, await mirror.allRows());
}

function effectiveConfig(legacy, saved, homeGuild, selectedGuild) {
  const guild = selectedGuild || homeGuild;
  if (selectedGuild && !/^\d{16,22}$/.test(selectedGuild)) throw Error('Invalid --guild Discord ID.');
  if (!guild && Object.keys(saved).length)
    throw Error('Select the Discord guild using --guild=ID to verify its saved configuration.');
  if (guild && Object.hasOwn(saved, guild)) {
    return {config:{...saved[guild], callsignPrefixes:saved[guild].callsignPrefixes || legacy.callsignPrefixes || {}},
      source:'saved guild configuration'};
  }
  if (selectedGuild && selectedGuild !== homeGuild)
    throw Error('Selected guild has no saved roster configuration.');
  return {config:legacy, source:'source configuration'};
}

async function main() {
  const root = path.resolve(__dirname, '..');
  const read = (file, fallback) => fs.existsSync(path.join(root,file))
    ? JSON.parse(fs.readFileSync(path.join(root,file),'utf8')) : fallback;
  const legacy = read('sadleroaster/config.json', {});
  const saved = read('guild_roster_settings.private.json', {});
  const bot = read('bot_config.private.json', {});
  const requested = process.argv.find(value=>value.startsWith('--guild='))?.slice('--guild='.length);
  const {config, source} = effectiveConfig(legacy, saved, bot.guildId || process.env.GORP_DISCORD_GUILD_ID, requested);
  const credentials = JSON.parse(fs.readFileSync(path.join(root, 'google-service-account.json'), 'utf8'));
  const report = {...await verify(config, credentials), configurationSource:source};
  if (process.argv.includes('--json')) console.log(JSON.stringify(report, null, 2));
  else {
    console.log(`Read-only roster verification (${source}): ${report.totals.sections} rank sections, ${report.totals.slots} callsign slots, ${report.totals.occupied} occupied rows, ${report.totals.vacant} vacant rows.`);
    for (const section of report.sections)
      console.log(`${section.rank}: ${section.tab}, rows ${section.startRow}-${section.endRow}, ${section.slots} callsigns`);
    for (const item of report.issues)
      console.log(`${item.code}: ${item.message} ${item.locations.map(p=>`${p.tab}${p.row ? ' row '+p.row : ' rows '+p.startRow+'-'+p.endRow}`).join('; ')}`);
    console.log(report.ok ? 'PASS: configured roster checks passed.' : 'BLOCKED: resolve the reported issues before live synchronization.');
  }
  process.exitCode = report.ok ? 0 : 1;
}

if (require.main === module) main().catch(error => {
  // Avoid API response bodies, credential values, and spreadsheet identifiers.
  console.error('Roster verification failed before analysis: ' +
    (/^No custom|^The visible|^Missing configured|^Section |^Invalid |^Duplicate |^Overlapping |^Mapped |^Select(?:ed)? /.test(error.message)
      ? error.message : 'configuration, permissions, or service access failed; no response body logged.'));
  process.exitCode = 1;
});

module.exports = {verify, readOnly, effectiveConfig};
