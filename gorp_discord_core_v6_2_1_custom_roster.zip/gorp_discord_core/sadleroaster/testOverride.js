'use strict';
// Explicitly authorized testing account. This is an ACTOR-only override:
// it does not make this user immune to actions by normal higher-ranking staff.
// It also does not bypass Discord's own bot-role hierarchy, Google permissions,
// missing guild membership, target LEO eligibility, or spreadsheet safety checks.
const TESTING_ACCOUNT_ID = '397587984477585409';
function isTestingOverride(userId) {
  return String(userId) === TESTING_ACCOUNT_ID;
}
module.exports = {TESTING_ACCOUNT_ID,isTestingOverride};
