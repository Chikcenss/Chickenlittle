'use strict';

const { createSign } = require('node:crypto');

const BASE = 'https://sheets.googleapis.com/v4/spreadsheets';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const SCOPE = 'https://www.googleapis.com/auth/spreadsheets';

function b64url(value) {
  return Buffer.from(typeof value === 'string' ? value : JSON.stringify(value)).toString('base64url');
}

function quoteTab(tab) {
  return `'${tab.replace(/'/g, "''")}'`;
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

class GoogleSheetsClient {
  constructor(spreadsheetId, credentials) {
    if (!/^[A-Za-z0-9_-]+$/.test(spreadsheetId || '')) throw new Error('Invalid or missing gorp_sadle_sheet_id');
    if (credentials?.type !== 'service_account' || !credentials.client_email || !credentials.private_key) {
      throw new Error('google-service-account.json must be a Google service account key with client_email/private_key');
    }
    this.id = spreadsheetId;
    this.credentials = credentials;
    this.token = null;
    this.expires = 0;
  }

  async accessToken() {
    if (this.token && Date.now() < this.expires) return this.token;
    const now = Math.floor(Date.now() / 1000);
    const hdr = b64url({alg:'RS256',typ:'JWT'});
    const body = b64url({iss: this.credentials.client_email, scope: SCOPE, aud: TOKEN_URL, iat: now, exp: now + 3600});
    const input = `${hdr}.${body}`;
    const signer = createSign('RSA-SHA256');
    signer.update(input);
    signer.end();
    const jwt = `${input}.${signer.sign(this.credentials.private_key).toString('base64url')}`;
    const params = new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion:jwt});
    const resp = await fetch(TOKEN_URL, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:params, signal: AbortSignal.timeout(15000)});
    const json = await resp.json();
    if (!resp.ok || !json.access_token) throw new Error(`Google auth HTTP ${resp.status}: ${JSON.stringify(json).slice(0, 350)}`);
    this.token = json.access_token;
    this.expires = Date.now() + Math.max(60, (json.expires_in || 3600) - 90) * 1000;
    return this.token;
  }

  async request(method, suffix = '', body = undefined) {
    const url = `${BASE}/${this.id}${suffix}`;
    for (let attempt=0; attempt<4; attempt++) {
      const token = await this.accessToken();
      let response;
      try {
        response = await fetch(url, {
          method,
          headers: { Authorization:`Bearer ${token}`, ...(body === undefined ? {} : {'Content-Type':'application/json'}) },
          body: body === undefined ? undefined : JSON.stringify(body),
          signal: AbortSignal.timeout(20000)
        });
      } catch (err) {
        if (attempt < 3) { await sleep((attempt+1)*750); continue; }
        throw err;
      }
      if (response.status === 401 && attempt < 3) { this.token=null; await sleep(200); continue; }
      if ((response.status === 429 || response.status >= 500) && attempt < 3) {
        await sleep((attempt+1)*900); continue;
      }
      const payload = await response.json().catch(()=>({}));
      if (!response.ok) throw new Error(`Google Sheets HTTP ${response.status}: ${JSON.stringify(payload).slice(0,450)}`);
      return payload;
    }
    throw new Error('Google Sheets request exhausted retries');
  }

  async ensureTabs(schemas) {
    const meta = await this.request('GET','?fields=sheets(properties(sheetId,title))');
    let sheets = meta.sheets || [];
    const toAdd = Object.keys(schemas).filter(name => !sheets.some(s => s.properties.title === name));
    if (toAdd.length) {
      await this.request('POST', ':batchUpdate', {requests: toAdd.map(title => ({addSheet: {properties:{title, gridProperties:{frozenRowCount:1}}}}))});
      sheets = (await this.request('GET','?fields=sheets(properties(sheetId,title))')).sheets || [];
    }
    this.sheetIds = new Map(sheets.map(s => [s.properties.title,s.properties.sheetId]));
    for (const [name, headers] of Object.entries(schemas)) {
      const found = (await this.getValues(`${quoteTab(name)}!A1:${letter(headers.length)}1`))[0] || [];
      if (found.length === 0) {
        await this.putValues(`${quoteTab(name)}!A1:${letter(headers.length)}1`, [headers]);
      } else if (found.length !== headers.length || headers.some((x, i) => x !== found[i])) {
        throw new Error(`Tab "${name}" has different headers. To protect existing roster data, configure a fresh tab name or adjust your sheet. Expected: ${headers.join(' | ')}`);
      }
    }
  }

  async getValues(range) {
    const json = await this.request('GET', `/values/${encodeURIComponent(range)}?valueRenderOption=FORMATTED_VALUE`);
    return json.values || [];
  }

  async putValues(range, values) {
    if (!values.length) return;
    return this.request('PUT', `/values/${encodeURIComponent(range)}?valueInputOption=RAW`, {range, majorDimension:'ROWS', values});
  }

  async appendValues(range, values) {
    if (!values.length) return;
    return this.request('POST', `/values/${encodeURIComponent(range)}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, {values});
  }
}

function letter(n) {
  // Supported schema never exceeds 26 columns.
  if (n < 1 || n > 26) throw new Error('Column outside A-Z');
  return String.fromCharCode(64+n);
}

module.exports = { GoogleSheetsClient, quoteTab };
