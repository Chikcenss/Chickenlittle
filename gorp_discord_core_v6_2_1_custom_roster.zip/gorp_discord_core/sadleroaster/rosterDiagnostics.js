'use strict';

const {canonical, blankEntry, validatedSection} = require('./customRoster');
const {prefixFor, callsignKey, CallsignManager} = require('./callsigns');
const LEVELS = {probationary:10, leo:20, senior:30, corporal:40, sergeant:50, lieutenant:60, captain:70, commander:80, hq:90};
const text = value => String(value ?? '').trim();

function covers(range, row, column) {
  return row >= (range.startRowIndex ?? 0) && row < (range.endRowIndex ?? Infinity)
    && column >= (range.startColumnIndex ?? 0) && column < (range.endColumnIndex ?? Infinity);
}

function editable(sheet, row, column) {
  return (sheet.protectedRanges || []).every(protection => {
    if (protection.warningOnly || protection.requestingUserCanEdit === true) return true;
    if (!covers(protection.range || {}, row, column)) return true;
    return (protection.unprotectedRanges || []).some(range => covers(range, row, column));
  });
}

// Pure analysis: row locations are reported without exposing officer names or IDs.
function analyzeRoster(layout, metadata, rowsBySection) {
  const sheets = metadata instanceof Map ? metadata
    : new Map((metadata.sheets || []).map(sheet => [sheet.properties.title, sheet]));
  const issues = [], sections = [], identities = new Map(), callsigns = new Map();
  const issue = (code, message, locations = []) => issues.push({code, message, locations});
  for (const [key, raw] of Object.entries(layout.sections || {})) {
    const section = validatedSection(raw), rows = rowsBySection[key] || [];
    const sheet = sheets.get(section.tab);
    const expectedPrefix = prefixFor(LEVELS[key], layout.callsignPrefixes || {});
    const summary = {rank:key, tab:section.tab, startRow:section.startRow, endRow:section.endRow, slots:0, occupied:0, vacant:0};
    const blocked = new Set();
    for (let offset = 0; offset <= section.endRow - section.startRow; offset++) {
      const row = rows[offset] || [], number = section.startRow + offset;
      const location = {rank:key, tab:section.tab, row:number};
      const value = text(row[section.indices.callsign]), numericCall = canonical(value);
      let call = numericCall;
      if (value && !call) {
        try { if (CallsignManager.cleanInput(value) !== 'auto') call = callsignKey(value); } catch {}
      }
      const id = section.indices.id === undefined ? '' : text(row[section.indices.id]);
      const name = text(row[section.indices.name]);
      if (call) {
        summary.slots++;
        if (!callsigns.has(call)) callsigns.set(call, []);
        callsigns.get(call).push(location);
        if (numericCall && !call.startsWith(expectedPrefix + '-') && !name && !id)
          issue('WRONG_RANK_PREFIX', `Vacant callsign ${call} is outside the configured ${expectedPrefix} prefix.`, [location]);
      }
      if (blankEntry(row, section)) summary.vacant++;
      else if (name || id) summary.occupied++;
      if (id) {
        if (!/^\d{16,22}$/.test(id)) issue('INVALID_DISCORD_ID', 'Mapped Discord ID is not a valid Discord snowflake.', [location]);
        else {
          if (!identities.has(id)) identities.set(id, []);
          identities.get(id).push(location);
        }
      }
      if ((name || id) && !call) issue('MISSING_CALLSIGN', 'An occupied officer row has no recognizable callsign.', [location]);
      if (sheet) for (const [field, column] of Object.entries(section.indices)) {
        if (!editable(sheet, number - 1, column)) blocked.add(field);
      }
    }
    if (!sheet) issue('MISSING_TAB', 'Mapped worksheet is missing.', [{rank:key,tab:section.tab}]);
    if (blocked.size) issue('PROTECTED_CELLS', `The service account cannot edit protected mapped columns: ${[...blocked].join(', ')}.`, [{rank:key,tab:section.tab,startRow:section.startRow,endRow:section.endRow}]);
    sections.push(summary);
  }
  for (const locations of identities.values()) if (locations.length > 1)
    issue('DUPLICATE_DISCORD_ID', 'The same Discord ID appears in multiple officer rows; resolve the duplicate before syncing.', locations);
  for (const [call, locations] of callsigns) if (locations.length > 1)
    issue('DUPLICATE_CALLSIGN', `Callsign ${call} appears in multiple mapped slots.`, locations);
  return {ok:issues.length === 0, sections, issues,
    totals:{sections:sections.length, slots:sections.reduce((n,s)=>n+s.slots,0), occupied:sections.reduce((n,s)=>n+s.occupied,0), vacant:sections.reduce((n,s)=>n+s.vacant,0)}};
}

module.exports = {analyzeRoster, editable};
