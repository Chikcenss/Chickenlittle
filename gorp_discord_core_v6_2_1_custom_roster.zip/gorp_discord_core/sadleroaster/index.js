'use strict';

// Discord REST and gateway-event integration for the EXISTING GORP discord_local client.
// There is NO second Discord login and NO discord.js / Yarn requirement.
const { GoogleSheetsClient, quoteTab } = require('./googleSheets');
const { CallsignManager, CALLSIGN_HEADERS, CALLSIGN_HISTORY_HEADERS } = require('./callsigns');
const { OriginalRosterMirror } = require('./originalRoster');
const { CustomRosterMirror } = require('./customRoster');
const { PersonnelLedger } = require('./personnel');
const { isTestingOverride } = require('./testOverride');
const { createHash } = require('node:crypto');
const ACTIVE_HEADERS = ['Discord ID','Officer','Rank','Discord Username','Joined Roster (UTC)','Last Updated (UTC)'];
const HISTORY_HEADERS = [...ACTIVE_HEADERS,'Removed (UTC)','Reason'];
const CAREER_HEADERS = ['Discord ID','Officer','Rank','Joined Department (UTC)','Previous Rank','Last Rank Action','Last Rank Action (UTC)','Tracked Roles JSON','Last Ranked Role','State Changed (UTC)'];
const RANK_HISTORY_HEADERS = ['Event ID','Discord ID','Officer','Event','Old Role / Rank','New Role / Rank','Date (UTC)','Details'];
const DETAILS_HEADERS = ['Discord ID','Callsign',...Array.from({length:18},(_,i)=>'Bot Field '+(i+3))];
const log = (...args) => console.log('[GORP SADLE Roster]',...args);
const fail = (...args) => console.error('[GORP SADLE Roster]',...args);
const iso = () => new Date().toISOString();
const sleep = ms => new Promise(r => setTimeout(r, ms));
const normalizeRow = (r,n) => Array.from({length:n},(_,i)=>String(r[i]??''));

// All ranks are resolved from the LIVE Discord role list. Recreated roles have
// new IDs, so never rely on deleted historical role IDs in config.json.
function normalizedRoleName(name) {
  return String(name || '')
    .replace(/s\.?\s*a\.?\s*d\.?\s*l\.?\s*e\.?/gi, 'SADLE')
    .normalize('NFKC').toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}
// Fixed law-enforcement rank order: Discord position is not a promotion scale.
// Subdivision director/certification roles are tracked, but never override a patrol rank.
const RANK_LEVELS = new Map([
  ['sadle probationary',10],['sadle leo',20],['sadle senior leo',30],
  ['sadle corporal',40],['sadle supervisor',45],['sadle sergeant',50],
  ['sadle lieutenant',60],['sadle captain',70],['sadle commander',80],
  ['sadle hq',90],['deputy director of sadle',100],
  ['assistant director of sadle',110],['director of sadle',120],
  ['sadle commissioner',130]
]);
const CORE_RANK_NAMES = new Set(RANK_LEVELS.keys());
function rankLevel(name){
 const n=normalizedRoleName(name);
 if(RANK_LEVELS.has(n))return RANK_LEVELS.get(n);
 if(/commissioner/.test(n))return 130;
 if(/assistant director/.test(n))return 110;
 if(/deputy director/.test(n))return 100;
 if(/director of sadle/.test(n))return 120;
 if(/(?:^| )hq(?:$| )|headquarters/.test(n))return 90;
 if(/commander/.test(n))return 80;
 if(/captain/.test(n))return 70;
 if(/lieutenant|(?:^| )lt(?:$| )/.test(n))return 60;
 if(/sergeant|(?:^| )sgt(?:$| )/.test(n))return 50;
 if(/corporal/.test(n))return 40;
 if(/senior.*leo/.test(n))return 30;
 if(/probationary|probie/.test(n))return 10;
 if(/(?:^| )leo(?:$| )|law enforcement officer/.test(n))return 20;
 return 0;
}
function mainRankEntry(member,ranks) {
  const held=new Set((member.roles||[]).map(String));
  return (ranks||[]).filter(r => held.has(String(r.roleId||'')) && rankLevel(r.roleName||r.label)>0)
    .sort((a,b)=>rankLevel(b.roleName||b.label)-rankLevel(a.roleName||a.label) ||
      (Number(b.discordPosition)||0)-(Number(a.discordPosition)||0))[0] || null;
}
function rankFor(member,ranks) {
  const main=mainRankEntry(member,ranks);
  if(main)return String(main.label||main.roleName);
  // Specialty-only members still appear in their own category.
  const held=new Set((member.roles||[]).map(String));
  const other=(ranks||[]).filter(r=>held.has(String(r.roleId||'')));
  other.sort((a,b)=>(Number(b.priority)||0)-(Number(a.priority)||0));
  return String(other[0]?.label||other[0]?.roleName||'SADLE Member');
}
function trackedNames(member,ranks){
  const held=new Set((member.roles||[]).map(String));
  return [...new Set((ranks||[]).filter(r=>held.has(String(r.roleId||'')))
    .map(r=>String(r.roleName||r.label||'').trim()).filter(Boolean))].sort();
}
function isRankName(name){return rankLevel(name)>0;}
function hashEvent(userId,oldState,newState,event){
  return createHash('sha256').update([userId,oldState,newState,event.type,event.old,event.next].join('|')).digest('hex').slice(0,32);
}
function officer(member){return String(member.nick||member.user?.global_name||member.user?.username||member.user?.id||'');}
function makeRow(member,ranks){return [String(member.user.id),officer(member),rankFor(member,ranks),String(member.user.username||''),iso(),iso()];}

function strError(e){return String(e||'unknown error').slice(0,140);}
class DiscordRest {
  constructor(guildId,getToken){this.guildId=guildId;this.getToken=getToken;}
  async request(suffix) {
    for(let attempt=0;attempt<4;attempt++) {
      const token=this.getToken();
      if(!token) throw new Error('Discord bot token not available (bot not connected)');
      let resp;
      try {resp=await fetch('https://discord.com/api/v10'+suffix,{headers:{Authorization:'Bot '+token,'User-Agent':'GORP-SADLE-AutoRoster/2.0'},signal:AbortSignal.timeout(20000)});}
      catch(e){if(attempt<3){await sleep(800*(attempt+1));continue;} throw e;}
      const data=await resp.json().catch(()=>null);
      if(resp.status===404) return null;
      if((resp.status===429||resp.status>=500)&&attempt<3){
        const seconds=Number(data?.retry_after||0);
        await sleep(Math.max(800,Math.min(12000,seconds*1000||800*(attempt+1))));continue;
      }
      if(!resp.ok) throw new Error('Discord HTTP '+resp.status+(data?.message?': '+String(data.message).slice(0,140):''));
      return data;
    }
    throw new Error('Discord REST exhausted retries');
  }
  // Announce only completed Google Sheets callsign changes. Discord messages
  // never block roster writes if a channel permission is missing.
  async sendChannelMessage(channelId,content,mentionUserId){
    if(!/^\d{16,22}$/.test(String(channelId)))throw Error('Invalid callsign channel ID');
    if(!this.getToken())throw Error('Discord bot token unavailable');
    const body={content:String(content).slice(0,1900),allowed_mentions:{parse:[],
      users:/^\d{16,22}$/.test(String(mentionUserId||''))?[String(mentionUserId)]:[]}};
    for(let attempt=0;attempt<4;attempt++){
      const resp=await fetch('https://discord.com/api/v10/channels/'+channelId+'/messages',{
        method:'POST',
        headers:{Authorization:'Bot '+this.getToken(),'Content-Type':'application/json',
          'User-Agent':'GORP-SADLE-AutoRoster/3.1'},
        body:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
      if(resp.ok)return await resp.json().catch(()=>({}));
      const payload=await resp.json().catch(()=>({}));
      if((resp.status===429||resp.status>=500)&&attempt<3){
        const delay=Number(payload.retry_after)||.75*(attempt+1);
        await sleep(Math.min(15000,Math.max(500,delay*1000)));continue;
      }
      throw Error('Discord callsign channel HTTP '+resp.status+': '+String(payload.message||'send failed').slice(0,120));
    }
  }
  async mutateMemberRole(id,roleId,method){
    if(!['PUT','DELETE'].includes(method))throw Error('Invalid role operation');
    const resp=await fetch(`https://discord.com/api/v10/guilds/${this.guildId}/members/${id}/roles/${roleId}`,{
      method,headers:{Authorization:'Bot '+this.getToken(),'User-Agent':'GORP-Roster/4.0'},signal:AbortSignal.timeout(20000)});
    if(!resp.ok){const error=await resp.json().catch(()=>({}));throw Error('Discord role change HTTP '+resp.status+': '+strError(error.message));}
  }
  async botMember(botId){return this.fetchMember(botId);}
  async fetchRoles(){return this.request(`/guilds/${this.guildId}/roles`);}
  async fetchMember(userId){return this.request(`/guilds/${this.guildId}/members/${userId}`);}
  async fetchBan(userId){return this.request(`/guilds/${this.guildId}/bans/${userId}`);}
  async fetchAll() {
    const result=[];let after='0';let last='';
    for(let page=0;page<200;page++) {
      const rows=await this.request(`/guilds/${this.guildId}/members?limit=1000&after=${after}`);
      if(!Array.isArray(rows)) throw new Error('Discord returned non-array member list: refusing roster changes');
      for(const m of rows){if(!/^\d{16,22}$/.test(String(m.user?.id||''))) throw new Error('Incomplete Discord member list: refusing roster changes');result.push(m);}
      if(rows.length<1000) return result;
      last=String(rows[rows.length-1].user.id);
      if(BigInt(last)<=BigInt(after)) throw new Error('Discord member pagination stalled');
      after=last;
    }
    throw new Error('Discord pagination cap exceeded: refusing roster changes');
  }
}

class SadleRoster {
  constructor(client,config, sheetClient, discordClient){
    if(!client?.on||!client?.once) throw new Error('Existing Discord EventEmitter client required');
    if(!/^\d{16,22}$/.test(String(config.guildId||''))) throw new Error('Invalid Discord guild ID');
    const membershipRoleIds = Array.isArray(config.membershipRoleIds) ? config.membershipRoleIds : [config.sadleRoleId];
    if(!membershipRoleIds.length || membershipRoleIds.some(id => !/^\d{16,22}$/.test(String(id)))) throw new Error('Missing/invalid LEO membership role IDs');
    this.membershipRoles = new Set(membershipRoleIds.map(String));
    this.requiredRoleId=String(config.requiredRoleId||'');
    if(this.requiredRoleId&&!/^\d{16,22}$/.test(this.requiredRoleId)) throw new Error('Invalid required SADLE membership role');
    this.client=client;this.cfg=config;this.department=String(config.department||'SADLE').replace(/[\r\n@*`]/g,'').slice(0,60);this.ranks=config.rankRoles||[];
    this.lastRoleLookup=0;this.rankLookupStats=null;
    this.activeTab=config.activeTab||'SADLE Active';this.historyTab=config.historyTab||'SADLE History';
    this.careerTab=config.careerTab||'SADLE Career';this.rankHistoryTab=config.rankHistoryTab||'SADLE Rank History';
    if(new Set([this.activeTab,this.historyTab,this.careerTab,this.rankHistoryTab]).size!==4)throw new Error('Roster tab names must be distinct');
    if(this.activeTab===this.historyTab) throw new Error('Active/history tab names must be different');
    // The visible officer roster and all bot-owned logs MUST be separate spreadsheets.
    if(config.originalRosterSpreadsheetId && config.originalRosterSpreadsheetId===config.spreadsheetId)
      throw Error('Main roster cannot be the bot data/log spreadsheet. Configure separate Google Sheets IDs.');
    if(config.personnelSpreadsheetId && config.originalRosterSpreadsheetId===config.personnelSpreadsheetId)
      throw Error('Private personnel records cannot be stored in the public main roster spreadsheet.');
    this.sheets=sheetClient||new GoogleSheetsClient(config.spreadsheetId,config.credentials);
    this.originalRoster=config.rosterLayout?.sections && Object.keys(config.rosterLayout.sections).length ?
      new CustomRosterMirror(this.sheets,config.originalRosterSpreadsheetId||config.spreadsheetId,config.credentials,
       config.rosterLayout,{mainRankEntry,rankLevel},config.onLayoutChange) :
      (config.originalRosterSpreadsheetId?new OriginalRosterMirror(this.sheets,config.originalRosterSpreadsheetId,config.credentials,{mainRankEntry,rankLevel}):null);
    this.callsigns=new CallsignManager(this.sheets,{callsignTab:config.callsignTab,detailsTab:config.detailsTab,
      callsignHistoryTab:config.callsignHistoryTab,callsignPrefixes:config.callsignPrefixes,
      rankLevel,mainRankEntry});
    this.discord=discordClient||new DiscordRest(config.guildId,config.getToken);
    this.personnel=new PersonnelLedger(config.personnelSpreadsheetId?new GoogleSheetsClient(config.personnelSpreadsheetId,config.credentials):this.sheets,config.guildId,config.personnelTabs||{});
    this.personnelLogChannelId=String(config.personnelLogChannelId||'').trim();
    if(this.personnelLogChannelId&&!/^\d{16,22}$/.test(this.personnelLogChannelId))throw Error('Invalid personnel log channel ID');
    this.callsignChannelId=String(config.callsignChannelId||'').trim();
    if(this.callsignChannelId&&!/^\d{16,22}$/.test(this.callsignChannelId))
      throw Error('Invalid configured SADLE callsign channel ID');
    this.queue=Promise.resolve();this.started=false;this.closed=false;this.timer=null;this.listeners=[];
    this.memberDebounces=new Map();this.roleMappingReliable=false;
    this.stats={lastGatewayEvent:null, lastGatewayMemberId:null, gatewayEvents:0,
      lastCheck:null, lastCheckSuccess:null, lastError:null, lastWrite:null,
      lastJob:null, checkedMembers:null, eligibleMembers:null, fallbackIntervalSec:null,
      lastCallsignAnnouncement:null,lastCallsignAnnouncementError:null, originalRosterSheetId:config.originalRosterSpreadsheetId||null};
  }
  // Resolve roleName -> current Discord role ID; no changes to Discord roles.
  // Throttle lookups but refresh regularly to recover from future migrations.
  async resolveRanks(force=false){
    if(!this.discord.fetchRoles)return;
    if(!force && this.lastRoleLookup && Date.now()-this.lastRoleLookup < 60000)return;
    const roles=await this.discord.fetchRoles();
    if(!Array.isArray(roles))throw new Error('Discord role list is not an array');
    const byName=new Map();
    for(const role of roles){
      const key=normalizedRoleName(role.name);
      if(!byName.has(key))byName.set(key,[]);
      byName.get(key).push(role);
    }
    let matched=0,ambiguous=0;
    const unresolved=[];
    const mapped=(this.cfg.rankRoles||[]).map(entry=>{
      const roleName=String(entry.roleName||entry.name||entry.label||'');
      const exact=entry.roleId?roles.filter(role=>String(role.id)===String(entry.roleId)):[];
      const candidates=exact.length?exact:(byName.get(normalizedRoleName(roleName))||[]);
      if(candidates.length===1){
        matched++;
        return {...entry,roleName,roleId:String(candidates[0].id),discordPosition:Number(candidates[0].position)||0};
      }
      if(candidates.length>1)ambiguous++;
      else unresolved.push(roleName);
      // A stale/deleted role ID must never map to a different new role.
      return {...entry,roleName,roleId:null};
    });
    this.ranks=mapped;
    // A partially unavailable Discord role list can otherwise be mistaken for
    // dozens of role removals. Require nearly all configured role names.
    const coreRankRoles=mapped.filter(x=>rankLevel(x.roleName||x.label)>0);
    const resolvedCore=coreRankRoles.filter(x=>x.roleId).length;
    this.roleMappingReliable = coreRankRoles.length>0 && resolvedCore >= Math.ceil(coreRankRoles.length*0.9);
    this.lastRoleLookup=Date.now();
    const details={configured:mapped.length,resolved:matched,ambiguous,missing:unresolved.length};
    if(JSON.stringify(details)!==JSON.stringify(this.rankLookupStats)){
      log('Discord rank mapping: '+matched+'/'+mapped.length+' matched by current role name; '+ambiguous+' ambiguous, '+unresolved.length+' missing.');
      if(unresolved.length)log('Missing Discord rank roles: '+unresolved.slice(0,12).join(', '));
    }
    this.rankLookupStats=details;
  }
  bind(event,fn){this.client.on(event,fn);this.listeners.push([event,fn]);}
  enqueue(label,fn,propagateError=false) {
    // Keep one serialized Google Sheet writer to prevent racing role updates.
    const task=this.queue.catch(()=>{}).then(async()=>{
      if(this.closed||!this.started) throw new Error('Roster not running');
      this.stats.lastJob=label;
      try {
        const result=await fn();
        this.stats.lastError=null;
        return result;
      } catch(e) {
        this.stats.lastError=label+': '+String(e?.message||e);
        fail(this.stats.lastError);
        throw e;
      }
    });
    this.queue=task.catch(()=>{}); // Auto-event callers don't crash the bot.
    return propagateError ? task : this.queue;
  }
  status(){
    return {running:this.started&&!this.closed,requiredRoleId:this.requiredRoleId||'(any qualifying role)',
      gatewayMembersIntentEnabled:Boolean(this.client.intents&2),
      gatewayMembersFallback:Boolean(this.client.membersIntentFallbackUsed),
      rankLookup:this.rankLookupStats,callsignChannelId:this.callsignChannelId||'(disabled)',
      roleMappingReliable:this.roleMappingReliable,
      originalRoster:this.originalRoster?.stats||null, ...this.stats};
  }
  start(){
    // Keep roster errors isolated. A failed Sheets/Discord REST request must NOT
    // take the main bot offline or delete existing roster entries.
    this.bind('shardResume',()=>this.enqueue('Post-reconnect reconciliation',()=>this.reconcile()));
    this.bind('rawDiscordDispatch',packet=>{
      const d=packet?.d||{};
      if(String(d.guild_id||'')!==this.cfg.guildId)return;
      const type=String(packet.t||'');
      if(!['GUILD_MEMBER_ADD','GUILD_MEMBER_UPDATE','GUILD_MEMBER_REMOVE','GUILD_BAN_ADD'].includes(type))return;
      const id=String(d.user?.id||d.user_id||'');
      if(!/^\d{16,22}$/.test(id)) {log('Skipped '+type+': Discord supplied no valid member ID.');return;}
      this.stats.lastGatewayEvent=type+' '+iso();
      this.stats.lastGatewayMemberId=id;
      this.stats.gatewayEvents++;
      log('LIVE Discord event '+type+' for member '+id+' (member role count '+(Array.isArray(d.roles)?d.roles.length:'unknown')+').');
      if(type==='GUILD_MEMBER_ADD'||type==='GUILD_MEMBER_UPDATE') {
        // Discord often sends remove-previous-role and add-new-role seconds apart.
        // Debounce to record one promotion/demotion instead of two partial changes.
        const old=this.memberDebounces.get(id);if(old)clearTimeout(old);
        const timer=setTimeout(()=>{
          this.memberDebounces.delete(id);
          this.enqueue(type,()=>this.refreshOne(id));
        },2300);
        this.memberDebounces.set(id,timer);
      }else if(type==='GUILD_MEMBER_REMOVE'){
        this.enqueue(type,()=>this.removeOne(id,'Left Discord / kicked'));
      }else if(type==='GUILD_BAN_ADD'){
        this.enqueue(type,()=>this.removeOne(id,'Banned from Discord'));
      }
    });
    const startReady=()=>{
      if(this.closed||this.started)return;
      this.started=true;
      const secs=Math.max(15,Math.min(3600,Number(this.cfg.reconcileSeconds)||20));
      this.stats.fallbackIntervalSec=secs;
      this.timer=setInterval(()=>this.enqueue('Periodic REST reconciliation',()=>this.syncAll()),secs*1000);
      log('Live Discord member event listener ready; backup reconciliation every '+secs+' seconds; Gateway GuildMembers intent '+((this.client.intents & 2)?'ENABLED':'DISABLED')+'.');
      log('Callsign announcement channel: '+(this.callsignChannelId||'not configured'));
      this.enqueue('Initial synchronization',()=>this.syncAll());
    };
    if(this.client.user)startReady();else this.client.once('ready',startReady);
    return this;
  }
  async syncAll(){
    // Resolve IDs before syncing any rows, including immediately after restart.
    try{await this.resolveRanks();}
    catch(e){log('Rank lookup unavailable; keeping previous mapping: '+e.message);}
    await this.sheets.ensureTabs({[this.activeTab]:ACTIVE_HEADERS,[this.historyTab]:HISTORY_HEADERS,
      [this.careerTab]:CAREER_HEADERS,[this.rankHistoryTab]:RANK_HISTORY_HEADERS,...this.callsigns.schema(),
      ...(this.personnel.sheets===this.sheets?this.personnel.schema():{}),
      ...(this.cfg.rosterLayout?.sections?{[this.cfg.detailsTab]:DETAILS_HEADERS}:{})});
    if(this.personnel.sheets===this.sheets)this.personnel.initialized=true;
    else await this.personnel.ready();
    await this.reconcile();
    if(!this.initialDone){this.initialDone=true;log('Connected to Google Sheets. Initial roster synchronization complete.');}
  }
  syncNow(){
    if(!this.started||this.closed) return Promise.reject(new Error('Roster bot not ready'));
    return this.enqueue('Manual roster synchronization',()=>this.syncAll(),true);
  }
  async activeRows(){
    const raw=await this.sheets.getValues(`${quoteTab(this.activeTab)}!A2:F`);
    const rows=raw.filter(r=>String(r[0]||'')).map(r=>normalizeRow(r,6));const seen=new Set();
    for(const r of rows){if(!/^\d{16,22}$/.test(r[0])||seen.has(r[0]))throw new Error('Malformed or duplicate bot-owned active Discord ID; refusing overwrite');seen.add(r[0]);}
    return rows;
  }
  async archive(removed,reasons=new Map()){
    if(!removed.length)return;
    const old=(await this.sheets.getValues(`${quoteTab(this.historyTab)}!A2:H`)).map(r=>normalizeRow(r,8));
    const seen=new Set(old.map(r=>r[0]+'|'+r[4]));
    const now=iso();
    const add=removed.filter(r=>!seen.has(r[0]+'|'+r[4]))
      .map(r=>[...r,now,reasons.get(r[0])||'All LEO roles removed / no longer in Discord']);
    if(add.length)await this.sheets.appendValues(`${quoteTab(this.historyTab)}!A:H`,add);
  }
  async recentBan(id){
    const old=(await this.sheets.getValues(`${quoteTab(this.historyTab)}!A2:H`)).map(r=>normalizeRow(r,8));
    for(let i=old.length-1;i>=0;i--){
      const row=old[i];if(row[0]!==id)continue;
      const removed=Date.parse(row[6]);
      if(Number.isFinite(removed)&&Date.now()-removed<10*60000&&Date.now()>=removed&&row[7]!=='Banned from Discord')
        await this.sheets.putValues(`${quoteTab(this.historyTab)}!H${i+2}`,[['Banned from Discord']]);
      return;
    }
  }
  async writeActive(current,rows){
    if(JSON.stringify(current)===JSON.stringify(rows))return;
    const len=Math.max(current.length,rows.length);
    if(len)await this.sheets.putValues(`${quoteTab(this.activeTab)}!A2:F${len+1}`,[...rows,...Array.from({length:len-rows.length},()=>Array(6).fill(''))]);
    this.stats.lastWrite=iso();
    log('Active roster updated: '+rows.length+' members');
  }
  isEligible(member){
    const roles=new Set((member.roles||[]).map(String));
    // The SADLE membership role is the source of truth: removing this role
    // removes the officer even if they still hold a rank or subdivision role.
    return !member.user?.bot && (this.requiredRoleId ? roles.has(this.requiredRoleId) :
      [...this.membershipRoles].some(id=>roles.has(id)));
  }
  async reconcile(){
    // Fetch EVERYTHING successfully before touching a single active roster row.
    this.stats.lastCheck=iso();
    const list=await this.discord.fetchAll();
    const current=await this.activeRows();
    if(list.length===0&&current.length)throw new Error('Discord returned zero members; refusing destructive reconciliation');
    const memberById=new Map(list.map(m=>[String(m.user.id),m]));
    const desired=new Map(list.filter(m=>this.isEligible(m)).map(m=>[String(m.user.id),m]));
    const currentById=new Map(current.map(r=>[r[0],r]));
    const removed=current.filter(r=>!desired.has(r[0]));
    const reasons=new Map(removed.map(r=>[r[0],memberById.has(r[0])?'All qualifying LEO roles removed':'Left Discord / kicked']));
    // Ban events are sent through GuildModeration. REST is a safety net for
    // missed ban events across bot restarts or temporary gateway disconnects.
    if(typeof this.discord.fetchBan==='function'){
      for(const row of removed){
        if(memberById.has(row[0]))continue;
        try{if(await this.discord.fetchBan(row[0]))reasons.set(row[0],'Banned from Discord');}
        catch(e){log('Ban detail unavailable for '+row[0]+': '+e.message+'; archiving as left/kicked.');}
      }
    }
    await this.archive(removed,reasons);
    // Release callsign allocations only for previously active members that truly left.
    for(const row of removed){
      try{await this.originalRoster?.dropOne(row[0]);await this.callsigns.release(row[0],reasons.get(row[0]));}
      catch(e){log('Removal cleanup deferred for '+row[0]+': '+e.message);}
    }
    const ids=[...current.filter(r=>desired.has(r[0])).map(r=>r[0]),...Array.from(desired.keys()).filter(id=>!currentById.has(id)).sort((a,b)=>officer(desired.get(a)).localeCompare(officer(desired.get(b))))];
    const next=ids.map(id=>this.makeStable(desired.get(id),currentById.get(id)));
    await this.writeActive(current,next);
    await this.syncCareer(desired,current,true);
    if(this.roleMappingReliable){
      for(const [id,member] of desired)if(!mainRankEntry(member,this.ranks))
        await this.callsigns.release(id,'LEO rank removed (membership remains)');
      const slots=await this.originalRoster?.callCandidates(desired.values(),this.ranks);
      const summary=await this.callsigns.update(desired.values(),this.ranks,null,true,slots);
      if(summary.changed||summary.detailsUpdated)log('Callsigns auto-synced: '+summary.changed+' changed, '+summary.detailsUpdated+' detail rows.');
      await this.announceCallsignChanges(summary.announcements);
      await this.syncOriginalRankTabs(desired.values(),true);
    }
    this.stats.lastCheckSuccess=iso();
    this.stats.checkedMembers=list.length;this.stats.eligibleMembers=desired.size;
    log('Checked '+list.length+' Discord members; '+desired.size+' eligible for SADLE.');
  }
  async syncOriginalRankTabs(members,full=false){
    if(!this.originalRoster)return {success:true,skipped:true};
    if(!this.roleMappingReliable)return {success:false,skipped:true,error:'Current rank mapping is incomplete'};
    try{
      const rosterMembers=Array.from(members);
      const profiles=await this.personnel.profiles();
      const withNames=rosterMembers.map(m=>{
        const name=String(profiles.get(String(m.user?.id))?.data?.[6]||'').trim();
        return name?{...m,nick:name}:m;
      });
      await this.originalRoster.sync(withNames,this.ranks,{full});
      // Summaries update ONLY columns already on the main roster. Detailed strike
      // reasons, removals and appeals are never written into those cells.
      const allStrikes=await this.personnel.rows('strikes',12);
      const active=new Map(),knownStrikeIds=new Set();
      for(const {data:r} of allStrikes){if(r[1]!==String(this.cfg.guildId))continue;
        knownStrikeIds.add(r[2]);if(r[8]==='Active')active.set(r[2],(active.get(r[2])||0)+1);
      }
      for(const member of withNames){
        const id=String(member.user?.id||'');if(!id)continue;
        const profile=profiles.get(id)?.data;
        if(!profile&&!knownStrikeIds.has(id))continue;
        const fields={};
        if(profile){
          const {decodeSubdivisions}=require('./personnel');
          fields.subdivision=decodeSubdivisions(profile[3]).join(', ');
          try{fields.certifications=JSON.parse(profile[4]||'[]').join(', ');}catch(_){throw Error('Invalid certifications for '+id);}
          if(profile[5])fields.status=profile[5];
        }
        if(knownStrikeIds.has(id))fields.strikes=String(active.get(id)||0);
        if(Object.keys(fields).length)await this.originalRoster.updateOfficerFields(id,fields);
      }
      this.originalRoster.stats.lastError=null;
      this.stats.lastRosterSyncSuccess=iso();this.stats.lastRosterSyncError=null;
      return {success:true};
    }catch(e){this.originalRoster.stats.lastError=String(e?.message||e);this.stats.lastRosterSyncError=this.originalRoster.stats.lastError;log('Original roster sync skipped (backend preserved): '+this.originalRoster.stats.lastError);return {success:false,error:String(e?.message||e)};}
  }
  async careerRows(){
    return (await this.sheets.getValues(`${quoteTab(this.careerTab)}!A2:J`))
      .filter(r=>String(r[0]||'')).map(r=>normalizeRow(r,10));
  }
  async writeCareer(current,next){
    if(JSON.stringify(current)===JSON.stringify(next))return;
    const len=Math.max(current.length,next.length);
    if(len)await this.sheets.putValues(`${quoteTab(this.careerTab)}!A2:J${len+1}`,
      [...next,...Array.from({length:len-next.length},()=>Array(10).fill(''))]);
    log('Career roster updated: '+next.length+' members.');
  }
  async removeCareerMember(id){
    const current=await this.careerRows();
    await this.writeCareer(current,current.filter(r=>r[0]!==id));
  }
  async appendCareerEvents(events){
    if(!events.length)return;
    const old=(await this.sheets.getValues(`${quoteTab(this.rankHistoryTab)}!A2:H`));
    const ids=new Set(old.map(r=>String(r[0]||'')));
    const newRows=events.filter(x=>!ids.has(x[0]));
    if(newRows.length)await this.sheets.appendValues(`${quoteTab(this.rankHistoryTab)}!A:H`,newRows);
    if(newRows.length)log('Personnel history: '+newRows.map(x=>x[3]).join(', '));
  }
  async syncCareer(desired,previousActive,full){
    // Without a successful role-list lookup, missing names could falsely appear
    // as lost ranks/certifications. Fail closed on historical events.
    if(!this.roleMappingReliable){
      log('Career sync skipped: Discord role-name mapping not available; no false promotion or demotion will be recorded.');return;
    }
    const old=await this.careerRows(),oldMap=new Map(old.map(r=>[r[0],r]));
    const activeMap=new Map(previousActive.map(r=>[r[0],r]));
    const incoming=[];const newRows=[];
    for(const [id,member] of desired){
      const previous=oldMap.get(id);
      const names=trackedNames(member,this.ranks);
      const snapshot=JSON.stringify(names);
      const main=mainRankEntry(member,this.ranks);
      const currentRank=String(main?.label||main?.roleName||'');
      const viewRank=rankFor(member,this.ranks);
      const joined=previous?.[3]||activeMap.get(id)?.[4]||iso();
      let row;
      if(!previous){
        // Initial migration and first joins establish a baseline, not an
        // invented promotion from an unknown old rank.
        row=[id,officer(member),viewRank,joined,'','','',snapshot,currentRank,iso()];
      }else{
        row=previous.slice();row[1]=officer(member);row[2]=viewRank;row[3]=joined;
        let oldNames;
        try{oldNames=JSON.parse(previous[7]||'[]');if(!Array.isArray(oldNames))throw Error('Invalid roles');}
        catch(e){throw new Error('Career role snapshot malformed for '+id+'; refusing history changes');}
        const normalizedOld=JSON.stringify([...new Set(oldNames.map(String))].sort());
        const originalMain=String(previous[8]||'');
        const lastKnown=originalMain||oldNames.find(isRankName)||'';
        const prevRank=isRankName(previous[2]) ? String(previous[2]) : '';
        const previouslyAssigned=prevRank||originalMain;
        const events=[];
        if(currentRank && currentRank!==prevRank){
          let type='Rank Assigned';
          if(lastKnown){
            const before=rankLevel(lastKnown),after=rankLevel(currentRank);
            type=after>before?'Promotion':after<before?'Demotion':'Rank Updated';
          }
          events.push({type,old:lastKnown,next:currentRank,details:'SADLE rank transition'});
          row[4]=lastKnown;row[5]=type;row[6]=iso();
        }else if(!currentRank && prevRank){
          // No current core rank: preserve the prior rank so a remove-then-add
          // sequence still classifies the next assignment correctly.
          events.push({type:'Rank Removed',old:prevRank,next:'',details:'SADLE rank role removed (membership remains)'});
        }
        const beforeExtras=new Set(oldNames.filter(x=>!isRankName(x)));
        const afterExtras=new Set(names.filter(x=>!isRankName(x)));
        for(const x of [...afterExtras].filter(x=>!beforeExtras.has(x)))events.push({type:'Role Added',old:'',next:x,details:'Non-rank SADLE role assigned'});
        for(const x of [...beforeExtras].filter(x=>!afterExtras.has(x)))events.push({type:'Role Removed',old:x,next:'',details:'Non-rank SADLE role removed'});
        if(events.length){
          const stamp=iso();
          const basis=previous[9]||previous[3]||'baseline';
          for(const ev of events){
            incoming.push([hashEvent(id,basis,normalizedOld+'->'+snapshot,ev),id,officer(member),ev.type,ev.old,ev.next,stamp,ev.details]);
          }
          row[9]=stamp;
        }
        row[7]=snapshot;
        // Preserve the last real rank through periods of no rank assignment.
        row[8]=currentRank||lastKnown;
      }
      newRows.push(row);
    }
    // Deduplicate and journal BEFORE committing new state. A retry after a
    // partial write can re-use the same event ID rather than double-log it.
    await this.appendCareerEvents(incoming);
    const byId=new Map(newRows.map(r=>[r[0],r]));
    const next=full ? [...old.filter(r=>byId.has(r[0])).map(r=>byId.get(r[0])),
      ...newRows.filter(r=>!oldMap.has(r[0]))] : old.map(r=>byId.get(r[0])||r).concat(newRows.filter(r=>!oldMap.has(r[0])));
    await this.writeCareer(old,next);
  }
  async announceCallsignChanges(announcements){
    if(!this.callsignChannelId||!announcements?.length)return;
    const levelByPrefix={M:10,K:20,I:30,G:40,E:50,C:60,A:70,X:80,L:90};
    const labelByPrefix={M:'Probationary',K:'LEO 1',I:'Senior LEO',G:'Corporal',E:'Sergeant',C:'Lieutenant',A:'Captain',X:'Commander',L:'HQ'};
    for(const event of announcements){
      const before=String(event.oldCallsign||'');const after=String(event.newCallsign||'');
      const oldPrefix=before.split('-')[0].toUpperCase(),newPrefix=after.split('-')[0].toUpperCase();
      const oldLevel=levelByPrefix[oldPrefix]||0,newLevel=levelByPrefix[newPrefix]||0;
      const isRankChange=before&&oldPrefix!==newPrefix;
      const message=['**SADLE CALLSIGN UPDATED**',`<@${event.userId}>`];
      if(before)message.push(`${labelByPrefix[oldPrefix]||'Old Rank'} ${before} → ${event.newRank||labelByPrefix[newPrefix]||'New Rank'} ${after}`);
      else message.push(`${event.newRank||labelByPrefix[newPrefix]||'LEO'} ${after}`);
      if(isRankChange)message.push(newLevel>oldLevel?'PROMOTED':newLevel<oldLevel?'DEMOTED':'RANK UPDATED');
      else message.push(before?'CALLSIGN UPDATED':'NEW CALLSIGN');
      if(event.actor&&event.actor!=='AUTO')message.push(`By: <@${event.actor}>`);
      try{
        await this.discord.sendChannelMessage(this.callsignChannelId,message.join('\n'),event.userId);
        this.stats.lastCallsignAnnouncement=iso();this.stats.lastCallsignAnnouncementError=null;
      }catch(e){
        this.stats.lastCallsignAnnouncementError=String(e?.message||e).slice(0,200);
        log('Callsign saved; Discord announcement failed: '+this.stats.lastCallsignAnnouncementError);
      }
    }
  }
  async testCallsignChannel(){
    if(!this.callsignChannelId)throw Error('SADLE callsign channel not configured in sadleroaster/config.json');
    if(typeof this.discord.sendChannelMessage!=='function')throw Error('Discord adapter cannot send channel messages');
    await this.discord.sendChannelMessage(this.callsignChannelId,
      '✅ **SADLE Roster Bot — Callsign Logging Test**\nAutomatic callsign announcements are connected. New assignments, rank changes and Sergeant+ /callsign changes will post here.');
    this.stats.lastCallsignAnnouncement=iso();
    this.stats.lastCallsignAnnouncementError=null;
    return this.callsignChannelId;
  }
  async changeRank(action,actorId,targetId,toRoleName,reason,approval={}){
    if(!['promote','demote'].includes(action))throw Error('Invalid personnel action');
    if(!/^[0-9]{16,22}$/.test(String(actorId))||!/^[0-9]{16,22}$/.test(String(targetId)))throw Error('Invalid member ID');
    const testingOverride=isTestingOverride(actorId);
    if(!testingOverride&&String(actorId)===String(targetId))throw Error('You cannot change your own rank.');
    if(!String(reason||'').trim())throw Error('A reason is required.');
    return this.enqueue('Rank '+action,async()=>{
      await this.resolveRanks(true);
      if(!this.roleMappingReliable)throw Error('Current rank mapping is incomplete; no roles changed.');
      const [actor,target,roles]=await Promise.all([this.discord.fetchMember(actorId),this.discord.fetchMember(targetId),this.discord.fetchRoles()]);
      if(!actor||!target)throw Error('Both officers must be in this Discord server.');
      if((!testingOverride&&!this.isEligible(actor))||!this.isEligible(target))throw Error('Both members must belong to this department.');
      const a=mainRankEntry(actor,this.ranks),t=mainRankEntry(target,this.ranks);
      const actorLevel=a?rankLevel(a.roleName||a.label):0,targetLevel=t?rankLevel(t.roleName||t.label):0;
      if(!testingOverride&&actorLevel<50)throw Error('Only Sergeant and higher can use personnel commands.');
      if(!testingOverride&&targetLevel>=actorLevel)throw Error('You cannot change a member of equal or higher rank.');
      if(!targetLevel)throw Error('Target has no mapped LEO rank.');
      const wanted=normalizedRoleName(toRoleName),wantedLevel=rankLevel(toRoleName);
      const desired=this.ranks.find(r=>rankLevel(r.roleName||r.label)>0 &&
       (normalizedRoleName(r.roleName||r.label)===wanted||
        normalizedRoleName(r.label)===wanted||
        (wantedLevel>0&&rankLevel(r.roleName||r.label)===wantedLevel)));
      if(!desired||!desired.roleId)throw Error('Target rank not configured/resolved: '+toRoleName);
      const destinationLevel=rankLevel(desired.roleName||desired.label);
      if(!destinationLevel||(!testingOverride&&destinationLevel>=actorLevel))throw Error('You cannot assign a rank equal to or above yours.');
      if(action==='promote'&&destinationLevel<=targetLevel)throw Error('The selected rank is not a promotion.');
      if(action==='demote'&&destinationLevel>=targetLevel)throw Error('The selected rank is not a demotion.');
      const me=await this.discord.botMember(this.client.user.id);
      const botIds=new Set(me?.roles||[]);
      const botTop=Math.max(0,...(roles||[]).filter(r=>botIds.has(r.id)).map(r=>Number(r.position)||0));
      const affected=[...(this.ranks||[]).filter(r=>(target.roles||[]).includes(r.roleId)&&rankLevel(r.roleName||r.label)>0),desired];
      if(affected.some(r=>!r.discordPosition||r.discordPosition>=botTop))throw Error('Place the bot role above all managed LEO rank roles.');
      const beforeRoles=[...(target.roles||[])];
      const removed=[];
      try{
        // Add the new role FIRST, then remove old ranks. If adding fails, target stays unchanged.
        if(!beforeRoles.includes(desired.roleId))await this.discord.mutateMemberRole(targetId,desired.roleId,'PUT');
        for(const role of affected){
          if(role.roleId===desired.roleId||!beforeRoles.includes(role.roleId))continue;
          await this.discord.mutateMemberRole(targetId,role.roleId,'DELETE');removed.push(role.roleId);
        }
      }catch(e){
        // Best-effort restore Discord state on partial change, then fail safely.
        for(const id of removed)await this.discord.mutateMemberRole(targetId,id,'PUT').catch(()=>{});
        if(!beforeRoles.includes(desired.roleId))await this.discord.mutateMemberRole(targetId,desired.roleId,'DELETE').catch(()=>{});
        throw Error('Discord rank update incomplete; attempted rollback. '+e.message);
      }
      const method=String(approval.type||'').trim();
      const approvedBy=String(approval.by||'').trim();
      const vote=String(approval.vote||'').trim();
      const displayName=String(target.nick||target.user?.global_name||target.user?.username||targetId);
      const previousCalls=await this.callsigns.data();
      const oldCall=previousCalls.byId.get(String(targetId))?.[1]||'';
      const updated={...target,roles:beforeRoles.filter(id=>!affected.some(r=>r.roleId===id)).concat(desired.roleId)};
      // Run synchronously inside this same queue to avoid a duplicate event race.
      let syncPending=false;
      try{const synced=await this.refreshOne(targetId,updated,{skipAnnouncements:true});if(synced?.success===false)syncPending=true;}
      catch(e){syncPending=true;log('Rank changed in Discord; Sheets update pending retry for '+targetId+': '+e.message);}
      let newCall='pending';
      try{const calls=await this.callsigns.data();newCall=calls.byId.get(String(targetId))?.[1]||'pending';}
      catch(e){syncPending=true;log('Rank call lookup pending: '+e.message);}
      const message=['**SADLE CALLSIGN UPDATED**',`Officer: <@${targetId}>`,
        `${String(t?.label||t?.roleName||'Unknown')} → ${String(desired.label||desired.roleName)}`,
        `${action==='promote'?'PROMOTED':'DEMOTED'}`,`Callsign: ${oldCall||'-'} → ${newCall}`, 
        `By: <@${actorId}>`,`Reason: ${String(reason).slice(0,350)}`];
      if(method)message.push(`Approval Type: ${method.slice(0,100)}`);
      if(approvedBy)message.push(`Approved By: ${approvedBy.slice(0,120)}`);
      if(vote)message.push(`Vote: ${vote.slice(0,120)}`);
      if(testingOverride)message.push('Testing Override: used');
      if(this.callsignChannelId)await this.discord.sendChannelMessage(this.callsignChannelId,message.join('\n'),targetId).catch(e=>{log('Rank changed, announcement failed: '+e.message);});
      return {rank:desired.label||desired.roleName,callsign:newCall,officer:displayName,syncPending};
    },true);
  }
  async personnelPermission(actorId,targetId){
    if(!/^\d{16,22}$/.test(String(actorId))||!/^\d{16,22}$/.test(String(targetId)))throw Error('Invalid officer ID');
    const testingOverride=isTestingOverride(actorId);
    if(!testingOverride&&String(actorId)===String(targetId))throw Error('You cannot change or privately inspect your own personnel record using supervisor commands.');
    await this.resolveRanks(true);
    if(!this.roleMappingReliable)throw Error('Current LEO rank mapping is incomplete. No personnel changes made.');
    const [actor,target]=await Promise.all([this.discord.fetchMember(String(actorId)),this.discord.fetchMember(String(targetId))]);
    if(!actor||!target)throw Error('Supervisor and officer must be in this Discord server.');
    if((!testingOverride&&!this.isEligible(actor))||!this.isEligible(target))throw Error('Both members must be in this department.');
    const actorRank=mainRankEntry(actor,this.ranks),targetRank=mainRankEntry(target,this.ranks);
    const actorLevel=actorRank?rankLevel(actorRank.roleName||actorRank.label):0;
    const targetLevel=targetRank?rankLevel(targetRank.roleName||targetRank.label):0;
    if(!testingOverride&&actorLevel<50)throw Error('Only Sergeant and higher can use personnel commands.');
    if(!targetLevel||(!testingOverride&&targetLevel>=actorLevel))throw Error('You can only manage an officer with a lower LEO rank than yours.');
    return {actor,target,actorLevel,targetLevel,name:officer(target)};
  }
  async personnelNotice(action,targetId,actorId,summary){
    if(!this.personnelLogChannelId)return;
    // Personnel records remain PRIVATE to staff; the regular callsign channel is never used.
    const msg=`**${this.department} PERSONNEL — ${action}**\nOfficer: <@${targetId}>\nBy: <@${actorId}>${isTestingOverride(actorId)?' (Testing Override)':''}\n${String(summary||'').slice(0,1200)}`;
    await this.discord.sendChannelMessage(this.personnelLogChannelId,msg,targetId).catch(e=>log('Private personnel log failed (Sheet saved): '+e.message));
  }
  async managePersonnel(action,actorId,targetId,fields={}){
    const changes=new Set(['editofficer','setsubdivision','certification','removeofficer','note','strike','voidstrike','removestrike','appealstrike']);
    const reads=new Set(['officer','notes','strikes']);
    if(!changes.has(action)&&!reads.has(action))throw Error('Unsupported personnel command');
    return this.enqueue('Personnel '+action,async()=>{
      const {target,name}=await this.personnelPermission(actorId,targetId);
      await this.personnel.ready();
      const profile=await this.personnel.profile(targetId);
      const makeAudit=async(field,before,after,reason='')=>this.personnel.recordAction({id:targetId,officer:name,action,field,before,after,reason,actor:actorId});
      if(action==='officer'){
        const strikes=await this.personnel.strikes(targetId);const notes=await this.personnel.notes(targetId);
        const call=(await this.callsigns.data()).byId.get(String(targetId))?.[1]||'—';
        return {name,call,profile,activeStrikes:strikes.filter(x=>x.state==='Active').length,totalStrikes:strikes.length,noteCount:notes.length};
      }
      if(action==='notes')return await this.personnel.notes(targetId);
      if(action==='strikes')return await this.personnel.strikes(targetId);
      if(action==='note'){
        const note=String(fields.note||'').trim();const id=await this.personnel.addNote({id:targetId,officer:name,actor:actorId,note});
        await makeAudit('note','',id,'Note history stored on private Sheets');
        // The note itself may be displayed in the EXISTING Notes cell, if mapped.
        // Never create a column or append a log to the visible roster.
        let rosterUpdated=false,rosterPending=false;
        if(this.originalRoster?.appendOfficerNote){
          try{const result=await this.originalRoster.appendOfficerNote(targetId,{note,actor:actorId});rosterUpdated=Boolean(result?.updated);}
          catch(e){rosterPending=true;log('Existing roster Notes cell update pending: '+e.message);}
        }
        await this.personnelNotice('NOTE ADDED',targetId,actorId,`Note ID: ${id}; main roster Notes cell: ${rosterUpdated?'updated':rosterPending?'pending':'not mapped'}`);
        return {id,rosterUpdated,rosterPending};
      }
      if(action==='strike'){
        const id=await this.personnel.addStrike({id:targetId,officer:name,actor:actorId,reason:fields.reason,severity:fields.severity});
        await makeAudit('strike','',id,fields.reason);
        await this.personnelNotice('STRIKE ADDED',targetId,actorId,`Severity: ${fields.severity||'Standard'}\nStrike ID: ${id} (reason stored on private spreadsheet)`);
        const count=(await this.personnel.strikes(targetId)).filter(x=>x.state==='Active').length;
        await this.syncOriginalRankTabs([target],false);
        return {id,count};
      }
      if(['voidstrike','removestrike','appealstrike'].includes(action)){
        const outcome={voidstrike:'Voided',removestrike:'Removed',appealstrike:'Appealed'}[action];
        const item=await this.personnel.resolveStrike({id:targetId,strikeId:fields.strikeId,actor:actorId,reason:fields.reason,outcome});
        await makeAudit('strike',item.id,outcome,fields.reason);
        await this.personnelNotice('STRIKE '+outcome.toUpperCase(),targetId,actorId,`Strike ID: ${item.id}\nOutcome: ${outcome} (details retained on private spreadsheet)`);
        const sync=await this.syncOriginalRankTabs([target],false);
        return {id:item.id,state:outcome,resolutionReason:item.resolutionReason,resolvedBy:item.resolvedBy,resolvedAt:item.resolvedAt,count:(await this.personnel.strikes(targetId)).filter(x=>x.state==='Active').length,mirrorPending:sync?.success===false};
      }
      if(action==='removeofficer'){
        if(!String(fields.reason||'').trim())throw Error('A reason is required to remove an officer.');
        const roles=await this.discord.fetchRoles();const me=await this.discord.botMember(this.client.user.id);
        const botRoleIds=new Set((me?.roles||[]).map(String));
        const top=Math.max(0,...(roles||[]).filter(r=>botRoleIds.has(String(r.id))).map(r=>Number(r.position)||0));
        const managedIds=new Set([...this.membershipRoles,this.requiredRoleId,...this.ranks.filter(r=>rankLevel(r.roleName||r.label)>0).map(r=>String(r.roleId||''))].filter(Boolean));
        const removed=(target.roles||[]).filter(id=>managedIds.has(String(id)));
        for(const id of removed){const role=(roles||[]).find(r=>String(r.id)===String(id));if(!role||!Number(role.position)||Number(role.position)>=top)throw Error('Bot role must be above every rank/membership role being removed.');}
        const completed=[];
        try{for(const roleId of removed){await this.discord.mutateMemberRole(targetId,roleId,'DELETE');completed.push(roleId);}}
        catch(e){for(const id of completed.reverse())await this.discord.mutateMemberRole(targetId,id,'PUT').catch(()=>{});throw Error('Role removal failed; attempted rollback: '+e.message);}
        let pending=false;
        try{await this.removeOne(String(targetId),'Removed by '+actorId+': '+String(fields.reason).slice(0,200));}
        catch(e){pending=true;log('Removal done in Discord; roster sync pending: '+e.message);}
        await this.personnel.changeProfile(targetId,name,actorId,{status:'Removed'});
        await makeAudit('membership','Active','Removed',fields.reason);
        await this.personnelNotice('REMOVED',targetId,actorId,`Reason: ${fields.reason}\nRoster sync: ${pending?'pending retry':'complete'}`);
        return {removedRoles:removed.length,syncPending:pending};
      }
      let change={},field='',previous='',newValue='',reason=String(fields.reason||'').trim();
      if(action==='editofficer'){
        if(!['name','status'].includes(fields.field))throw Error('Officer field must be name or status.');
        newValue=String(fields.value||'').trim();
        if(!newValue||newValue.length>120)throw Error('Value must be 1–120 characters.');
        field=fields.field;
        if(field==='name'){previous=profile.nameOverride;change.nameOverride=newValue;}
        else {previous=profile.status;change.status=newValue;}
      }else if(action==='setsubdivision'){
        field='subdivision';previous=profile.subdivisions.join(', ');
        const {decodeSubdivisions}=require('./personnel');
        const verb=String(fields.operation||'add').trim().toLowerCase();
        if(!['add','remove','clear','replace'].includes(verb))throw Error('Subdivision action must be add, remove, clear or replace.');
        const incoming=decodeSubdivisions(String(fields.subdivision||''));
        if(verb!=='clear'&&!incoming.length)throw Error('Select one or more subdivisions, separated by commas.');
        let next=profile.subdivisions.slice();
        if(verb==='clear')next=[];
        else if(verb==='replace')next=incoming;
        else if(verb==='add')for(const value of incoming){if(!next.some(x=>x.toLowerCase()===value.toLowerCase()))next.push(value);}
        else for(const value of incoming)next=next.filter(x=>x.toLowerCase()!==value.toLowerCase());
        if(next.length>20)throw Error('Maximum 20 subdivisions per officer');
        change.subdivisions=next;newValue=next.join(', ');
      }else if(action==='certification'){
        field='certifications';previous=profile.certifications.join(', ');
        const cert=String(fields.certification||'').trim();if(!cert||cert.length>100)throw Error('Certification must be 1–100 characters.');
        const verb=String(fields.operation||'').toLowerCase();if(!['add','remove'].includes(verb))throw Error('Certification operation must be add or remove.');
        const certs=profile.certifications.slice();const index=certs.findIndex(x=>x.toLowerCase()===cert.toLowerCase());
        if(verb==='add'&&index<0)certs.push(cert);else if(verb==='remove'&&index>=0)certs.splice(index,1);
        if(certs.length>30)throw Error('Maximum 30 certifications per officer.');
        change.certifications=certs;newValue=certs.join(', ');
      }
      const updated=await this.personnel.changeProfile(targetId,name,actorId,change);
      if(!updated.changed)return {changed:false};
      await makeAudit(field,previous,newValue,reason);
      // The separate bot-owned profile is authoritative; mapped custom fields are best-effort
      // and cannot silently overwrite unrecognized cells or broken section mappings.
      let mirrorPending=false;
      const sync=await this.syncOriginalRankTabs([target],false);
      mirrorPending=sync?.success===false;
      await this.personnelNotice('PROFILE UPDATED',targetId,actorId,`${field}: ${newValue||'(cleared)'}${reason?'\nReason: '+reason:''}`);
      return {changed:true,mirrorPending};
    },true);
  }
  async setCallsign(actorId,targetId,text){
    const requested=CallsignManager.cleanInput(text);
    if(!/^\d{16,22}$/.test(String(actorId))||!/^\d{16,22}$/.test(String(targetId)))
      throw new Error('Invalid Discord member ID');
    return this.enqueue('Sergeant callsign change',async()=>{
      await this.resolveRanks(true);
      if(!this.roleMappingReliable)throw Error('Cannot verify current SADLE ranks. No changes made.');
      // REST lookup is mandatory; never trust client-supplied role/permission claims.
      const testingOverride=isTestingOverride(actorId);
      const actor=await this.discord.fetchMember(String(actorId));
      const target=await this.discord.fetchMember(String(targetId));
      if(!actor||(!testingOverride&&!this.isEligible(actor)))throw Error('Only SADLE Sergeant and higher can use /callsign.');
      const rank=mainRankEntry(actor,this.ranks);
      if(!testingOverride&&(!rank||rankLevel(rank.roleName||rank.label)<50))
        throw Error('Only SADLE Sergeant and higher can use /callsign.');
      if(!testingOverride&&String(actorId)===String(targetId))throw Error('You cannot change your own callsign through supervisor commands.');
      if(!target||!this.isEligible(target))throw Error('The selected officer does not have the SADLE membership role.');
      const targetRank=mainRankEntry(target,this.ranks);
      if(!targetRank||(!testingOverride&&rankLevel(targetRank.roleName||targetRank.label)>=rankLevel(rank.roleName||rank.label)))
        throw Error('Cannot change callsign for equal or higher-ranked officer.');
      const slots=await this.originalRoster?.callCandidates([target],this.ranks);
      const result=await this.callsigns.update([target],this.ranks,
        {id:String(targetId),actor:String(actorId),value:requested},true,slots);
      await this.announceCallsignChanges(result.announcements);
      const mirrored=await this.syncOriginalRankTabs([target]);
      if(mirrored?.success===false)throw Error('Callsign saved in private data, but the visible roster update is pending: '+mirrored.error);
      log('Callsign changed for '+targetId+' by '+actorId+' to '+result.callsign);
      return result.callsign;
    },true);
  }
  makeStable(member,old){const row=makeRow(member,this.ranks);if(old){row[4]=old[4]||row[4];if(old[1]===row[1]&&old[2]===row[2]&&old[3]===row[3])row[5]=old[5]||row[5];}return row;}
  async refreshOne(id,gatewayMember=null,{skipAnnouncements=false}={}){
    try{await this.resolveRanks();}
    catch(e){log('Rank lookup unavailable during event: '+e.message);}
    // Gateway member update packets include the complete role list; using them
    // avoids delays from an eventually-consistent Discord REST member lookup.
    const member=(gatewayMember && Array.isArray(gatewayMember.roles) &&
      String(gatewayMember.user?.id||'')===id) ? gatewayMember : await this.discord.fetchMember(id);
    if(!member){
      let reason='Left Discord / kicked';
      if(typeof this.discord.fetchBan==='function'){
        try{if(await this.discord.fetchBan(id))reason='Banned from Discord';}catch(_){}
      }
      await this.removeOne(id,reason);return;
    }
    const current=await this.activeRows(),idx=current.findIndex(r=>r[0]===id);
    const eligible=this.isEligible(member);
    if(!eligible){await this.removeOne(id,'All qualifying LEO roles removed',current);return;}
    const next=current.slice(),row=this.makeStable(member,idx<0?null:current[idx]);
    if(idx<0)next.push(row);else next[idx]=row;
    await this.writeActive(current,next);
    await this.syncCareer(new Map([[id,member]]),current,false);
    if(this.roleMappingReliable){
      if(!mainRankEntry(member,this.ranks)){
        await this.callsigns.release(id,'LEO rank removed (membership remains)');
        return await this.syncOriginalRankTabs([member]);
      }
      const slots=await this.originalRoster?.callCandidates([member],this.ranks);
      const result=await this.callsigns.update([member],this.ranks,null,true,slots);
      if(!skipAnnouncements)await this.announceCallsignChanges(result.announcements);
      return await this.syncOriginalRankTabs([member]);
    }
  }
  async removeOne(id,reason,providedCurrent=null){
    const current=providedCurrent||await this.activeRows();
    const found=current.find(r=>r[0]===id);
    if(found){await this.archive([found],new Map([[id,reason]]));await this.writeActive(current,current.filter(r=>r[0]!==id));}
    else if(reason==='Banned from Discord')await this.recentBan(id);
    await this.removeCareerMember(id);
    if(this.originalRoster){try{await this.originalRoster.dropOne(id);}catch(e){this.originalRoster.stats.lastError=String(e?.message||e);log('Original roster removal skipped: '+e.message);}}
    await this.callsigns.release(id,reason);
  }
  stop(){this.closed=true;if(this.timer)clearInterval(this.timer);for(const t of this.memberDebounces.values())clearTimeout(t);this.memberDebounces.clear();for(const [event,fn] of this.listeners)this.client.off(event,fn);this.listeners=[];}
}
function installSadleRosterSync(client,config){return new SadleRoster(client,config).start();}
module.exports={installSadleRosterSync,SadleRoster,DiscordRest,ACTIVE_HEADERS,HISTORY_HEADERS,CAREER_HEADERS,RANK_HISTORY_HEADERS,rankFor,rankLevel,mainRankEntry,trackedNames,normalizedRoleName};
