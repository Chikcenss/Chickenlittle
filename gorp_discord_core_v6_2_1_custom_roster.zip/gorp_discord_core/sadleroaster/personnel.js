'use strict';
// Bot-owned personnel records. Never write private notes/strikes into public rank sections.
// Each row is scoped by guild ID, allowing multiple Discord communities to share a backend.
const {randomUUID} = require('node:crypto');
const {quoteTab} = require('./googleSheets');
const PROFILE_HEADERS = ['Guild ID','Discord ID','Officer','Subdivision','Certifications JSON','Status','Name Override','Updated (UTC)','Updated By'];
const NOTE_HEADERS = ['Note ID','Guild ID','Discord ID','Officer','Note','Added By','Date (UTC)'];
const STRIKE_HEADERS = ['Strike ID','Guild ID','Discord ID','Officer','Severity','Reason','Added By','Date (UTC)','State','Voided By','Voided (UTC)','Void Reason'];
const ACTION_HEADERS = ['Action ID','Guild ID','Discord ID','Officer','Action','Field','Previous Value','New Value','Reason','Changed By','Date (UTC)'];
const STRIKE_EVENT_HEADERS = ['Event ID','Guild ID','Discord ID','Strike ID','Officer','Event','Explanation','Changed By','Date (UTC)'];
const text = x => String(x ?? '').trim();
const max = (x,n) => text(x).slice(0,n);
const time = () => new Date().toISOString();
function safeCell(x,n=1000){const value=max(x,n);return /^[=+@\t\r]/.test(value)?'\''+value:value;}
function decodeSubdivisions(raw){
 const value=text(raw);if(!value)return [];
 let entries;
 if(value.startsWith('[')){
  try{entries=JSON.parse(value);}catch(_){throw Error('Invalid subdivision JSON in personnel profile');}
  if(!Array.isArray(entries)||entries.some(x=>typeof x!=='string'))throw Error('Invalid subdivision JSON in personnel profile');
 }else entries=value.split(','); // Migration of v5 single-string and comma-separated profiles.
 const list=[];for(const item of entries){const name=text(item);if(!name)continue;
  if(name.length>80)throw Error('Subdivision must be at most 80 characters');
  if(!list.some(x=>x.toLowerCase()===name.toLowerCase()))list.push(name);
 }
 if(list.length>20)throw Error('Maximum 20 subdivisions per officer');return list;
}
function decodeCerts(raw){if(!text(raw))return [];try{const a=JSON.parse(raw);if(!Array.isArray(a)||a.some(x=>typeof x!=='string'))throw Error('not array');return a;}catch(_){throw Error('Invalid certifications JSON in bot-managed profile; repair it before editing');}}
class PersonnelLedger{
 constructor(sheets,guildId,opts={}){
  this.sheets=sheets;this.guildId=String(guildId);
  this.tabs={profile:opts.profileTab||'BOT Personnel Profiles',notes:opts.notesTab||'BOT Personnel Notes',strikes:opts.strikesTab||'BOT Personnel Strikes',actions:opts.actionsTab||'BOT Personnel Actions',strikeEvents:opts.strikeEventsTab||'BOT Personnel Strike Events'};
  if(new Set(Object.values(this.tabs)).size!==5)throw Error('Personnel tabs must be unique');
  this.initialized=false;
 }
 schema(){return {[this.tabs.profile]:PROFILE_HEADERS,[this.tabs.notes]:NOTE_HEADERS,[this.tabs.strikes]:STRIKE_HEADERS,[this.tabs.actions]:ACTION_HEADERS,[this.tabs.strikeEvents]:STRIKE_EVENT_HEADERS};}
 async ready(){if(this.initialized)return;await this.sheets.ensureTabs(this.schema());this.initialized=true;}
 async rows(kind,width){await this.ready();return (await this.sheets.getValues(`${quoteTab(this.tabs[kind])}!A2:${String.fromCharCode(64+width)}`)).map((r,i)=>({index:i+2,data:Array.from({length:width},(_,j)=>text(r[j]))}));}
 async append(kind,row,width){await this.ready();if(row.length!==width)throw Error('Personnel row width mismatch');await this.sheets.appendValues(`${quoteTab(this.tabs[kind])}!A:${String.fromCharCode(64+width)}`,[row]);}
 async profiles(){const map=new Map();for(const {index,data} of await this.rows('profile',9)){if(data[0]!==this.guildId)continue;if(map.has(data[1]))throw Error('Duplicate bot personnel profile for '+data[1]);map.set(data[1],{index,data});}return map;}
 async profile(id){const p=(await this.profiles()).get(String(id));if(!p)return {guildId:this.guildId,id:String(id),officer:'',subdivision:'',subdivisions:[],certifications:[],status:'',nameOverride:'',updated:'',by:''};const r=p.data;return {guildId:r[0],id:r[1],officer:r[2],subdivision:decodeSubdivisions(r[3]).join(', '),subdivisions:decodeSubdivisions(r[3]),certifications:decodeCerts(r[4]),status:r[5],nameOverride:r[6],updated:r[7],by:r[8]};}
 async changeProfile(id,officer,actor,change){
  await this.ready();const profiles=await this.profiles(),old=profiles.get(String(id));
  const previous=old?.data||[this.guildId,String(id),'','','[]','','','',''];
  const next=previous.slice();next[2]=safeCell(officer,120);next[7]=time();next[8]=String(actor);
  if(change.subdivisions!==undefined||change.subdivision!==undefined){
   const list=decodeSubdivisions(change.subdivisions!==undefined?JSON.stringify(change.subdivisions):change.subdivision);
   next[3]=JSON.stringify(list);
  }
  if(change.certifications!==undefined)next[4]=JSON.stringify(change.certifications);
  if(change.status!==undefined)next[5]=safeCell(change.status,120);
  if(change.nameOverride!==undefined)next[6]=safeCell(change.nameOverride,120);
  const changed=next.some((v,i)=>i>=3&&i<=6&&v!==previous[i]);
  if(!changed)return {changed:false,profile:await this.profile(id)};
  if(old)await this.sheets.putValues(`${quoteTab(this.tabs.profile)}!A${old.index}:I${old.index}`,[next]);
  else await this.append('profile',next,9);
  return {changed:true,profile:await this.profile(id)};
 }
 async recordAction({id,officer,action,field='',before='',after='',reason='',actor}){
  const eventId=randomUUID();
  await this.append('actions',[eventId,this.guildId,String(id),safeCell(officer,120),safeCell(action,60),safeCell(field,80),safeCell(before,800),safeCell(after,800),safeCell(reason,900),String(actor),time()],11);
  return eventId;
 }
 async addNote({id,officer,actor,note}){
  if(!text(note)||text(note).length>1200)throw Error('Note must be 1–1200 characters');
  const uuid=randomUUID();await this.append('notes',[uuid,this.guildId,String(id),safeCell(officer,120),safeCell(note,1200),String(actor),time()],7);
  return uuid;
 }
 async notes(id){return (await this.rows('notes',7)).filter(x=>x.data[1]===this.guildId&&x.data[2]===String(id)).map(({data:r})=>({id:r[0],text:r[4],by:r[5],at:r[6]}));}
 async addStrike({id,officer,actor,reason,severity='Standard'}){
  if(!text(reason)||text(reason).length>1000)throw Error('Strike reason must be 1–1000 characters');
  const selected=['Verbal','Written','Final','Standard'].find(x=>x.toLowerCase()===text(severity||'Standard').toLowerCase());if(!selected)throw Error('Invalid severity (Verbal, Written, Final or Standard)');
  const uuid=randomUUID(),now=time();await this.append('strikes',[uuid,this.guildId,String(id),safeCell(officer,120),selected,safeCell(reason,1000),String(actor),now,'Active','','',''],12);
  await this.append('strikeEvents',[randomUUID(),this.guildId,String(id),uuid,safeCell(officer,120),'Issued',safeCell(reason,1000),String(actor),now],9);return uuid;
 }
 async strikes(id){return (await this.rows('strikes',12)).filter(x=>x.data[1]===this.guildId&&x.data[2]===String(id)).map(({index,data:r})=>({index,id:r[0],severity:r[4],reason:r[5],by:r[6],at:r[7],state:r[8],voidBy:r[9],voidAt:r[10],voidReason:r[11],officer:r[3],resolutionReason:r[11],resolvedBy:r[9],resolvedAt:r[10]}));}
 async strikeCounts(){
  const byId=new Map();
  for(const {data:r} of await this.rows('strikes',12)){
   if(r[1]!==this.guildId||r[8]!=='Active')continue;
   byId.set(r[2],(byId.get(r[2])||0)+1);
  }
  return byId;
 }
 async voidStrike({id,strikeId,actor,reason}){
  if(!text(reason)||text(reason).length>500)throw Error('Void reason is required (maximum 500 characters)');
  const found=(await this.strikes(id)).find(x=>x.id===String(strikeId));
  if(!found)throw Error('Strike not found for this officer');
  if(found.state!=='Active')throw Error('Strike already voided, removed or appealed');
  await this.resolveStrike({id,strikeId,actor,reason,outcome:'Voided'});
  return found;
 }
 async resolveStrike({id,strikeId,actor,reason,outcome}){
  const types=['Voided','Removed','Appealed'];if(!types.includes(outcome))throw Error('Invalid strike resolution');
  if(!text(reason)||text(reason).length>1000)throw Error('Strike resolution explanation must be 1–1000 characters');
  const found=(await this.strikes(id)).find(x=>x.id===String(strikeId));
  if(!found)throw Error('Strike not found for this officer');
  if(found.state!=='Active')throw Error('Strike is already '+found.state.toLowerCase());
  const now=time();
  // Strike stays in the private ledger for history, but no longer counts as active.
  // For backwards compatibility the old void columns store who resolved the strike and why.
  await this.sheets.putValues(`${quoteTab(this.tabs.strikes)}!I${found.index}:L${found.index}`,
   [[outcome,String(actor),now,safeCell(reason,1000)]]);
  await this.append('strikeEvents',[randomUUID(),this.guildId,String(id),found.id,safeCell(found.officer||'',120),outcome,safeCell(reason,1000),String(actor),now],9);
  return {...found,state:outcome,resolvedBy:String(actor),resolvedAt:now,resolutionReason:reason};
 }
 async strikeEvents(id){return (await this.rows('strikeEvents',9)).filter(x=>x.data[1]===this.guildId&&x.data[2]===String(id)).map(({data:r})=>({id:r[0],strikeId:r[3],event:r[5],reason:r[6],by:r[7],at:r[8]}));}
}
module.exports={PersonnelLedger,PROFILE_HEADERS,NOTE_HEADERS,STRIKE_HEADERS,ACTION_HEADERS,STRIKE_EVENT_HEADERS,decodeCerts,decodeSubdivisions,safeCell};
