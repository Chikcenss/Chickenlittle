'use strict';
// Mirrors the bot-owned SADLE roster data into the EXISTING GORP Whitelisted
// LEO Roster sheets. No replacement/duplicate visible sheets are created.
// Each row is matched by Discord ID, NOT by name or callsign.
const {GoogleSheetsClient,quoteTab}=require('./googleSheets');
const {prefixFor}=require('./callsigns');
const TAB={pro:'Probationary Officers',leo:'Law Enforcement Officers',sen:'Senior Law Enforcement Officers',cmd:'Supervisors / Command Staff'};
const CONFIG={
 [TAB.pro]:{first:9,minColumns:13,id:10,call:1,name:2,rank:3,status:12,hire:9,note:8},
 [TAB.leo]:{first:10,minColumns:23,id:21,call:1,name:2,rank:3,status:22,promo:18,note:15},
 [TAB.sen]:{first:10,minColumns:21,id:19,call:1,name:2,rank:3,status:20,promo:16,note:15},
 [TAB.cmd]:{first:10,minColumns:23,id:21,call:3,name:4,rank:5,status:22,promo:18,note:17}
};
const log=(...x)=>console.log('[GORP SADLE Original Roster]',...x);
const clean=x=>String(x??'').trim();
const validID=x=>/^\d{16,22}$/.test(clean(x));
const iso=()=>new Date().toISOString();
const colLabel=index=>{let n=index+1,out='';while(n>0){n--;out=String.fromCharCode(65+n%26)+out;n=Math.floor(n/26);}return out;};
const isMember=m=>Boolean(m?.user?.id&&!m.user.bot);
function targetOf(level){return level>=40?TAB.cmd:level>=30?TAB.sen:level>=20?TAB.leo:level>=10?TAB.pro:null;}
function rankLabel(level,name){
 if(level===10)return 'Probationary Officer';
 if(level===20)return 'Law Enforcement';
 if(level===30)return 'Senior LEO';
 if(level===40)return 'Corporal';
 if(level===45)return 'Supervisor';
 if(level===50)return 'Sergeant';
 if(level===60)return 'Lieutenant';
 if(level===70)return 'Captain';
 if(level===80)return 'Commander';
 if(level>=90){const str=clean(name).toLowerCase();if(str.includes('commissioner'))return 'Commissioner';if(str.includes('assistant director'))return 'Assistant Director';if(str.includes('deputy director'))return 'Deputy Director';if(str.includes('director'))return 'Director';return 'High Command';}
 return clean(name);
}
function cmdBand(level){return level>=90?'headquarters':level>=80?'commanders':level>=70?'captains':level>=60?'lieutenants':level>=50?'sergeant':'corporal';}
function normalizedBand(s){const v=clean(s).toLowerCase();if(v==='headquarters')return 'headquarters';if(v==='commanders')return 'commanders';if(v==='captains')return 'captains';if(v==='lieutenants')return 'lieutenants';if(v==='sergeant'||v==='sergeants')return 'sergeant';if(v==='corporal'||v==='corporals')return 'corporal';return null;}
// Locate the command section of a real officer row. A rank change within
// Supervisors / Command Staff must move sections, not just change Rank cell.
function commandBandAt(rows,row){
 let band=null;
 for(let i=CONFIG[TAB.cmd].first-1;i<row;i++){
   const candidate=normalizedBand(rows[i]?.[2]);
   if(candidate)band=candidate;
 }
 return band;
}
function safeDisplay(member){return clean(member?.nick||member?.user?.global_name||member?.user?.username||member?.user?.id).slice(0,140);}
class OriginalRosterMirror {
 constructor(backend,spreadsheetId,credentials,{mainRankEntry,rankLevel}={}){
  if(!/^[A-Za-z0-9_-]+$/.test(clean(spreadsheetId)))throw Error('Original roster Google Sheets ID missing');
  this.backend=backend;this.target=new GoogleSheetsClient(spreadsheetId,credentials);
  this.mainRankEntry=mainRankEntry;this.rankLevel=rankLevel;
  this.stats={lastSuccess:null,lastError:null,lastRowsUpdated:0,lastPlacement:null};
  this.lastFingerprint='';this.lastFull=0;this.backedUpTabs=new Set();
 }
 async prepare(){
  const m=await this.target.request('GET','?fields=sheets(properties(sheetId,title,gridProperties(rowCount,columnCount)))');
  const sheets=m.sheets||[];this.meta=new Map(sheets.map(x=>[x.properties.title,x.properties]));
  const missing=Object.values(TAB).filter(t=>!this.meta.has(t));
  if(missing.length)throw Error('Original roster missing expected tab(s): '+missing.join(', '));
  for(const [name,info] of Object.entries(CONFIG)){
   const p=this.meta.get(name);
   if(p.gridProperties.columnCount<info.minColumns)throw Error('Original roster tab has insufficient columns: '+name);
  }
  const hdr=this.meta.get(TAB.cmd);
  if(hdr.gridProperties.rowCount<10)throw Error('Supervisors original sheet has no rank rows');
 }
 async tabRows(name){const p=this.meta.get(name),last=String.fromCharCode(65+CONFIG[name].minColumns-1);
  const raw=await this.target.getValues(`${quoteTab(name)}!A1:${last}${p.gridProperties.rowCount}`);
  return Array.from({length:p.gridProperties.rowCount},(_,i)=>raw[i]||[]);
 }
 async backendData(){
  const [active,details,career,callsigns]=await Promise.all([
   this.backend.getValues("'SADLE Active'!A2:F"),
   this.backend.getValues("'SADLE Officer Details'!A2:T"),
   this.backend.getValues("'SADLE Career'!A2:J"),
   this.backend.getValues("'SADLE Callsigns'!A2:G")]);
  const keyed=x=>new Map(x.filter(r=>validID(r[0])).map(r=>[clean(r[0]),r]));
  const detailsById=new Map();details.forEach((r,i)=>{if(validID(r[0]))detailsById.set(clean(r[0]),{row:r,number:i+2});});
  return {active:keyed(active),detailsById,career:keyed(career),callsigns:keyed(callsigns)};
 }
 static existing(rows,name,id){const col=CONFIG[name].id;
  const found=[];for(let idx=CONFIG[name].first-1;idx<rows.length;idx++){if(clean(rows[idx]?.[col])===id)found.push(idx+1);}return found;}
 // Strict eligibility: blank name AND blank Discord ID. Don't take rows with manual notes,
 // statuses, qualifications, or strikes, even if their ID is empty.
 static blankSlot(row,name){
  const cfg=CONFIG[name];
  if(clean(row[cfg.id])||clean(row[cfg.name]))return false;
  // Command slots can also be reused when the row is genuinely vacant.
  const allowed=new Set(['','false','☐','-','probationary officer','law enforcement','senior leo','corporal','supervisor','sergeant','lieutenant','captain','commander','hq','headquarters']);
  const ignore=new Set([cfg.call,cfg.name,cfg.id,cfg.rank]);
  for(let col=0;col<row.length;col++){
   if(ignore.has(col))continue;
   const val=clean(row[col]).toLowerCase();
   if(!allowed.has(val))return false; // Preserve manually-entered notes/dates/qualifications
  }
  return true;
 }
 static canonicalCall(value){
  const match=clean(value).toUpperCase().match(/([MKIGECAXL])-([0-9]{1,5})$/);
  return match?match[1]+'-'+String(Number(match[2])).padStart(2,'0'):null;
 }
 // Rank slots already printed on the source roster are authoritative. A blank
 // name/Discord ID does not reserve a slot against new assignment; it makes
 // that pre-numbered slot available (e.g. M-06). Never renumber any row.
 async callCandidates(members,ranks){
  if(!this.meta)await this.prepare();
  const tabs={};for(const name of Object.values(TAB))tabs[name]=await this.tabRows(name);
  const reserved=new Set(),candidates=new Map(),usedByOthers=new Map();
  for(const [tab,rows] of Object.entries(tabs)){
   const cfg=CONFIG[tab];
   for(let i=cfg.first-1;i<rows.length;i++){
    const row=rows[i]||[];const code=OriginalRosterMirror.canonicalCall(row[cfg.call]);
    if(!code)continue;
    reserved.add(code);
    if(clean(row[cfg.id])||clean(row[cfg.name]))usedByOthers.set(code,clean(row[cfg.id])||'LEGACY');
   }
  }
  for(const m of members){
   const entry=this.mainRankEntry(m,ranks);
   const level=entry?this.rankLevel(entry.roleName||entry.label):0;
   const tab=targetOf(level);if(!tab)continue;
   const id=clean(m.user?.id);const prefix=prefixFor(level);
   const cfg=CONFIG[tab],rows=tabs[tab];
   const own=[],free=[];
   for(let i=cfg.first-1;i<rows.length;i++){
    const row=rows[i]||[],code=OriginalRosterMirror.canonicalCall(row[cfg.call]);
    if(!code||!code.startsWith(prefix+'-'))continue;
    if(clean(row[cfg.id])===id)own.push(code);
    else if(OriginalRosterMirror.blankSlot(row,tab))free.push(code);
   }
   candidates.set(id,[...own,...free]);
  }
  return {candidates,reserved,usedByOthers};
 }
 async safeInsert(tab,index){
  const meta=await this.target.request('GET','?fields=sheets(properties(sheetId,title),merges,protectedRanges(range,warningOnly,requestingUserCanEdit),basicFilter(range))');
  const sheet=(meta.sheets||[]).find(x=>x.properties.title===tab);
  if(!sheet)throw Error('Missing rank tab '+tab);
  const crosses=r=>r&&r.startRowIndex<=index&&(r.endRowIndex??Number.MAX_SAFE_INTEGER)>index;
  if((sheet.merges||[]).some(crosses))throw Error('Insertion intersects merged cells in '+tab);
  if((sheet.protectedRanges||[]).some(p=>!p.warningOnly&&p.requestingUserCanEdit!==true&&crosses(p.range)))throw Error('Insertion intersects protected range in '+tab);
  if(sheet.basicFilter&&crosses(sheet.basicFilter.range))throw Error('Insertion intersects filtered range in '+tab);
  if(!this.backedUpTabs.has(tab)){
    // Backups go to the PRIVATE data spreadsheet, never a new tab on the public roster.
    if(!this.backend.id || this.backend.id===this.target.id)throw Error('Separate private data spreadsheet is required for a safe roster backup');
    const dup=await this.target.request('POST',`/sheets/${sheet.properties.sheetId}:copyTo`,{destinationSpreadsheetId:this.backend.id});
    if(!Number.isInteger(dup.sheetId))throw Error('Could not confirm separate-sheet roster backup for '+tab);
    const stamp=new Date().toISOString().replace(/[-:TZ.]/g,'').slice(0,14);
    const name=('ROSTER BACKUP '+stamp+' '+tab).slice(0,98);
    await this.backend.request('POST',':batchUpdate',{requests:[{updateSheetProperties:{properties:{sheetId:dup.sheetId,title:name,hidden:true},fields:'title,hidden'}}]});
    this.backedUpTabs.add(tab);
  }
 }
 async insertCommandRankRow(level,rows){
  // Preserve the original HQ/Commander/Captain/etc. grouping by inserting BEFORE
  // the next count header, rather than overwriting existing command officers.
  const wanted=cmdBand(level);let active=null,start=null,end=null;
  for(let i=CONFIG[TAB.cmd].first-1;i<rows.length;i++){
   const marker=normalizedBand(rows[i]?.[2]);
   if(marker){if(active===wanted&&start!==null){end=i;break;}active=marker;if(marker===wanted)start=i;continue;}
   if(active===wanted && /^number of\b/i.test(clean(rows[i]?.[2]))){end=i;break;}
  }
  if(start===null)throw Error('Cannot locate '+wanted+' rank band in original supervisor tab');
  if(end===null){end=rows.length;while(end>start+1 && rows[end-1]?.every(v=>!clean(v)))end--;}
  const sheetId=this.meta.get(TAB.cmd).sheetId;
  const zero=end;
  await this.safeInsert(TAB.cmd,zero);
  const columnCount=this.meta.get(TAB.cmd).gridProperties.columnCount;
  const template=Math.max(start+1,zero-1);
  const templateDimensions=await this.target.request('GET',`?ranges=${encodeURIComponent(`${quoteTab(TAB.cmd)}!A${template+1}`)}&includeGridData=true&fields=sheets(data(rowMetadata(pixelSize)))`);
  const templateHeight=templateDimensions.sheets?.[0]?.data?.[0]?.rowMetadata?.[0]?.pixelSize;
  const requests=[
   {insertDimension:{range:{sheetId,dimension:'ROWS',startIndex:zero,endIndex:zero+1},inheritFromBefore:true}},
   {copyPaste:{source:{sheetId,startRowIndex:template,endRowIndex:template+1,startColumnIndex:0,endColumnIndex:columnCount},destination:{sheetId,startRowIndex:zero,endRowIndex:zero+1,startColumnIndex:0,endColumnIndex:columnCount},pasteType:'PASTE_FORMAT'}},
   {copyPaste:{source:{sheetId,startRowIndex:template,endRowIndex:template+1},destination:{sheetId,startRowIndex:zero,endRowIndex:zero+1},pasteType:'PASTE_DATA_VALIDATION'}},
   {copyPaste:{source:{sheetId,startRowIndex:template,endRowIndex:template+1},destination:{sheetId,startRowIndex:zero,endRowIndex:zero+1},pasteType:'PASTE_FORMULA'}}
  ];
  if(templateHeight)requests.push({updateDimensionProperties:{range:{sheetId,dimension:'ROWS',startIndex:zero,endIndex:zero+1},properties:{pixelSize:templateHeight},fields:'pixelSize'}});
  await this.target.request('POST',':batchUpdate',{requests});
  this.meta.get(TAB.cmd).gridProperties.rowCount++;
  log('Inserted one new '+wanted+' rank row in the ORIGINAL Supervisors / Command Staff tab.');
  return zero+1;
 }
 async setCell(tab,row,col,value,rows){const original=rows[row-1]?.[col];
  if(clean(original)===clean(value))return 0;
  const colLabel=String.fromCharCode(65+col);
  await this.target.putValues(`${quoteTab(tab)}!${colLabel}${row}` ,[[value]]);
  if(!rows[row-1])rows[row-1]=[];rows[row-1][col]=value;
  return 1;
 }
 async clearManaged(name,id,rows,knownRow=null){const cfg=CONFIG[name],matches=OriginalRosterMirror.existing(rows,name,id);
  if(knownRow!=null && !matches.includes(knownRow)){
   throw Error('Stale row changed before clearance: '+name+' row '+knownRow+' for '+id);
  }
  if(!matches.length)return 0;
  if(knownRow==null && matches.length>1){
   log('Ambiguous old placement for '+id+' in '+name+' ('+matches.length+').');return 0;
  }
  const row=knownRow||matches[0];let edits=0;
  // Keep the call number, template's rank label and any manually entered notes,
  // strikes, qualifications and history. Only remove the officer's identity
  // and active status, so the old rank list cannot show a ghost officer.
  for(const c of [cfg.name,cfg.id,cfg.status])edits+=await this.setCell(name,row,c,'',rows);
  return edits;
 }
 async setPlacement(detailsEntry,value){
  if(!detailsEntry)return;
  const row=detailsEntry.row,n=detailsEntry.number;
  if(clean(row[18])===value)return;
  await this.backend.putValues(`'SADLE Officer Details'!S${n}:T${n}`,[[value,iso()]]);
  row[18]=value;row[19]=iso();
 }
 // Read all currently assigned rank slots by permanent Discord ID. Legacy and
 // bot-created rows must both move when that person's Discord role changes.
 placementsFor(id,tabs){
  const found=[];
  for(const tab of Object.values(TAB)){
   const rows=tabs[tab];
   for(const row of OriginalRosterMirror.existing(rows,tab,id)){
    found.push({tab,row,band:tab===TAB.cmd?commandBandAt(rows,row):null,
      callsign:OriginalRosterMirror.canonicalCall(rows[row-1]?.[CONFIG[tab].call])});
   }
  }
  return found;
 }
 validDestination(placement,tab,level,wantedCall){
  return placement.tab===tab && placement.callsign===wantedCall &&
   (tab!==TAB.cmd || placement.band===cmdBand(level));
 }
 async sync(members,ranks,{full=true,force=false}={}){
  const incoming=[...members].filter(isMember);
  if(!this.meta)await this.prepare();
  const data=await this.backendData();
  const targetMembers=new Map();
  for(const member of incoming){
   const entry=this.mainRankEntry(member,ranks);
   const level=entry?this.rankLevel(entry.roleName||entry.label):0;
   const tab=targetOf(level);
   if(tab)targetMembers.set(clean(member.user.id),{member,entry,level,tab});
  }
  const ids=[...targetMembers.keys()].sort();
  const fingerprint=JSON.stringify(ids.map(id=>{const e=targetMembers.get(id),c=data.callsigns.get(id);
    return [id,e.tab,e.level,safeDisplay(e.member),clean(c?.[1])];}));
  if(!force && full && this.lastFingerprint===fingerprint && Date.now()-this.lastFull<180000)
    return {changed:0,skipped:true};
  const tabs={};for(const name of Object.values(TAB))tabs[name]=await this.tabRows(name);
  let changed=0,skipped=0,removedOld=0;
  // An officer still in SADLE but without any core LEO rank must not remain
  // on a former rank's page. Never touch unrelated historical IDs.
  for(const member of incoming){
    const id=clean(member.user.id);
    if(targetMembers.has(id))continue;
    for(const placement of this.placementsFor(id,tabs)){
      changed+=await this.clearManaged(placement.tab,id,tabs[placement.tab],placement.row);
      removedOld++;
    }
    const detail=data.detailsById.get(id);
    if(detail && /^(NEW|LEGACY):/.test(clean(detail.row[18])))await this.setPlacement(detail,'');
  }
  // Removed-from-SADLE officers are only cleared if they have a known bot
  // identity/placement marker. Do not delete all historical rows that happen
  // to be absent from the current Discord guild.
  if(full){
   for(const [id,detail] of data.detailsById){
    const marker=clean(detail.row[18]);
    if(!/^(NEW|LEGACY):/.test(marker) || targetMembers.has(id) || incoming.some(m=>clean(m.user.id)===id))continue;
    for(const placement of this.placementsFor(id,tabs)){
      changed+=await this.clearManaged(placement.tab,id,tabs[placement.tab],placement.row);
      removedOld++;
    }
    await this.setPlacement(detail,'');
   }
  }
  for(const id of ids){
   const {tab,level,entry,member}=targetMembers.get(id),cfg=CONFIG[tab];
   const desired=OriginalRosterMirror.canonicalCall(data.callsigns.get(id)?.[1]);
   if(!desired){log('No allocated callsign for '+id+'; cannot place safely.');skipped++;continue;}
   let placements=this.placementsFor(id,tabs);
   let matches=placements.filter(p=>this.validDestination(p,tab,level,desired));
   if(matches.length>1){log('Multiple matching placements for '+id+' in '+tab+'; skipped.');skipped++;continue;}
   let row=matches[0]?.row||null, newSlot=!row;
   if(!row){
    // Claim the actual preprinted number. A blank name alone is insufficient:
    // don't overwrite a reserved historical row with notes/strikes/quals.
    const candidates=[];
    for(let i=cfg.first-1;i<tabs[tab].length;i++){
      const r=tabs[tab][i]||[];
      if(OriginalRosterMirror.canonicalCall(r[cfg.call])!==desired)continue;
      if(tab===TAB.cmd && commandBandAt(tabs[tab],i+1)!==cmdBand(level))continue;
      if(OriginalRosterMirror.blankSlot(r,tab))candidates.push(i+1);
    }
    if(candidates.length>1){log('Ambiguous vacant callsign '+desired+' in '+tab+'; skipped.');skipped++;continue;}
    if(candidates.length)row=candidates[0];
   }
   if(!row){
    // If this ID already exists in the same tab under a different callsign,
    // never overwrite its printed unit number. Move to a distinct row.
    if(tab===TAB.cmd)row=await this.insertCommandRankRow(level,tabs[tab]);
    else{
     const props=this.meta.get(tab),sheetId=props.sheetId;
     // One rank per these original tabs. Place directly after the final
     // numbered rank row, not at the bottom of the entire worksheet.
     let last=cfg.first-2;
     for(let i=cfg.first-1;i<tabs[tab].length;i++){
      if(OriginalRosterMirror.canonicalCall(tabs[tab][i]?.[cfg.call]))last=i;
     }
     const index=Math.max(cfg.first-1,last+1),template=Math.max(cfg.first-1,index-1);
     const columns=props.gridProperties.columnCount;
     await this.safeInsert(tab,index);
     await this.target.request('POST',':batchUpdate',{requests:[
       {insertDimension:{range:{sheetId,dimension:'ROWS',startIndex:index,endIndex:index+1},inheritFromBefore:index>0}},
       {copyPaste:{source:{sheetId,startRowIndex:template,endRowIndex:template+1,startColumnIndex:0,endColumnIndex:columns},destination:{sheetId,startRowIndex:index,endRowIndex:index+1,startColumnIndex:0,endColumnIndex:columns},pasteType:'PASTE_FORMAT'}},
       {copyPaste:{source:{sheetId,startRowIndex:template,endRowIndex:template+1},destination:{sheetId,startRowIndex:index,endRowIndex:index+1},pasteType:'PASTE_DATA_VALIDATION'}},
       {copyPaste:{source:{sheetId,startRowIndex:template,endRowIndex:template+1},destination:{sheetId,startRowIndex:index,endRowIndex:index+1},pasteType:'PASTE_FORMULA'}}
     ]});
     props.gridProperties.rowCount++;
     row=index+1;
    }
    // Inserting a command row changes row positions for command slots. Read
    // fresh IDs before deleting any previous placement.
    tabs[tab]=await this.tabRows(tab);
   }
   const career=data.career.get(id)||[],call=data.callsigns.get(id)||[],detail=data.detailsById.get(id);
   const label=rankLabel(level,entry.label||entry.roleName);
   // Keep LOA / Part Time / Suspended on the roster when changing rank.
   // Do not overwrite an existing manual duty status during reconciliation.
   const prior=placements.find(p=>p.tab!==tab||p.row!==row);
   const priorStatus=prior?clean(tabs[prior.tab][prior.row-1]?.[CONFIG[prior.tab].status]):'';
   const currentStatus=clean(tabs[tab][row-1]?.[cfg.status]);
   const fields=[[cfg.name,safeDisplay(member)],[cfg.rank,label],[cfg.id,id]];
   // Preserve existing Notes when the officer moves to a different rank section.
   const noteSource=placements.find(p=>p.tab!==tab||p.row!==row);
   const olderNote=noteSource?clean(tabs[noteSource.tab]?.[noteSource.row-1]?.[CONFIG[noteSource.tab].note]):'';
   if(olderNote&&!clean(tabs[tab][row-1]?.[cfg.note]))fields.push([cfg.note,olderNote]);
   if(newSlot)fields.push([cfg.status,priorStatus||'Active']);
   else if(!currentStatus)fields.push([cfg.status,priorStatus||'Active']);
   if(!clean(tabs[tab][row-1]?.[cfg.call])){
     const marked=tab===TAB.cmd && tabs[tab].some(r=>/^\(X\)/i.test(clean(r[cfg.call])));
     fields.unshift([cfg.call,marked?'(X)'+desired:clean(call[1])]);
   }
   if(newSlot && cfg.hire && clean(career[3]))fields.push([cfg.hire,clean(career[3]).slice(0,10)]);
   if(newSlot && cfg.promo && ['Promotion','Demotion'].includes(clean(career[5])) && clean(career[6]))
     fields.push([cfg.promo,clean(career[6]).slice(0,10)]);
   // Successful destination is mandatory before removing any old rank row.
   for(const [col,value] of fields){changed+=await this.setCell(tab,row,col,value,tabs[tab]);}
   // Re-evaluate positions after the destination write (important when the
   // command band insertion shifted old rows).
   placements=this.placementsFor(id,tabs);
   for(const old of placements){
     if(old.tab===tab && old.row===row)continue;
     changed+=await this.clearManaged(old.tab,id,tabs[old.tab],old.row);
     removedOld++;
     log('Moved '+id+' from '+old.tab+' row '+old.row+' to '+tab+' row '+row+'.');
   }
   if(detail)await this.setPlacement(detail,(newSlot?'NEW:':'LEGACY:')+tab);
  }
  this.stats.lastRowsUpdated=changed;this.stats.lastSuccess=iso();this.stats.lastError=null;
  this.stats.lastPlacement=`${ids.length} ranks; ${removedOld} stale rank placements removed; ${skipped} safety skips`;
  if(full){this.lastFingerprint=fingerprint;this.lastFull=Date.now();}
  if(changed||removedOld)log('Synchronized '+changed+' original roster cells; cleared '+removedOld+' old rank placements, '+skipped+' skipped.');
  return {changed,skipped,removedOld};
 }
 async findOne(id){
  if(!this.meta)await this.prepare();
  const rows={};for(const tab of Object.values(TAB))rows[tab]=await this.tabRows(tab);
  const matches=this.placementsFor(String(id),rows);
  if(matches.length!==1)throw Error(matches.length?'Ambiguous officer identity in original roster':'Officer not on original roster');
  const p=matches[0];return {...p,rows:rows[p.tab],cfg:CONFIG[p.tab]};
 }
 async appendOfficerNote(id,{note}){
  const p=await this.findOne(id);const col=p.cfg.note;
  if(!Number.isInteger(col))return {updated:0,unmapped:true};
  const range=`${quoteTab(p.tab)}!${colLabel(col)}${p.row}`;
  const literal=await this.target.request('GET',`/values/${encodeURIComponent(range)}?valueRenderOption=FORMULA`);
  const existing=String(literal.values?.[0]?.[0]??'');
  if(existing.startsWith('='))throw Error('Refusing to overwrite original roster note formula');
  const addition=`${new Date().toISOString().slice(0,10)} — ${String(note).trim()}`;
  const updated=existing?existing+'\n'+addition:addition;
  if(updated.length>45000)throw Error('Main roster Notes cell is full; note remains stored privately');
  await this.target.putValues(range,[[updated]]);return {updated:1};
 }
 async updateOfficerFields(id,fields){
  const p=await this.findOne(id);
  // Only update existing columns whose HEADER unambiguously matches the field.
  const aliases={subdivision:new Set(['sub','subs','subdivision','subdivisions','sub division','unit','units']),strikes:new Set(['strike','strikes','strike count','strikes count','strike(s)','active strikes','active strike count']),certifications:new Set(['certifications','certification','qualifications']),status:new Set(['status','duty status'])};
  const used=new Set([p.cfg.id,p.cfg.call,p.cfg.name,p.cfg.rank,p.cfg.note]);
  const updates=[];
  for(const [field,value] of Object.entries(fields)){
   if(!Object.hasOwn(aliases,field))continue;
   const choices=[];
   for(let c=0;c<this.meta.get(p.tab).gridProperties.columnCount;c++){
    if(used.has(c))continue;
    for(let r=0;r<p.cfg.first-1;r++){
     if(aliases[field].has(clean(p.rows[r]?.[c]).toLowerCase())){choices.push(c);break;}
    }
   }
   if(new Set(choices).size!==1)continue; // No confident header: NEVER guess.
   const col=choices[0],range=`${quoteTab(p.tab)}!${colLabel(col)}${p.row}`;
   const literal=await this.target.request('GET',`/values/${encodeURIComponent(range)}?valueRenderOption=FORMULA`);
   const current=String(literal.values?.[0]?.[0]??'');
   if(current.startsWith('='))throw Error('Refusing to replace formula in '+range);
   if(current!==String(value??''))updates.push({range,value:String(value??'')});
  }
  for(const item of updates)await this.target.putValues(item.range,[[item.value]]);
  return {updated:updates.length,unmapped:updates.length===0};
 }
 async syncOne(member,ranks){return this.sync([member],ranks,{full:false});}
 async dropOne(id){
  if(!this.meta)await this.prepare();
  const details=await this.backend.getValues("'SADLE Officer Details'!A2:T");
  const ix=details.findIndex(r=>clean(r[0])===id);
  if(ix<0)return; // Don't purge unknown historical officers.
  const entry={row:details[ix],number:ix+2};
  const tabs={};for(const name of Object.values(TAB))tabs[name]=await this.tabRows(name);
  let edits=0;
  for(const p of this.placementsFor(id,tabs)){
   edits+=await this.clearManaged(p.tab,id,tabs[p.tab],p.row);
  }
  await this.setPlacement(entry,'');
  if(edits)log('Removed departed officer '+id+' from '+edits+' cells across former rank placements.');
 }

}
module.exports={OriginalRosterMirror,TAB,CONFIG,targetOf,rankLabel,cmdBand};
