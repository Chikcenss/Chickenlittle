'use strict';

// Callsign source of truth: Google Sheets, keyed by permanent Discord user ID.
// Officer Details is the presentation lookup used by existing visual roster tabs.
const {quoteTab}=require('./googleSheets');
const CALLSIGN_HEADERS=['Discord ID','Callsign','Assignment','Prefix','Assigned (UTC)','Updated (UTC)','Updated By'];
const CALLSIGN_HISTORY_HEADERS=['Event ID','Discord ID','Officer','Action','Old Callsign','New Callsign','Date (UTC)','Changed By'];
const now=()=>new Date().toISOString();
const string=v=>String(v??'').trim();
const display=(member)=>String(member.nick||member.user?.global_name||member.user?.username||member.user?.id||'');
const normalizeRow=(row,len)=>Array.from({length:len},(_,i)=>string(row[i]));
const hasID=x=>/^\d{16,22}$/.test(x);
// Printed roster decorations are presentation, not a different allocation.
// Keep arbitrary manual identifiers intact while normalizing numeric callsigns.
function callsignKey(value){
  const text=string(value).toUpperCase();
  const match=text.match(/^(?:\(X\)\s*)?([A-Z]{1,4})\s*-\s*(\d{1,5})$/);
  return match?match[1]+'-'+String(Number(match[2])).padStart(2,'0'):text;
}
const matchesPrefix=(value,prefix)=>callsignKey(value).startsWith(prefix+'-');

// Codes can be changed in sadleroaster/config.json without modifying source.
const DEFAULT_PREFIXES={
  probationary:'M', leo:'K', senior:'I', corporal:'G',
  sergeant:'E', lieutenant:'C', captain:'A',
  commander:'X', hq:'L'
};
function prefixFor(level,custom={}){
  let key=level>=90?'hq':level>=80?'commander':level>=70?'captain':
    level>=60?'lieutenant':level>=50?'sergeant':level>=40?'corporal':
    level>=30?'senior':level>=20?'leo':level>=10?'probationary':'leo';
  return String(custom[key]||DEFAULT_PREFIXES[key]).trim().toUpperCase();
}
function allocate(prefix,used){
  for(let n=1;n<=99999;n++){
    const candidate=prefix+'-'+String(n).padStart(2,'0');
    if(!used.has(candidate.toUpperCase())){used.add(candidate.toUpperCase());return candidate;}
  }
  throw new Error('No unused callsigns available for '+prefix);
}
class CallsignManager {
  constructor(sheets,options={}){
    this.sheets=sheets;
    this.callsignTab=options.callsignTab||'SADLE Callsigns';
    this.auditTab=options.callsignHistoryTab||'SADLE Callsign History';
    this.detailsTab=options.detailsTab||'SADLE Officer Details';
    this.prefixes=options.callsignPrefixes||{};
    this.rankLevel=options.rankLevel;
    this.mainRankEntry=options.mainRankEntry;
    if(!this.rankLevel||!this.mainRankEntry)throw Error('Rank functions required');
  }
  schema(){return {[this.callsignTab]:CALLSIGN_HEADERS,[this.auditTab]:CALLSIGN_HISTORY_HEADERS};}
  async values(tab,range){return await this.sheets.getValues(quoteTab(tab)+'!'+range);}
  async data(){
    const raw=await this.values(this.callsignTab,'A2:G');
    const rows=raw.map(r=>normalizeRow(r,7)); // Preserve physical row numbers, including gaps.
    const byId=new Map(),used=new Map();
    for(const [index,row] of rows.entries()){
      if(row[0]){
        if(!hasID(row[0])||byId.has(row[0]))throw Error('Malformed/duplicate SADLE Callsigns Discord ID: '+row[0]);
        byId.set(row[0],row);
      }
      if(row[1]){
        const key=callsignKey(row[1]),owner=row[0]||'UNLINKED_CALLSIGN_ROW_'+(index+2);
        if(used.has(key)&&used.get(key)!==owner)throw Error('Duplicate callsign in SADLE Callsigns: '+row[1]);
        used.set(key,owner);
      }
    }
    const details=(await this.values(this.detailsTab,'A2:R')).map(r=>normalizeRow(r,18));
    const detailById=new Map();
    details.forEach((row,index)=>{
      if(row[0]){
        if(!hasID(row[0])||detailById.has(row[0]))throw Error('Invalid/duplicate Discord ID in SADLE Officer Details: '+row[0]);
        detailById.set(row[0],{row,index:index+2});
      }
      if(row[1]){
        const key=callsignKey(row[1]),owner=row[0]||'UNLINKED_DETAILS_ROW_'+(index+2);
        if(used.has(key)&&used.get(key)!==owner)throw Error('Duplicate callsign in Officer Details: '+row[1]);
        used.set(key,owner);
      }
    });
    return {rows,byId,used,details,detailById};
  }
  async release(id,reason='Rank removed'){
    const state=await this.data();const entry=state.byId.get(String(id));
    if(!entry?.[1])return false;
    const oldCall=entry[1],stamp=now(),index=state.rows.findIndex(r=>r[0]===String(id));
    if(index<0)throw Error('Callsign entry index missing');
    // Only clear this person's managed fields. Release removes the callsign
    // from the used set, never another officer's roster row.
    entry[1]='';entry[2]='RELEASED';entry[3]='';entry[5]=stamp;entry[6]='AUTO';
    await this.writeRanges([{range:`${quoteTab(this.callsignTab)}!A${index+2}:G${index+2}`,values:[entry]},
      ...(state.detailById.get(String(id))?[{range:`${quoteTab(this.detailsTab)}!B${state.detailById.get(String(id)).index}`,values:[['']]}]:[])]);
    const {createHash}=require('node:crypto');
    const eventId=createHash('sha256').update(`release|${id}|${oldCall}|${stamp}`).digest('hex').slice(0,32);
    await this.sheets.appendValues(`${quoteTab(this.auditTab)}!A:H`,[[eventId,id,'',String(reason).slice(0,120),oldCall,'',stamp,'AUTO']]);
    return true;
  }
  autoPrefix(member,ranks){
    const main=this.mainRankEntry(member,ranks);
    const level=main?this.rankLevel(main.roleName||main.label):0;
    return prefixFor(level,this.prefixes);
  }
  async writeRanges(data){
    if(!data.length)return;
    // One batched Sheets write for all modified callsigns, regardless of guild size.
    if(typeof this.sheets.request==='function'){
      await this.sheets.request('POST','/values:batchUpdate',{
        valueInputOption:'RAW',data:data.map(x=>({range:x.range,majorDimension:'ROWS',values:x.values}))
      });
    }else for(const d of data)await this.sheets.putValues(d.range,d.values);
  }
  async update(members,ranks,override=null,returnEvents=false,rosterSlots=null){
    const state=await this.data();
    const started=new Set(state.used.keys());
    const rosterClaimed=new Set();
    const rosterOwners=new Map();
    for(const [code,owner] of rosterSlots?.usedByOthers||[]){
      const key=callsignKey(code);
      if(rosterOwners.has(key)&&rosterOwners.get(key)!==owner)throw Error('Conflicting roster callsign owners: '+code);
      rosterOwners.set(key,owner);
    }
    for(const code of rosterSlots?.reserved||[])started.add(callsignKey(code));
    const byId=state.byId;
    const changed=[];const audit=[];const changes=[];
    const membersArray=Array.from(members).sort((a,b)=>String(a.user.id).localeCompare(String(b.user.id)));
    const unique=new Set();
    for(const member of membersArray){
      const id=String(member.user?.id||'');
      if(!hasID(id)||unique.has(id))throw Error('Invalid or duplicate Discord member in callsign sync');
      unique.add(id);
      // The plain SADLE membership role is NOT a law enforcement rank.
      // Never assign a K callsign to membership-only officers.
      if(!this.mainRankEntry(member,ranks))continue;
      const existing=byId.get(id);
      const detail=state.detailById.get(id);
      const originalCall=string(existing?.[1]||detail?.row?.[1]);
      const originalSource=string(existing?.[2]||(detail?.row?.[1]?'MANUAL':''));
      const prefix=this.autoPrefix(member,ranks);
      const forced=override&&override.id===id;
      let callsign=originalCall,source=originalSource==='MANUAL'?'MANUAL':'AUTO';
      if(forced&&override.value!=='auto'){
        callsign=override.value;source='MANUAL';
        const owner=state.used.get(callsignKey(callsign));
        if(owner&&owner!==id)throw Error('Callsign '+callsign+' is already assigned to another Discord member');
      }else if(forced&&override.value==='auto'){
        source='AUTO';
        // Keep the previous automatic value if the same rank/prefix; otherwise allocate.
        if(!originalCall||originalSource!=='AUTO'||!matchesPrefix(originalCall,prefix))callsign='';
      }
      if(source==='AUTO'&&rosterSlots){
        // A valid existing assignment is stable across restarts. Only use the
        // first vacant printed slot for an officer who actually needs a number.
        const own=callsignKey(callsign);
        const holder=rosterOwners.get(own);
        const keep=Boolean(callsign)&&matchesPrefix(callsign,prefix)&&
          (!holder||holder===id)&&!rosterClaimed.has(own);
        if(keep)rosterClaimed.add(own);
        else {
          const candidates=rosterSlots.candidates?.get(id)||[];
          const found=candidates.find(value=>{
            const code=callsignKey(value),owner=state.used.get(code),rosterOwner=rosterOwners.get(code);
            return matchesPrefix(value,prefix)&&(!owner||owner===id)&&
              (!rosterOwner||rosterOwner===id)&&!rosterClaimed.has(code);
          });
          callsign=found||'';
          if(found)rosterClaimed.add(callsignKey(found));
        }
      }
      if(source==='AUTO'&&(!callsign||!matchesPrefix(callsign,prefix))){
        // All printed slots are reserved during allocation; vacant printed
        // numbers have already been considered by the candidate selection.
        callsign=allocate(prefix,started);
      }
      if(!callsign)throw Error('Cannot assign blank callsign');
      const owner=state.used.get(callsignKey(callsign));
      if(owner&&owner!==id)throw Error('Callsign collision '+callsign);
      const rosterOwner=rosterOwners.get(callsignKey(callsign));
      if(rosterOwner&&rosterOwner!==id)throw Error('Callsign '+callsign+' is occupied in the mapped roster');
      // Claim new values immediately so later officers in this same batch
      // cannot choose the same printed candidate or collide with an override.
      state.used.set(callsignKey(callsign),id);
      started.add(callsignKey(callsign));
      if(originalCall!==callsign||!existing||originalSource!==source){
        let row=existing||[id,'','','',now(),'', ''];
        row[1]=callsign;row[2]=source;row[3]=prefix;
        row[4]=row[4]||now();row[5]=now();row[6]=forced?override.actor:'AUTO';
        byId.set(id,row);
        if(!existing){state.rows.push(row);} // existing rows are shared references
        changed.push(id);
        const action=forced?(source==='MANUAL'?'Manual Change':'Reset To Auto'):
           (!originalCall?'Automatic Assignment':'Automatic Rank Update');
        const {createHash}=require('node:crypto');
        const eventId=createHash('sha256').update(`${id}|${originalCall}|${callsign}|${action}|${row[5]}`).digest('hex').slice(0,32);
        audit.push([eventId,id,display(member),action,originalCall,callsign,row[5],forced?override.actor:'AUTO']);
      }
      if(!detail||detail.row[1]!==callsign){
        let number;
        if(detail) number=detail.index;
        else {
          // A blank Google Sheets checkbox may render as FALSE. Treat unchecked
          // boxes as empty when looking for a safe free row; preserve any notes,
          // statuses, IDs or checked qualifications already written manually.
          const occupied=(r)=>r.some((v,i)=>{
            const x=string(v).toLowerCase();
            return i>=2&&i<=12 ? !!x&&x!=='false'&&x!=='☐' : !!x;
          });
          const free=state.details.findIndex(row=>!occupied(row));
          number=free<0?state.details.length+2:free+2;
          const row=Array(18).fill('');row[0]=id;row[1]=callsign;
          state.details[number-2]=row;
          state.detailById.set(id,{index:number,row});
        }
        changes.push({range:`${quoteTab(this.detailsTab)}!A${number}:B${number}`,values:[[id,callsign]]});
        if(detail) detail.row[1]=callsign;
      }
    }
    if(changed.length){
      const all=state.rows.map(r=>normalizeRow(r,7));
      await this.writeRanges([{range:`${quoteTab(this.callsignTab)}!A2:G${all.length+1}`,values:all}]);
    }
    if(changes.length)await this.writeRanges(changes);
    if(audit.length)await this.sheets.appendValues(`${quoteTab(this.auditTab)}!A:H`,audit);
    const callsign=override?byId.get(String(override.id))?.[1]||null:null;
    const memberById=new Map(membersArray.map(m=>[String(m.user.id),m]));
    const result={callsign,changed:changed.length,detailsUpdated:changes.length,
      announcements:audit.map(([eventId,userId,officer,action,oldCallsign,newCallsign,at,actor])=>
        ({eventId,userId,officer,action,oldCallsign,newCallsign,at,actor,
          newRank:String(this.mainRankEntry(memberById.get(userId)||{roles:[]},ranks)?.label||'')}))};
    return returnEvents?result:(override?callsign:{changed:changed.length,detailsUpdated:changes.length});
  }
  static cleanInput(text){
    const v=string(text);
    if(v.toLowerCase()==='auto')return 'auto';
    if(!/^[A-Za-z0-9()[\]_-]{2,20}$/.test(v))throw Error('Use 2-20 letters/numbers/()-_ with no spaces, e.g. (X)G-05, or auto.');
    const brackets=[];
    for(const char of v){
      if(char==='('||char==='[')brackets.push(char);
      else if(char===')'||char===']'){
        if(brackets.pop()!==(char===')'?'(':'['))throw Error('Callsign parentheses and brackets must be balanced, e.g. (X)G-05.');
      }
    }
    if(brackets.length)throw Error('Callsign parentheses and brackets must be balanced, e.g. (X)G-05.');
    return v.toUpperCase();
  }
}
module.exports={CallsignManager,CALLSIGN_HEADERS,CALLSIGN_HISTORY_HEADERS,DEFAULT_PREFIXES,prefixFor,allocate,callsignKey};
