'use strict';
// Layout-aware mirror for individually mapped spreadsheet rank sections.
// NEVER edits columns outside the administrator's explicit mapping.
const {GoogleSheetsClient,quoteTab}=require('./googleSheets');
const {prefixFor,callsignKey,CallsignManager}=require('./callsigns');
const str=x=>String(x??'').trim();
const letterToIndex=col=>{const s=str(col).toUpperCase();if(!/^[A-Z]{1,3}$/.test(s))throw Error('Invalid column '+col);return [...s].reduce((a,c)=>a*26+c.charCodeAt(0)-64,0)-1;};
const indexToLetter=index=>{if(!Number.isSafeInteger(index)||index<0||index>=18278)throw Error('Invalid column index');let n=index+1,s='';while(n>0){n--;s=String.fromCharCode(65+(n%26))+s;n=Math.floor(n/26);}return s;};
const canonical=val=>{const m=str(val).toUpperCase().match(/^(?:\(X\)\s*)?([A-Z]{1,4})\s*-\s*(\d{1,5})$/);return m?m[1]+'-'+String(Number(m[2])).padStart(2,'0'):null;};
const SECTION_KEYS=new Set(['probationary','leo','senior','corporal','sergeant','lieutenant','captain','commander','hq']);
const MAPPED_FIELDS=new Set(['name','callsign','rank','id','status','subdivision','certifications','strikes','notes']);
const emptyIdentity=value=>['','OPEN','VACANT','AVAILABLE','N/A','-','FALSE','☐'].includes(str(value).toUpperCase());
function rosterCallKey(value){
 if(emptyIdentity(value))return '';
 if(!canonical(value)){
  const checked=CallsignManager.cleanInput(value);
  if(checked==='auto')throw Error('The auto command is not a printed roster callsign');
 }
 return callsignKey(value);
}
function checkedRowCall(section,row,data){
 try{return rosterCallKey(data[section.indices.callsign]);}
 catch(error){throw Error('Malformed callsign at '+section.tab+' row '+row+': '+error.message);}
}
function validatedSection(section){
 if(!section||typeof section!=='object'||Array.isArray(section))throw Error('Invalid roster section');
 const s={...section,tab:str(section.tab)};
 for(const field of ['startRow','endRow']){
  const value=Number(s[field]);
  if(!Number.isSafeInteger(value)||value<1||value>2147483647)throw Error('Invalid section '+field);
  s[field]=value;
 }
 if(!s.tab||s.tab.length>100||s.endRow<s.startRow)throw Error('Invalid section tab/startRow/endRow');
 if(s.templateRow!==undefined){
  s.templateRow=Number(s.templateRow);
  if(!Number.isSafeInteger(s.templateRow)||s.templateRow<s.startRow||s.templateRow>s.endRow)throw Error('Invalid template row');
 }
 if(!s.columns||typeof s.columns!=='object'||Array.isArray(s.columns))throw Error('Missing mapped columns');
 s.columns=Object.fromEntries(Object.entries(s.columns).map(([field,column])=>{
  if(!MAPPED_FIELDS.has(field))throw Error('Unknown mapped field '+field);
  return [field,str(column).toUpperCase()];
 }));
 for(const field of ['name','callsign'])if(!s.columns[field])throw Error('Missing required '+field+' column');
 const indices=Object.fromEntries(Object.entries(s.columns).map(([k,v])=>[k,letterToIndex(v)]));
 if(new Set(Object.values(indices)).size!==Object.keys(indices).length)throw Error('Duplicate mapped columns');
 return {...s,indices};
}
function validatedLayout(layout={}){
 if(!layout||typeof layout!=='object'||Array.isArray(layout))throw Error('Invalid roster layout');
 const sections=Object.fromEntries(Object.entries(layout.sections||{}).map(([key,value])=>{
  if(!SECTION_KEYS.has(key))throw Error('Unknown roster rank section '+key);
  return [key,validatedSection(value)];
 }));
 const entries=Object.entries(sections);
 for(let i=0;i<entries.length;i++)for(let j=i+1;j<entries.length;j++){
  const [aKey,a]=entries[i],[bKey,b]=entries[j];
  if(a.tab===b.tab&&a.startRow<=b.endRow&&b.startRow<=a.endRow&&
    Object.values(a.indices).some(col=>Object.values(b.indices).includes(col)))
   throw Error('Overlapping mapped cells in sections '+aKey+' and '+bKey);
 }
 return {...layout,sections};
}
function blankEntry(row,s){
 // Explicit mappings define the table. Other columns can contain separate
 // rosters, dates, formulas, qualifications or manual information we never edit.
 if(!['name','id'].every(field=>s.indices[field]===undefined||emptyIdentity(row[s.indices[field]])))return false;
 return Object.entries(s.indices).every(([field,col])=>['name','id','callsign','rank','status'].includes(field)||emptyIdentity(row[col]));
}
const cellKey=(key,row)=>key+'|'+row;
function inRange(range,row,column){
 return range&&row>=(range.startRowIndex??0)&&row<(range.endRowIndex??Infinity)&&
  column>=(range.startColumnIndex??0)&&column<(range.endColumnIndex??Infinity);
}
function canEditCell(sheet,row,column){
 return !(sheet.protectedRanges||[]).some(p=>{
  if(p.warningOnly||p.requestingUserCanEdit===true||!inRange(p.range,row,column))return false;
  return !(p.unprotectedRanges||[]).some(range=>inRange(range,row,column));
 });
}
class CustomRosterMirror{
 constructor(backend,sheetId,credentials,layout,helpers,onLayoutChange){
  this.backend=backend;this.target=new GoogleSheetsClient(sheetId,credentials);
  const validated=validatedLayout(layout||{});
  this.layout={...validated,sections:Object.fromEntries(Object.entries(validated.sections).map(([key,{indices,...section}])=>[key,section]))};
  this.helpers=helpers||{};this.placements=this.layout.placements||{};this.layout.placements=this.placements;this.onLayoutChange=onLayoutChange||(()=>{});
  this.sections=validated.sections;
  this.stats={lastError:null,lastSuccess:null,lastRowsUpdated:0};
  this.meta=null;
 }
 async prepare(){
  const res=await this.target.request('GET','?fields=sheets(properties(sheetId,title,gridProperties(rowCount,columnCount)),merges,protectedRanges(range,warningOnly,requestingUserCanEdit,unprotectedRanges),basicFilter(range))');
  this.meta=new Map((res.sheets||[]).map(s=>[s.properties.title,s]));
  for(const [key,s] of Object.entries(this.sections)){
   const sheet=this.meta.get(s.tab);
   if(!sheet)throw Error('Missing configured roster tab '+s.tab);
   if(s.endRow>sheet.properties.gridProperties.rowCount)throw Error('Section '+key+' lies outside the sheet');
   if(Object.values(s.indices).some(c=>c>=sheet.properties.gridProperties.columnCount))throw Error('Section '+key+' has column beyond sheet bounds');
   for(const merge of sheet.merges||[])for(const [field,col] of Object.entries(s.indices)){
    const first=Math.max(s.startRow-1,merge.startRowIndex??0),last=Math.min(s.endRow,merge.endRowIndex??Infinity);
    if(first<last&&col>=(merge.startColumnIndex??0)&&col<(merge.endColumnIndex??Infinity)&&
      (col!==(merge.startColumnIndex??0)||first!==(merge.startRowIndex??0)||last>first+1))
     throw Error('Mapped '+field+' cells in section '+key+' intersect non-anchor merged cells');
   }
  }
 }
 sectionFor(level){const key=level>=90?'hq':level>=80?'commander':level>=70?'captain':level>=60?'lieutenant':level>=50?'sergeant':level>=40?'corporal':level>=30?'senior':level>=20?'leo':level>=10?'probationary':null;return {key,section:this.sections[key]};}
 async rows(section){
  const max=Math.max(...Object.values(section.indices));
  const range=`${quoteTab(section.tab)}!A${section.startRow}:${indexToLetter(max)}${section.endRow}`;
  const values=await this.target.getValues(range);
  return Array.from({length:section.endRow-section.startRow+1},(_,i)=>values[i]||[]);
 }
 async allRows(){const obj={};for(const [key,section] of Object.entries(this.sections))obj[key]=await this.rows(section);return obj;}
 callsignInventory(rows){
  const inventory=new Map(),linked=new Map();
  for(const [id,p] of Object.entries(this.placements))linked.set(cellKey(p.key,p.row),id);
  for(const [key,section] of Object.entries(this.sections))for(const [offset,row] of rows[key].entries()){
   const call=checkedRowCall(section,section.startRow+offset,row);if(!call)continue;
   if(inventory.has(call))throw Error('Duplicate callsign '+call+' in custom roster');
   const vacancy=blankEntry(row,section),id=str(row[section.indices.id]);
   const owner=emptyIdentity(id)?linked.get(cellKey(key,section.startRow+offset))||'LEGACY':id;
   inventory.set(call,{key,row:section.startRow+offset,vacancy,owner});
  }
  return inventory;
 }
 async callCandidates(members,ranks){
  if(!this.meta)await this.prepare();
  const rows=await this.allRows();await this.validatePlacements(rows);
  const inventory=this.callsignInventory(rows),reserved=new Set(inventory.keys()),usedByOthers=new Map(),candidates=new Map();
  for(const [call,slot] of inventory)if(!slot.vacancy)usedByOthers.set(call,slot.owner);
  for(const member of members){
   const main=this.helpers.mainRankEntry(member,ranks);if(!main)continue;
   const level=this.helpers.rankLevel(main.roleName||main.label),id=str(member.user.id);
   const {key,section}=this.sectionFor(level);if(!section)continue;
   const prefix=prefixFor(level,this.layout.callsignPrefixes||{});
   const own=[],free=[];
   for(const row of rows[key]){
    const call=canonical(row[section.indices.callsign]);if(!call||!call.startsWith(prefix+'-'))continue;
    if(section.indices.id!==undefined && str(row[section.indices.id])===id)own.push(call);
    else if(blankEntry(row,section))free.push(call);
   }
   const placement=this.placements[id],ownNumeric=canonical(placement?.callsign);
   if(placement?.key===key&&ownNumeric&&ownNumeric.startsWith(prefix+'-')&&!own.includes(ownNumeric))own.unshift(ownNumeric);
   candidates.set(id,[...own,...free]);
  }
  return {reserved,usedByOthers,candidates};
 }
 async readCallsigns(){
  if(!this.meta)await this.prepare();
  const result=[];
  for(const [key,s] of Object.entries(this.sections))for(const [offset,row] of (await this.rows(s)).entries()){
   const call=checkedRowCall(s,s.startRow+offset,row);if(call)result.push({call,name:str(row[s.indices.name]),section:key});
  }
  return result;
 }
 assertPlacement(id,remembered,section,row){
  if(!section||section.tab!==remembered.tab||!Number.isSafeInteger(remembered.row)||remembered.row<section.startRow||remembered.row>section.endRow)
   throw Error('Saved placement invalid for '+id+'; run setup/remap');
  const expected=rosterCallKey(remembered.callsign),actual=rosterCallKey(row[section.indices.callsign]);
  if(!expected||actual!==expected)throw Error('Roster layout changed near '+remembered.tab+' row '+remembered.row+'; refusing to overwrite');
  const actualId=section.indices.id===undefined?'':str(row[section.indices.id]);
  if(!emptyIdentity(actualId)&&actualId!==id)throw Error('Mapped Discord ID does not match '+id+' at '+section.tab+' row '+remembered.row);
  if(emptyIdentity(actualId)){
   const name=str(row[section.indices.name]);
   if(emptyIdentity(name)||(remembered.name!==undefined&&name!==str(remembered.name)))
    throw Error('Linked officer identity changed at '+section.tab+' row '+remembered.row+'; run setup/remap');
  }
 }
 async validatePlacements(existingRows){
  if(!this.meta)await this.prepare();
  const rows=existingRows||await this.allRows(),occupied=new Set(),mappedIds=new Map();
  for(const [key,section] of Object.entries(this.sections)){
   for(const [offset,row] of rows[key].entries()){
    checkedRowCall(section,section.startRow+offset,row);
    if(section.indices.id===undefined)continue;
    const id=str(row[section.indices.id]);if(emptyIdentity(id))continue;
    const location=section.tab+' row '+(section.startRow+offset);
    if(!/^\d{16,22}$/.test(id))throw Error('Malformed Discord ID in custom roster at '+location);
    if(mappedIds.has(id))throw Error('Duplicate Discord ID in custom roster at '+mappedIds.get(id)+' and '+location);
    mappedIds.set(id,location);
   }
  }
  for(const [id,p] of Object.entries(this.placements)){
   if(!/^\d{16,22}$/.test(id)||!p||typeof p!=='object')throw Error('Invalid linked officer placement');
   const s=this.sections[p.key];
   this.assertPlacement(id,p,s,s?(rows[p.key]?.[p.row-s.startRow]||[]):[]);
   const key=cellKey(p.key,p.row);
   if(occupied.has(key))throw Error('Multiple officers linked to the same custom roster slot');
   occupied.add(key);
  }
  return {count:Object.keys(this.placements).length};
 }
 async findMember(id){
  id=str(id);const all=[];
  const remembered=this.placements[id];
  if(remembered){
   const s=this.sections[remembered.key];
   if(!s)throw Error('Saved placement invalid for '+id+'; run setup/remap');
   const rows=await this.rows(s),row=rows[remembered.row-s.startRow]||[];
   this.assertPlacement(id,remembered,s,row);
   all.push({id,key:remembered.key,section:s,row:remembered.row,data:row});
  }
  for(const [key,s] of Object.entries(this.sections)){
   if(s.indices.id===undefined)continue;
   const rows=await this.rows(s);
   rows.forEach((row,i)=>{if(str(row[s.indices.id])===id)all.push({id,key,section:s,row:s.startRow+i,data:row});});
  }
  const unique=new Map();for(const item of all){const key=cellKey(item.key,item.row);if(!unique.has(key))unique.set(key,item);}
  return [...unique.values()];
 }
 async preflightInsertion(section){
  await this.prepare(); // protections, merges and filters may have moved since the last write
  const sheet=this.meta.get(section.tab),index=section.endRow; // 0-based insert AFTER 1-based endRow
  const intersects=(range)=>range && (range.startRowIndex??0)<=index && (range.endRowIndex??Infinity)>index;
  if((sheet.merges||[]).some(intersects))throw Error('Row insertion intersects merged cells: requires manual review');
  if((sheet.protectedRanges||[]).some(p=>!p.warningOnly && p.requestingUserCanEdit!==true && intersects(p.range)))throw Error('Row insertion intersects a protected range');
  if(sheet.basicFilter&&intersects(sheet.basicFilter.range))throw Error('Row insertion touches an active filter range; expand manually');
  // A row insertion moves every column on that sheet. Side-by-side independent
  // tables cannot be expanded without also shifting their rows; require opt-in.
  if(this.layout.allowWholeRowInsertion!==true)throw Error('Automatic row insertion disabled; enable after reviewing side-by-side tables');
  return {sheet,index};
 }
 async extendSection(key){
  const s=this.sections[key];if(!s)throw Error('Section not configured');
  const {sheet,index}=await this.preflightInsertion(s);
  const sheetId=sheet.properties.sheetId;
  const source=(s.templateRow||s.endRow)-1;
  const rowCount=sheet.properties.gridProperties.rowCount;
  // Insert row in the same rank block, inheriting row formatting and then copying
  // the verified template FORMAT + validation only, never the officer's values.
  const requests=[{insertDimension:{range:{sheetId,dimension:'ROWS',startIndex:index,endIndex:index+1},inheritFromBefore:true}},
   {copyPaste:{source:{sheetId,startRowIndex:source,endRowIndex:source+1,startColumnIndex:0,endColumnIndex:sheet.properties.gridProperties.columnCount},
    destination:{sheetId,startRowIndex:index,endRowIndex:index+1,startColumnIndex:0,endColumnIndex:sheet.properties.gridProperties.columnCount},pasteType:'PASTE_FORMAT'}},
   {copyPaste:{source:{sheetId,startRowIndex:source,endRowIndex:source+1},destination:{sheetId,startRowIndex:index,endRowIndex:index+1},pasteType:'PASTE_DATA_VALIDATION'}},
   {copyPaste:{source:{sheetId,startRowIndex:source,endRowIndex:source+1},destination:{sheetId,startRowIndex:index,endRowIndex:index+1},pasteType:'PASTE_FORMULA'}}];
  const sourceStyle=await this.target.request('GET',`?ranges=${encodeURIComponent(`${quoteTab(s.tab)}!A${source+1}`)}&includeGridData=true&fields=sheets(data(rowMetadata(pixelSize)))`);
  const height=sourceStyle.sheets?.[0]?.data?.[0]?.rowMetadata?.[0]?.pixelSize;
  if(height)requests.push({updateDimensionProperties:{range:{sheetId,dimension:'ROWS',startIndex:index,endIndex:index+1},properties:{pixelSize:height},fields:'pixelSize'}});
  await this.target.request('POST',':batchUpdate',{requests});
  for(const [otherKey,other] of Object.entries(this.sections)){
   if(other.tab!==s.tab)continue;
   if(otherKey===key){other.endRow++;continue;}
   if(other.startRow>index){other.startRow++;other.endRow++;if(other.templateRow)other.templateRow++;}
   else if(other.endRow>index){other.endRow++;}
  }
  for(const place of Object.values(this.placements)){
   if(place.tab===s.tab && place.row>index)place.row++;
  }
  sheet.properties.gridProperties.rowCount=rowCount+1;
  const serialized={...this.layout,placements:this.placements,sections:Object.fromEntries(Object.entries(this.sections).map(([k,{indices,...v}])=>[k,v]))};
  this.layout=serialized;
  this.meta=null; // Google shifts metadata ranges when inserting; fetch authoritative coordinates next time.
  await this.onLayoutChange(serialized); // persisted before subsequent sync
  return index+1;
 }
 async validateWriteAccess(){
  if(!this.meta)await this.prepare();
  let cells=0;
  for(const [key,section] of Object.entries(this.sections)){
   const sheet=this.meta.get(section.tab);
   for(let row=section.startRow;row<=section.endRow;row++)for(const [field,col] of Object.entries(section.indices)){
    if(!canEditCell(sheet,row-1,col))throw Error('Mapped '+field+' cell is protected in section '+key+': '+quoteTab(section.tab)+'!'+indexToLetter(col)+row);
    cells++;
   }
  }
  return {cells,sections:Object.keys(this.sections).length};
 }
 async validateChanges(section,row,changes){
  if(!changes.length)return;
  if(!this.meta)await this.prepare();
  const sheet=this.meta.get(section.tab);
  for(const change of changes){
   if(!canEditCell(sheet,row-1,change.column))throw Error('Mapped cell is protected: '+change.range);
   const cell=await this.target.request('GET',`/values/${encodeURIComponent(change.range)}?valueRenderOption=FORMULA`);
   if(String(cell.values?.[0]?.[0]??'').startsWith('='))throw Error('Refusing to replace formula at '+change.range);
  }
 }
 async commitChanges(changes){
  if(changes.length)await this.target.request('POST','/values:batchUpdate',{valueInputOption:'RAW',data:changes.map(({column,...change})=>change)});
  return changes.length;
 }
 async applyChanges(section,row,changes){await this.validateChanges(section,row,changes);return this.commitChanges(changes);}
 async planWriteOne(s,row,fields,existing,{ownerId}={}){
  const changes=[];
  for(const [key,value] of Object.entries(fields)){
   const col=s.indices[key];if(col===undefined)continue;
   const current=str(existing[col]);
   if(current===str(value)||(key==='callsign'&&current&&callsignKey(current)===callsignKey(value)))continue;
   if(['id','name','callsign'].includes(key)&&!emptyIdentity(current)&&current!==str(value)&&!(ownerId&&['name','callsign'].includes(key)))
    throw Error('Refusing overwrite of occupied '+key+' in '+s.tab+' row '+row);
   changes.push({range:`${quoteTab(s.tab)}!${indexToLetter(col)}${row}`,values:[[str(value)]],column:col});
  }
  await this.validateChanges(s,row,changes);
  return changes;
 }
 async writeOne(s,row,fields,existing,options){return this.commitChanges(await this.planWriteOne(s,row,fields,existing,options));}
 async sync(members,ranks,{full=false}={}){
  if(!this.meta)await this.prepare();
  const initialRows=await this.allRows();await this.validatePlacements(initialRows);
  const inventory=this.callsignInventory(initialRows);
  let changed=0,skipped=0;
  const backendCalls=await this.backend.getValues(`${quoteTab(this.layout.callsignTab||'SADLE Callsigns')}!A2:G`);
  const assigned=new Map(),assignedOwners=new Map();
  for(const row of backendCalls){
   if(!row[0]||!row[1])continue;
   const id=str(row[0]),call=str(row[1]),callKey=rosterCallKey(call);
   if(!callKey)throw Error('Invalid assigned callsign for custom roster');
   if(assigned.has(id))throw Error('Duplicate assigned officer identity in custom roster');
   if(assignedOwners.has(callKey)&&assignedOwners.get(callKey)!==id)throw Error('Duplicate assigned callsign '+call);
   assigned.set(id,{call,manual:str(row[2]).toUpperCase()==='MANUAL'||!canonical(call)});assignedOwners.set(callKey,id);
  }
  const known=new Set();
  for(const member of members){
   const id=str(member?.user?.id);if(!id||member.user.bot)continue;
   known.add(id);
   const main=this.helpers.mainRankEntry(member,ranks);
   const level=main?this.helpers.rankLevel(main.roleName||main.label):0;
   const {key,section}=this.sectionFor(level);
   const existing=await this.findMember(id);
   if(!section){
    if(main)throw Error('No custom roster section mapped for rank '+key);
    if(existing.length){await this.clearPlacements(existing);delete this.placements[id];await this.onLayoutChange(this.layout);}
    continue;
   }
   const assignment=assigned.get(id);if(!assignment){skipped++;continue;}
   const {call,manual}=assignment,callKey=rosterCallKey(call),slot=inventory.get(callKey);
   if(slot&&!slot.vacancy&&slot.owner!==id)throw Error('Callsign '+call+' belongs to another custom roster officer');
   if(existing.length>1){skipped++;throw Error('Duplicate officer identity '+id+' in custom roster');}
   const current=existing[0];
   const sameCall=current&&rosterCallKey(current.data[section.indices.callsign])===callKey;
   const canChangeInPlace=manual&&(!slot||(current&&slot.key===current.key&&slot.row===current.row));
   if(current&&current.key===key&&(sameCall||canChangeInPlace)){
    // Owned manual identifiers can change in place. Preserve decorated numeric
    // printing when unchanged; arbitrary manual identifiers never inherit (X).
    const numeric=canonical(call),oldPrinted=str(current.data[section.indices.callsign]);
    const printedCall=numeric&&/^\(X\)/i.test(oldPrinted)?'(X)'+numeric:call;
    const requested={callsign:printedCall,name:str(member.nick||member.user.global_name||member.user.username),rank:str(main.label||main.roleName),id};
    changed+=await this.writeOne(section,current.row,requested,current.data,{ownerId:id});
    await this.remember(id,key,section,current.row,call,requested.name);
    continue;
   }
   // Validate the source before even inserting a destination row. A protected
   // or formula-owned source must not leave a half-completed promotion behind.
   let sourceClear=current?await this.planClearPlacements([current]):[];
   let all=await this.rows(section);
   const matches=[];
   for(let i=0;i<all.length;i++)if(rosterCallKey(all[i][section.indices.callsign])===callKey&&blankEntry(all[i],section))matches.push(i);
   if(matches.length>1)throw Error('Multiple blank slots with '+call+' in '+section.tab);
   let offset=matches[0];
   if(offset===undefined){
    offset=all.findIndex(row=>blankEntry(row,section)&&!rosterCallKey(row[section.indices.callsign])&&Object.entries(section.indices).every(([field,c])=>['name','id','callsign','rank','status'].includes(field)||!str(row[c])));
   }
   let row;
   let oldPlacement=current;
   if(offset<0||offset===undefined){
    if(manual&&this.layout.allowWholeRowInsertion!==true)throw Error('No unnumbered slot for manual callsign '+call+'; automatic row insertion is disabled');
    const insertionIndex=section.endRow;
    row=await this.extendSection(key);all=await this.rows(section);offset=row-section.startRow;
    if(oldPlacement&&oldPlacement.section.tab===section.tab&&oldPlacement.row>insertionIndex)
      oldPlacement={...oldPlacement,row:oldPlacement.row+1};
   }
   else row=section.startRow+offset;
   const existingStyle=all.map(v=>str(v[section.indices.callsign])).find(v=>/^\(X\)/i.test(v));
   const numeric=canonical(call),printedCall=existingStyle&&numeric?'(X)'+numeric:call;
   const fields={callsign:printedCall,name:str(member.nick||member.user.global_name||member.user.username),id,rank:str(main.label||main.roleName)};
   // Migrate the original Notes cell text when moving between ranks, but do
   // not replace notes already present in a destination slot.
   if(oldPlacement&&oldPlacement.section.indices.notes!==undefined&&section.indices.notes!==undefined){
    const previousNotes=str(oldPlacement.data[oldPlacement.section.indices.notes]);
    if(previousNotes&&!str((all[offset]||[])[section.indices.notes]))fields.notes=previousNotes;
   }
   const destination=await this.planWriteOne(section,row,fields,all[offset]||[]);
   if(oldPlacement)sourceClear=await this.planClearPlacements([oldPlacement]);
   // Commit destination and source identity updates together, then persist the
   // new placement. Notes and other manual cells remain untouched at source.
   changed+=await this.commitChanges([...destination,...sourceClear]);
   await this.remember(id,key,section,row,call,fields.name);
  }
  this.stats.lastRowsUpdated=changed;this.stats.lastSuccess=new Date().toISOString();this.stats.lastError=null;
  return {changed,skipped};
 }
 async planClearPlacements(placements){
  const planned=[];
  for(const p of placements){
   const live=await this.rows(p.section),before=live[p.row-p.section.startRow]||[];
   this.assertPlacement(p.id,{tab:p.section.tab,row:p.row,callsign:p.data[p.section.indices.callsign],name:p.data[p.section.indices.name]},p.section,before);
   const clear=['name','id','status','subdivision','certifications','strikes']; // preserve manual notes
   const changes=[];
   for(const field of clear){const col=p.section.indices[field];if(col!==undefined&&str(before[col]))
    changes.push({range:`${quoteTab(p.section.tab)}!${indexToLetter(col)}${p.row}`,values:[['']],column:col});}
   await this.validateChanges(p.section,p.row,changes);planned.push(...changes);
  }
  return planned;
 }
 async clearPlacements(placements){return this.commitChanges(await this.planClearPlacements(placements));}
 async remember(id,key,section,row,callsign,name){
  this.placements[id]={key,tab:section.tab,row,callsign,...(name!==undefined?{name}: {})};
  this.layout.placements=this.placements;
  await this.onLayoutChange(this.layout);
 }
 async dropOne(id){
  await this.clearPlacements(await this.findMember(id));
  delete this.placements[id];this.layout.placements=this.placements;
  await this.onLayoutChange(this.layout);
 }
  async appendOfficerNote(id,{note,actor}){
    if(!this.meta)await this.prepare();
    const found=await this.findMember(String(id));
    if(found.length!==1)throw Error(found.length?'Ambiguous officer location':'Officer not placed in mapped roster');
    const {section,row,data}=found[0],col=section.indices.notes;
    if(col===undefined)return {updated:0,unmapped:true}; // Never add a notes column.
    const range=`${quoteTab(section.tab)}!${indexToLetter(col)}${row}`;
    const literal=await this.target.request('GET',`/values/${encodeURIComponent(range)}?valueRenderOption=FORMULA`);
    const existing=String(literal.values?.[0]?.[0]??'');
    if(existing.startsWith('='))throw Error('Refusing to replace formula in notes at '+range);
    const added=`${new Date().toISOString().slice(0,10)} — ${String(note).trim()}`;
    const next=existing?existing+'\n'+added:added;
    if(next.length>45000)throw Error('Existing roster notes cell is full; note is safely saved in private history');
    await this.target.putValues(range,[[next]]);
    return {updated:1};
  }
  async updateOfficerFields(id,fields){
    // Only existing mapped columns are writable. Detailed strike reasons/appeals stay PRIVATE.
    if(!Object.values(this.sections).some(s=>['subdivision','certifications','status','strikes'].some(field=>s.indices[field]!==undefined)))return {updated:0,unmapped:true};
    if(!this.meta)await this.prepare();
    const found=await this.findMember(String(id));
    if(!found.length)return {updated:0,unmapped:true};
    if(found.length>1)throw Error('Duplicate officer identity in custom roster; refusing profile update');
    const {section,row,data}=found[0];
    if(section.indices.id!==undefined&&str(data[section.indices.id])!==String(id))
      throw Error('Mapped Discord ID does not match '+id+' at '+section.tab+' row '+row);
    const update=[];
    for(const field of ['subdivision','certifications','status','strikes']){
      if(!Object.hasOwn(fields,field)||section.indices[field]===undefined)continue;
      const value=String(fields[field]??'');
      if(str(data[section.indices[field]])===value)continue;
      const column=indexToLetter(section.indices[field]);
      const range=`${quoteTab(section.tab)}!${column}${row}`;
      const cell=await this.target.request('GET',`/values/${encodeURIComponent(range)}?valueRenderOption=FORMULA`);
      const literal=String(cell.values?.[0]?.[0]??'');
      if(literal.startsWith('='))throw Error('Cannot replace formula in mapped '+field+' cell '+range);
      update.push({range,values:[[value]]});
    }
    if(update.length)await this.target.request('POST','/values:batchUpdate',{valueInputOption:'RAW',data:update});
    return {updated:update.length};
  }
 async syncOne(member,ranks){return this.sync([member],ranks,{full:false});}
}
module.exports={CustomRosterMirror,canonical,blankEntry,validatedSection,validatedLayout,letterToIndex,indexToLetter};
