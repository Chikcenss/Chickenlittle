'use strict';
// Dependency-free Discord gateway/REST adapter for FiveM's embedded Node.js 22.
// It intentionally implements only the discord.js API surface used by server.js.
// No separate bot host, Yarn resource, or npm installation is required.
const { EventEmitter } = require('node:events');
const GatewayIntentBits = Object.freeze({Guilds: 1, GuildMembers: 2, GuildModeration: 4});
const Events = Object.freeze({
  Error: 'error', Warn: 'warn', ClientReady: 'ready', InteractionCreate: 'interactionCreate',
  ShardDisconnect: 'shardDisconnect', ShardResume: 'shardResume'
});
const ActivityType = Object.freeze({Playing:0, Streaming:1, Listening:2, Watching:3});
const API_ROOT = 'https://discord.com/api/v10';
const RETRYABLE = new Set([429,500,502,503,504]);

async function request(token, method, path, payload, attempt=0) {
  if (typeof fetch !== 'function') throw new Error('This FXServer build does not provide Node.js fetch. Update server artifacts for Node.js 22.');
  let res;
  try {
    res = await fetch(`${API_ROOT}${path}`, {
      method,
      headers: {
        Authorization: `Bot ${token}`,
        'User-Agent': 'GORP-FiveM-Bot (1.3.0)',
        ...(payload === undefined ? {} : {'Content-Type':'application/json'})
      },
      ...(payload === undefined ? {} : {body:JSON.stringify(payload)}),
      signal: AbortSignal.timeout(14000)
    });
  } catch (e) { throw new Error(`Discord network unavailable: ${e.message}`); }
  let data;
  try { data=await res.json(); } catch (_) { data=null; }
  if (RETRYABLE.has(res.status) && attempt < 2) {
    const pause = Math.max(750, Math.min(4000, Number(data?.retry_after || 0.9)*1000));
    await new Promise(r=>setTimeout(r, pause));
    return request(token, method, path, payload, attempt+1);
  }
  if (!res.ok) throw new Error(`Discord HTTP ${res.status}${data?.message ? ': '+String(data.message).slice(0,140) : ''}`);
  return data;
}
class SlashCommandBuilder {
  constructor(){this.data={type:1};}
  setName(name){this.data.name=name; return this;}
  setDescription(desc){this.data.description=desc; return this;}
  addUserOption(build){return this._addOption(6,build);}
  addStringOption(build){return this._addOption(3,build);}
  addRoleOption(build){return this._addOption(8,build);}
  addIntegerOption(build){return this._addOption(4,build);}
  _addOption(type,build){
    const option={type,required:false};
    const builder={setName(value){option.name=value;return this;},
      setDescription(value){option.description=value;return this;},
      setRequired(value){option.required=Boolean(value);return this;},
      setMinLength(value){if(type!==3)throw Error('Minimum length only applies to string options');option.min_length=value;return this;},
      setMaxLength(value){if(type!==3)throw Error('Maximum length only applies to string options');option.max_length=value;return this;}};
    build(builder);
    if(!option.name||!option.description)throw Error('Discord slash option missing a name/description');
    if(!this.data.options)this.data.options=[];
    this.data.options.push(option);return this;
  }
  toJSON(){return {...this.data};}
}
class REST {
  setToken(token){this.token=token;return this;}
  put(path,{body}){return request(this.token,'PUT',path,body);}
}
const Routes={applicationGuildCommands:(app,guild)=>`/applications/${app}/guilds/${guild}/commands`};
class Client extends EventEmitter {
  constructor(opts={}) {
    super();
    this.intents=(opts.intents||[]).reduce((a,b)=>a|b,0);
    this.user=null; this.token=null; this.socket=null; this.heartbeat=null;
    this.reconnectTimer=null; this.retry=0; this.stopped=false; this.sequence=null;
    this.sessionId=null; this.resumeUrl=null; this.gatewayUrl=null; this.ack=true;
    this.guilds={fetch:async guildId=>({members:{fetch:async ({user})=>{
      const id=String(user);
      if (!/^\d{17,20}$/.test(id) || !/^\d{17,20}$/.test(String(guildId))) throw new Error('Invalid Discord member/guild ID');
      const member=await request(this.token,'GET',`/guilds/${guildId}/members/${id}`);
      return {roles:{cache:new Map((member.roles||[]).map(role=>[role,true]))}};
    }}})};
    // Node's EventEmitter 'error' is special. Set a default error handler for safe startup.
    this.on('error',()=>{});
  }
  _warn(message){this.emit(Events.Warn, String(message));}
  _send(op,d){
    if(this.socket && this.socket.readyState===1) this.socket.send(JSON.stringify({op,d}));
  }
  _heartbeat(){
    if(!this.ack) {this._warn('Discord gateway did not acknowledge heartbeat; reconnecting.');this.socket?.close();return;}
    this.ack=false; this._send(1,this.sequence);
  }
  _resetHeartbeat(){if(this.heartbeat){clearInterval(this.heartbeat);this.heartbeat=null;}}
  async login(token){
    if(this.stopped) throw new Error('Discord client was stopped');
    this.token=token;
    if(typeof WebSocket!=='function') throw new Error('This FXServer build lacks native WebSocket. Update FXServer artifacts to support Node.js 22.');
    const gateway=await request(token,'GET','/gateway/bot');
    this.gatewayUrl=gateway.url;
    await this._connect(true);
    return token ? 'connected' : '';
  }
  async _connect(waitUntilReady=false){
    if(this.stopped)return;
    const base=this.resumeUrl || this.gatewayUrl;
    const url=base.replace(/\/$/,'')+'/?v=10&encoding=json';
    return new Promise((resolve,reject)=>{
      let finished=false;
      let readyTimeout=null;
      let ws;
      const resolveOnce=()=>{if(!finished){finished=true;clearTimeout(readyTimeout);resolve();}};
      const rejectOnce=(error)=>{if(!finished){finished=true;clearTimeout(readyTimeout);reject(error);}};
      try {ws=new WebSocket(url);} catch(e){rejectOnce(e);return;}
      this.socket=ws;
      const failReady=()=>{if(waitUntilReady)rejectOnce(new Error('Discord gateway did not become ready in 30 seconds'));};
      if(waitUntilReady)readyTimeout=setTimeout(failReady,30000);
      ws.addEventListener('message',(event)=>{
        let p;
        try{p=JSON.parse(typeof event.data==='string'?event.data:String(event.data));}
        catch(_){return;}
        if(p.s!==null&&p.s!==undefined)this.sequence=p.s;
        if(p.op===10){
          this._resetHeartbeat();this.ack=true;
          const interval=Number(p.d?.heartbeat_interval||45000);
          this.heartbeat=setInterval(()=>this._heartbeat(),interval);
          if(this.sessionId&&this.resumeUrl){this._send(6,{token:this.token,session_id:this.sessionId,seq:this.sequence});}
          else this._send(2,{token:this.token,intents:this.intents,properties:{os:process.platform,browser:'gorp-fivem',device:'gorp-fivem'}});
          this._heartbeat();
        } else if(p.op===11){this.ack=true;}
        else if(p.op===1){this._heartbeat();}
        else if(p.op===7){ws.close();}
        else if(p.op===9){this.sessionId=null;this.resumeUrl=null;ws.close();}
        else if(p.op===0){
          this.emit('rawDiscordDispatch',p);
          if(p.t==='READY'){
            this.sessionId=p.d.session_id;
            this.resumeUrl=p.d.resume_gateway_url || this.gatewayUrl;
            this.retry=0;
            this.user={...p.d.user,tag:p.d.user.global_name||p.d.user.username,
              setActivity:(name,options={})=>this._send(3,{since:null,activities:[{name,type:options.type ?? 0}],status:'online',afk:false})};
            this.emit(Events.ClientReady);resolveOnce();
          } else if(p.t==='RESUMED'){
            this.retry=0;this.emit(Events.ShardResume);resolveOnce();
          } else if(p.t==='INTERACTION_CREATE'){
            const d=p.d;
            const options=Array.isArray(d.data?.options)?d.data.options:[];
            const getOption=name=>options.find(o=>o.name===name);
            const i={guildId:d.guild_id,commandName:d.data?.name,memberPermissions:String(d.member?.permissions||'0'),
              user:d.member?.user||d.user||{},isChatInputCommand:()=>d.type===2,
              options:{
                getString:name=>{const o=getOption(name);return o?.type===3?String(o.value):null;},
                getInteger:name=>{const o=getOption(name);return o?.type===4?Number(o.value):null;},
                getRole:name=>{const o=getOption(name);return o?.type===8?{...(d.data?.resolved?.roles?.[String(o.value)]||{}),id:String(o.value)}:null;},
                getUser:name=>{const o=getOption(name);return o?.type===6?{...(d.data?.resolved?.users?.[String(o.value)]||{}),id:String(o.value)}:null;}
              },
              reply:async ({content,ephemeral})=>request(this.token,'POST',`/interactions/${d.id}/${d.token}/callback`,
                {type:4,data:{content:String(content).slice(0,1900),flags:ephemeral?64:0}}),
              deferReply:async ({ephemeral}={})=>request(this.token,'POST',`/interactions/${d.id}/${d.token}/callback`,
                {type:5,data:{flags:ephemeral?64:0}}),
              editReply:async ({content})=>request(this.token,'PATCH',
                `/webhooks/${d.application_id}/${d.token}/messages/@original`,{content:String(content).slice(0,1900)})};
            // Never let an async interaction handler become an unhandled rejection.
            this.emit(Events.InteractionCreate,i);
          }
        }
      });
      ws.addEventListener('error',(ev)=>{this._warn('Discord gateway socket error');});
      ws.addEventListener('close',(ev)=>{
        if(this.socket!==ws)return;
        this._resetHeartbeat();
        this.emit(Events.ShardDisconnect,ev);
        if(this.stopped){rejectOnce(new Error('Bot stopped'));return;}
        // If GuildMembers is not enabled in the Developer Portal, fall back
        // automatically to Guilds/GuildModeration instead of taking the bot down.
        // The roster has a 30-second REST reconciliation as a safety net.
        if(ev.code===4014 && (this.intents & GatewayIntentBits.GuildMembers) && !this.membersIntentFallbackUsed){
          this.membersIntentFallbackUsed=true;
          this.intents &= ~GatewayIntentBits.GuildMembers;
          this.sessionId=null;this.resumeUrl=null;
          this._warn('Discord Server Members gateway intent not enabled. Live events unavailable; using periodic REST roster sync. Enable it in the Developer Portal for instant changes.');
          clearTimeout(readyTimeout);
          this._connect(waitUntilReady).then(resolveOnce,rejectOnce);
          return;
        }
        if([4004,4014].includes(ev.code)){
          this._warn(`Discord gateway rejected session (code ${ev.code}). Check bot token/intents.`);
          rejectOnce(new Error(`Discord gateway rejected session (${ev.code})`));return;
        }
        if(waitUntilReady)rejectOnce(new Error(`Discord gateway disconnected (code ${ev.code})`));
        this._retryConnect();
      });
    });
  }
  _retryConnect(){
    if(this.stopped||this.reconnectTimer)return;
    const wait=Math.min(30000,1500*Math.pow(2,Math.min(this.retry++,4)));
    this.reconnectTimer=setTimeout(()=>{
      this.reconnectTimer=null;
      this._connect(false).catch(e=>this._warn(`Discord reconnect failed: ${e.message}`));
    },wait);
  }
  destroy(){
    this.stopped=true;this._resetHeartbeat();
    if(this.reconnectTimer)clearTimeout(this.reconnectTimer);
    this.reconnectTimer=null;this.socket?.close();this.socket=null;
  }
}
module.exports={Client,GatewayIntentBits,Events,ActivityType,REST,Routes,SlashCommandBuilder,PermissionFlagsBits:{}};
